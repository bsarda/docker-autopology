Autopology Documentation
========================

To start the server after autopology package installation
# autopology.server

To build wheel package,
# python setup.py bdist_wheel

To install/upgrade the package,
# pip install --upgrade dist/*.whl


