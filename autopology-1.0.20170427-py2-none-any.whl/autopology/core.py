import copy
import json
import logging
import pprint

import random
import signal
import time
import types
import uuid


import config
import errors
import inventory
import topology
import expanders.expander as expander

topo = None
invdict = None
DEFAULT_NUM_THREADS = 16
DEFAULT_PRIORITY = 1
LOWEST_PRIORITY = 9
log = logging.getLogger('autopology')

urlmap = {'logical-switches': 'https://%s/nsxapi/#view=switching/switches/editor/summary&id=%s',  # noqa
          'logical-routers': 'https://%s/nsxapi/#view=routing/routers/editor/summary&id=%s',  # noqa
          'create-nic': 'https://%s/nsxapi/#view=switching/ports/editor/summary&id=%s'}  # noqa


def sig_handler(signum, frame):
    topo.dump()


signal.signal(signal.SIGALRM, sig_handler)


def json_dump(name, uid, data):
    fname = '%s/autopology_%s_%s.json' % (config.DEFAULT_LOG_DIR, name, uid)
    with open(fname, 'w') as f:
        json.dump(data, f, sort_keys=True, indent=4)


class DependencyHandler(object):

    @classmethod
    def on_set_queuer(cls, dct, *args):
        def foo(func):
            dct.on_set(func, *args)
        return foo

INTERNAL = '_internal'


def call(mgr, dct, uid, k, idx, schema):
    try:
        schema = make_manager_call(mgr, dct, uid, k, idx, schema)
        dct.decrement(uid, '_pending')
        dct.set(uid, INTERNAL,
                '%s.%s.id' % (k, schema.get('display_name')),
                str(schema.get('id')))
        dct.set(uid, k, idx, schema)
    except errors.WaitError:
        if dct.get(uid, 'status') == 'FAILURE':
            dct.decrement(uid, '_pending')
            dct.flush_on_set_queues()
            schema.update({'error': 'ABORTED'})
            dct.set(uid, k, idx, schema)
        else:
            raise
    except Exception as e:
        log.exception(e)
        dct.decrement(uid, '_pending')
        dct.set(uid, 'status', 'FAILURE')
        dct.flush_on_set_queues()
        schema.update({'error': 'Failed due to %s' % repr(e)})
        dct.set(uid, k, idx, schema)
        dct.dump()


def delete(mgr, dct, uid, k, idx, schema):
    try:
        make_manager_delete_call(mgr, dct, uid, k, idx, schema)
        dct.decrement(uid, '_pending')
        dct.set(uid, INTERNAL,
                '%s.%s.id' % (k, schema.get('display_name')), None)
    except errors.WaitError:
        raise
    except Exception as e:
        log.exception(e)
        dct.decrement(uid, '_pending')
        dct.set(uid, 'status', 'FAILURE')
        dct.flush_on_set_queues()
        schema.update({'error': 'Failed due to %s' % repr(e)})
        dct.set(uid, k, idx, schema)
        dct.dump()


def immutable_type(v):
    return (type(v) in types.StringTypes or
            type(v) in (types.IntType, types.BooleanType))


def replace_idref_in_schema(mgr, dct, uid, k, idx, schema):
    # TRACE log.debug('schema: %s' % schema)
    if immutable_type(schema):
        return

    for k, v in schema.iteritems():
        if type(v) is dict:
            # TRACE print "%s is dict, recursing" % k
            replace_idref_in_schema(mgr, dct, uid, k, idx, v)
        elif type(v) is list:
            # TRACE print "%s is list, iterating" % k
            for x in v:
                replace_idref_in_schema(mgr, dct, uid, k, idx, x)
        elif immutable_type(v) and type(v) not in types.StringTypes:
            continue
        elif v.startswith('FN-'):
            node_ip = v.split("-")[-1]
            node_id = get_node_id_from_ip(mgr, node_ip, False)
            if node_id is not None:
                schema[k] = node_id
            else:
                raise errors.WaitError(
                    "FabricNodeIdDependency<%s>" % node_ip, None)
        elif v.startswith('TN-'):
            node_ip = v.split("-")[-1]
            node_id = get_node_id_from_ip(mgr, node_ip, True)
            if node_id is not None:
                schema[k] = node_id
            else:
                raise errors.WaitError(
                    "TransportNodeIdDependency<%s>" % node_ip, None)
        elif v.endswith('.id'):  # All common scenarios
            # TRACE log.debug("%s:%s needs replace" % (k, v))
            cacheval = dct.get(uid, INTERNAL, v)
            if cacheval is not None:
                schema[k] = cacheval
            else:
                raise errors.WaitError(
                    "Dependency<%s>" % v,
                    DependencyHandler.on_set_queuer(dct, uid, INTERNAL, v))


def get_node_id_from_ip(mgr, node_ip, tn_required):
    list_fnode_url = 'fabric/nodes'
    list_tnode_url = 'transport-nodes'
    headers = {'Content-Type': 'application/json'}
    nodes = mgr.get(list_fnode_url)
    node_id = None
    for node in nodes:
        ips = [str(x) for x in node['ip_addresses']]
        if node_ip in ips:
            node_id = node['id']
            if not tn_required:
                return node_id

    if node_id is None:
        log.error("Unable to find node-id for node with IP '%s'" % node_ip)
        return
    tns = mgr.get(list_tnode_url)
    log.debug("Transport-nodes:\n%s" % pprint.pprint(tns))
    for tn in tns:
        if node_id == str(tn['node_id']):
            # time.sleep(120)  # XXX: Sleeping for TN and LSes to be synced
            return tn['id']


def get_fabric_nodes(resource_type=None):
    url = 'fabric/nodes'
    if resource_type:
        url = "%s?resource_type=%s" % (url, resource_type)
    return topo.nsxmanagers[0].get(url)


def make_manager_delete_call(mgr, dct, uid, k, idx, schema):
    try:
        mgr.delete(k, schema['id'])
    except Exception as e:
        raise errors.WaitError(
            "Dependency<unknown> %s" % e, None)


def make_manager_call(mgr, dct, uid, k, idx, schema):
    non_manager_keys = ['create-nic']
    non_manager_func_dict = {'create-nic': create_attach_vm_interface}

    if k.startswith('/'):
        lst = k.split('/')
        entity = lst[1]
        name = lst[2]
        v = "%s.%s.id" % (entity, name)
        cacheval = dct.get(uid, INTERNAL, v)
        log.debug([entity, name, k, cacheval])
        if cacheval is not None:
            lst[2] = cacheval
            k = '/'.join(lst[1:])
        else:
            raise errors.WaitError(
                "Dependency<%s>" % v,
                DependencyHandler.on_set_queuer(dct, uid, INTERNAL, v))

    # Pop unwanted paramters before making MP call.
    x = schema.pop('x', None)
    y = schema.pop('y', None)
    borathonid = schema.pop('borathonid', None)

    # Handle special cases where url is not a direct mapping of component name.
    if k == 'ip-pool':
        k = 'pools/ip-pools'
    elif k == 'uplink-profiles':
        k = 'host-switch-profiles'

    replace_idref_in_schema(mgr, dct, uid, k, idx, schema)
    if k in non_manager_keys:
        log.debug("Found key %r. Making non-manager call" % k)
        func = non_manager_func_dict[k]
        result = func(schema)
        url = None
    else:
        url = 'https://%s/api/v1/%s' % (mgr.ip, k)
        log.debug("Making manager call to URL %s with schema:\n%s" %
                  (url, pprint.pformat(schema)))
        if not mgr.ip:
            result = {'id': '%s-00000000' % schema['display_name']}
        else:
            put_endpoints = ('bgp',
                             'advertisement', 'advertisement/rules',
                             'redistribution', 'redistribution/rules')
            if any(k.endswith(x) for x in put_endpoints):
                result = mgr.put(k, None, schema, merge=True)
            else:
                result = mgr.post(k, schema)
    if 'id' in result:
        insert_url(schema, mgr, k, result['id'], url)
    else:
        log.warn("POST call returned:\n%s" % pprint.pformat(result))
        dct.set(uid, 'status', 'FAILURE')

    for key, value in result.iteritems():
        schema[str(key)] = value

    if schema.get('resource_type') in ('LogicalSwitch', 'TransportNode'):
        for _ in xrange(120):
            try:
                resp = topo.nsxmanagers[0].get(k, uid=result['id'],
                                               path_ext='state')
                if resp.get('state') == 'success':
                    break
            finally:
                log.debug("%s '%s' state '%s', retrying" %
                          (schema.get('resource_type'), result.get('id'),
                           resp.get('state')))
                time.sleep(5)
        else:
            msg = ("%s '%s' state '%s', failed" %
                   (schema.get('resource_type'), result.get('id'),
                    resp.get('state')))
            log.error(msg)
            schema['error'] = msg
            dct.set(uid, 'status', 'FAILURE')

    # Populate the earlier popped parameters to send back to UI.
    if x is not None:
        schema['x'] = x
    if y is not None:
        schema['y'] = y
    if borathonid is not None:
        schema['borathonid'] = borathonid
    return schema


def create_attach_vm_interface(vm_json):
    """
    Adds a vnic/vif to the VM provided in vm_json.
    Discovers the lport for this added vnic in case of guest VM hosted on ESX.
    Creates an lport for this added vif in case of guest VM hosted on KVM.

    Sample input:
    {'logical_switch_id': 'foo',
     'vm_uuid': 'ESX/10.116.247.248/1-vm_RHEL-srv32-local-1314-b/<vm-ip>',
     'vnic_ip': '192.168.1.1',
     'vnic_ip_prefix': '24'}

    Sample output:
    TODO
    """
    vm_json = inventory.Inventory.add_vm_interface(vm_json)
    if "ESX" in vm_json['vm_uuid']:
        lport = discover_logical_port(vm_json['interface_uuid'])
    elif "KVM" in vm_json['vm_uuid']:
        lport = create_logical_port(ls_id=vm_json['logical_switch_id'],
                                    interface_uuid=vm_json['interface_uuid'],
                                    attachment_type='VIF')
    else:
        raise ValueError("VM UUID must contain ESX/KVM. VM Json: %s" % vm_json)
    vm_json['id'] = lport
    return vm_json


def discover_logical_port(interface_uuid=None):
    log.debug('TODO: Add support for discover_logical_port().')
    pass


def create_logical_port(ls_id=None, interface_uuid=None, attachment_type=None):
    schema = {}
    schema['logical_switch_id'] = ls_id
    schema['attachment'] = {}
    schema['attachment']['attachment_type'] = attachment_type
    schema['attachment']['id'] = interface_uuid
    schema['admin_state'] = 'UP'
    return topo.nsxmanagers[0].post('logical-ports', schema)


def insert_url(schema, mgr, component, component_id, api_url):
    """
    Return UI-URL for components whose mapping is found in urlmap.
    Return API-URL otherwise.
    """
    if component_id is None:
        return
    if component in urlmap:
        schema['url'] = urlmap[component] % (mgr.ip, component_id)
    else:
        schema['url'] = '%s/%s' % (api_url, component_id)


def normalize_unicode_json(j):
    s = json.dumps(j)
    s = s.replace("true", "True")
    s = s.replace("false", "False")
    return eval(s)


def _post_bulk_api(data, uid=None):
    uid = uid or str(uuid.uuid4())
    data = normalize_unicode_json(data)
    topo.bulkdict.set(uid, 'id', uid)
    topo.bulkdict.set(uid, 'status', 'INPROGRESS')
    topo.resize_workers()
    for k, v in data.iteritems():
        if k in ('status', '_pending', 'id', INTERNAL):
            continue
        for idx, schema in v.iteritems():
            if schema.get('id'):
                log.debug('Found id in %s' % schema)
                continue
            topo.bulkdict.increment(uid, '_pending')
            topo.qiter.next().put(
                (random.choice([DEFAULT_PRIORITY, DEFAULT_PRIORITY + 1]),
                 [call, topo.mgr, topo.bulkdict, uid, k, idx, schema]))
    topo.bulkdict.dump()
    return topo.bulkdict.get(uid)


def _del_bulk_api(uid, data=None):
    uid = uid or str(uuid.uuid4())
    data = data or topo.bulkdict.get(uid)
    topo.bulkdict.set(uid, 'id', uid)
    topo.bulkdict.set(uid, 'status', 'INPROGRESS')
    for k, v in data.iteritems():
        if k in ('status', '_pending', 'id', INTERNAL):
            continue
        for idx, schema in v.iteritems():
            if not schema.get('id'):
                log.warn('Ignoring schema without id:\n%s' % schema)
                continue
            topo.bulkdict.increment(uid, '_pending')
            topo.qiter.next().put(
                (DEFAULT_PRIORITY,
                 [delete, topo.mgr, topo.bulkdict, uid, k, idx, schema]))
    topo.bulkdict.dump()
    return topo.bulkdict.get(uid)


def _post_topologies_api(data):
    uid = str(uuid.uuid4())
    try:
        data = _preprocess_topology_spec(uid, data)
        expanded_dict = compact_to_bulk(uid, data)
        _post_bulk_api(expanded_dict, uid)
        bulk_to_compact(_get_bulk_api(uid), topo.topodict.get(uid))
        topo.topodict.dump()
    except Exception as e:
        log.exception(e)
        topo.bulkdict.set(uid, 'status', 'FAILURE')
        topo.topodict.set(uid, 'status', 'FAILURE')
    return topo.topodict.get(uid)


def _post_monitor_api(data):
    uid = str(uuid.uuid4())
    data = normalize_unicode_json(data)
    data['id'] = uid
    data['status'] = 'INPROGRESS'
    topo.monitordict.set(uid, data)
    topo.start_monitor(uid, data['topology_id'], data.get('entity_id'))
    return data


def _preprocess_topology_spec(uid, data):
    """
    Takes input a topology spec received from UI or discovered from read-back
    and does the following tasks:
      1) Gives it an ID (random uuid)
      2) Gives it a tag if tag is not present in the spec.
      3) Stores this new spec in topodict
      4) Returns the new spec with tag (but not with ID)

    """
    existing = False
    if uid is None:
        uid = str(uuid.uuid4())
        existing = True
    data = normalize_unicode_json(data)
    cache = {'id': uid}
    # Only created topologies have 'tag'.
    # We should add the 'tag' for discovered topologies.
    if 'tag' not in data:
        data['tag'] = 'Discovered_%s' % uid
    cache.update(data)
    topo.topodict.set(uid, cache)
    topo.bulkdict.set(uid, 'id', uid)
    if existing:
        topo.bulkdict.set(uid, 'status', 'SUCCESS')
    return data


def _preprocess_existing_topo(existing_topo):
    """
    Takes input any existing topo spec received from read-back module and does
      1) Converts this read-back spec into the format identical to the spec
         received when a topology is created.
      2) Returns a list of specs with PLR as root node in each spec.

    """
    specs = []
    for plr in existing_topo.get('PLR', {}):
        spec = {'PLR': {}}
        plr_spec = existing_topo['PLR'][plr]
        spec['PLR'][1] = {}
        spec['PLR'][1]['display_name'] = plr_spec['display_name']
        spec['PLR'][1]['resource_type'] = plr_spec['resource_type']
        spec['PLR'][1]['url'] = plr_spec['url']
        spec['PLR'][1]['id'] = plr_spec['id']
        spec['PLR'][1]['TLR'] = {}
        for tlr_index, tlr in enumerate(plr_spec.get('TLR', [])):
            tlr_index += 1
            tlr_spec = plr_spec['TLR'][tlr]
            spec['PLR'][1]['TLR'][str(tlr_index)] = {}
            spec['PLR'][1]['TLR'][str(tlr_index)]['display_name'] = tlr_spec['display_name']  # noqa
            spec['PLR'][1]['TLR'][str(tlr_index)]['url'] = tlr_spec['url']
            spec['PLR'][1]['TLR'][str(tlr_index)]['resource_type'] = tlr_spec['resource_type']  # noqa
            spec['PLR'][1]['TLR'][str(tlr_index)]['id'] = tlr_spec['id']
            spec['PLR'][1]['TLR'][str(tlr_index)]['LS'] = {}
            for ls_index, ls in enumerate(tlr_spec.get('LS', [])):
                ls_index += 1
                ls_spec = tlr_spec['LS'][ls]
                spec['PLR'][1]['TLR'][str(tlr_index)]['LS'][str(ls_index)] = {}
                spec['PLR'][1]['TLR'][str(tlr_index)]['LS'][str(ls_index)]['display_name'] = ls_spec['display_name']  # noqa
                spec['PLR'][1]['TLR'][str(tlr_index)]['LS'][str(ls_index)]['url'] = ls_spec['url']  # noqa
                spec['PLR'][1]['TLR'][str(tlr_index)]['LS'][str(ls_index)]['resource_type'] = ls_spec['resource_type']  # noqa
                spec['PLR'][1]['TLR'][str(tlr_index)]['LS'][str(ls_index)]['id'] = ls_spec['id']  # noqa
                if 'LSP' in ls_spec:
                    spec['PLR'][1]['TLR'][str(tlr_index)]['LS'][str(ls_index)]['LSP'] = {}  # noqa
                    for lsp_index, lsp in enumerate(ls_spec['LSP']):
                        lsp_index += 1
                        lsp_spec = ls_spec['LSP'][lsp]
                        spec['PLR'][1]['TLR'][str(tlr_index)]['LS'][str(ls_index)]['LSP'][str(lsp_index)] = {}  # noqa
                        spec['PLR'][1]['TLR'][str(tlr_index)]['LS'][str(ls_index)]['LSP'][str(lsp_index)]['display_name'] = lsp_spec['display_name']  # noqa
                        spec['PLR'][1]['TLR'][str(tlr_index)]['LS'][str(ls_index)]['LSP'][str(lsp_index)]['url'] = lsp_spec['url']  # noqa
                        spec['PLR'][1]['TLR'][str(tlr_index)]['LS'][str(ls_index)]['LSP'][str(lsp_index)]['resource_type'] = lsp_spec['resource_type']  # noqa
                        spec['PLR'][1]['TLR'][str(tlr_index)]['LS'][str(ls_index)]['LSP'][str(lsp_index)]['id'] = lsp_spec['id']  # noqa
                        spec['PLR'][1]['TLR'][str(tlr_index)]['LS'][str(ls_index)]['LSP'][str(lsp_index)]['vm_ip'] = lsp_spec['vm_ip']  # noqa
                        spec['PLR'][1]['TLR'][str(tlr_index)]['LS'][str(ls_index)]['LSP'][str(lsp_index)]['vm_uuid'] = lsp_spec['vm_uuid']  # noqa
        new_spec = {'spec': spec}
        specs.append(new_spec)
    return specs


def compact_to_bulk(uid, compactdata):
    compactdata = copy.deepcopy(compactdata)
    topo_object = expander.Topology()
    json_dump('COMPACT', uid, compactdata)
    workload_list = topo_object.convert_ui_schema_to_workload_list(compactdata)
    json_dump('WORKLOAD_LIST', uid, workload_list)
    workload_dict = topo_object.list_to_dict(workload_list)
    json_dump('WORKLOAD_DICT', uid, workload_dict)
    workload_schema = topo_object.generate_missing_workloads(workload_dict)
    json_dump('WORKLOAD_SCHEMA', uid, workload_schema)
    return workload_schema


def bulk_to_compact(bulkdata, compactdata):
    topo_object = expander.Topology()
    return topo_object.merge_dicts(bulkdata, compactdata, bulkdata, '')


def _get_bulk_state(uid):
    pending = topo.bulkdict.get(uid, '_pending')
    status = topo.bulkdict.get(uid, 'status')
    if pending == 0 and status == 'INPROGRESS':
        status = 'SUCCESS'
        topo.bulkdict.set(uid, 'status', 'SUCCESS')
    topo.bulkdict.dump()
    return {'_pending': pending, 'status': status}


def _get_bulk_api(uid):
    if uid:
        _get_bulk_state(uid)
        res = topo.bulkdict.get(uid)
    else:
        res = topo.bulkdict.get()
    return res


def configure_testbed(testbed, num_threads):
    global topo
    config.set_auth_config(testbed)
    topo = topology.Topology(testbed, num_threads)
    topo.inventory = _get_inventory_api()
    return topo


def _get_inventory_api():
    global invdict
    if invdict is None:
        fabric_nodes = get_fabric_nodes(resource_type='HostNode')
        invdict = inventory.Inventory.build_inventory(fabric_nodes)
    return invdict
