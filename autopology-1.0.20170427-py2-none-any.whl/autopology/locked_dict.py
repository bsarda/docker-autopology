import collections
import json
import logging
import sys
import threading

log = logging.getLogger('autopology')


class LockedDict(object):

    def __init__(self, name):
        self.name = name
        self.cache = {}
        self.lock = threading.Lock()
        self.count_lock = threading.Lock()
        self.on_set_queues = collections.defaultdict(list)

    def log(self, msg):
        log.debug("|| %8s || %s" % (self.name[:8], msg))

    def _update_count(self, *args):
        args = list(args)
        val = int(args.pop())
        key = args.pop()
        args = [str(x) for x in args]
        self.log("Updating %s/%s: %s" % ('/'.join(args), key, val))
        if not args:
            raise ValueError("Updating %s to %s not allowed" % (args, val))
        self.count_lock.acquire()
        try:
            d = self.cache
            for k in args:
                if k not in d:
                    d[k] = {}
                d = d[k]
            if key not in d:
                d[key] = 0
            d[key] += val
        except Exception as e:
            log.error("Updating %s/%s to %s ... failed: %s" %
                      ('/'.join(args), key, val, e))
        finally:
            self.count_lock.release()

    def increment(self, *args):
        """
        Increments the counter at the given path by 1 or sets it to 1

        >>> x = LockedDict('doctest')
        >>> x.get('a', 'b')
        >>> x.increment('a', 'b')
        1
        >>> x.get('a', 'b')
        1
        >>> x.increment('a', 'b')
        2
        """
        update_args = list(args) + [1]
        self._update_count(*update_args)
        return self.get(*args)

    def decrement(self, *args):
        """
        Decrements the counter at the given path by 1 or sets it to -1

        >>> x = LockedDict('doctest')
        >>> x.get('a', 'b')
        >>> x.decrement('a', 'b')
        -1
        >>> x.get('a', 'b')
        -1
        >>> x.decrement('a', 'b')
        -2
        """
        update_args = list(args) + [-1]
        self._update_count(*update_args)
        return self.get(*args)

    def append(self, *args):
        """
        Sets an element at the given path

        >>> x = LockedDict('doctest')
        >>> x.append('a', 1)
        [1]
        >>> x.append('a', 2)
        [1, 2]
        >>> x.cache
        {'a': [1, 2]}
        """
        args = list(args)
        val = args.pop()
        args = [str(x) for x in args]
        if not args:
            raise ValueError
        self.log("Appending %s to %s" % ('/'.join(args), val))
        self.lock.acquire()
        try:
            d = self.cache
            for k in args[:-1]:
                if k not in d:
                    d[k] = {}
                d = d[k]
            if args[-1] in d:
                d[args[-1]].append(val)
            else:
                d[args[-1]] = [val]
        finally:
            self.lock.release()
        # pprint.pprint(self.cache)
        return self.get(*args)

    def clear(self, *args):
        """
        Fetches the value and deletes the key

        >>> x = LockedDict('doctest')
        >>> x.append('a', 1)
        [1]
        >>> x.append('a', 2)
        [1, 2]
        >>> x.cache
        {'a': [1, 2]}
        >>> x.clear('a')
        [1, 2]
        >>> x.cache
        {}
        """
        args = list(args)
        args = [str(x) for x in args]
        if not args:
            raise ValueError
        self.log("Clearing %s" % ('/'.join(args)))
        self.lock.acquire()
        try:
            d = self.cache
            for k in args[:-1]:
                if k not in d:
                    d[k] = {}
                d = d[k]
            if args[-1] in d:
                val = d[args[-1]]
                del d[args[-1]]
                return val
            else:
                raise ValueError
        finally:
            self.lock.release()

    def set(self, *args):
        """
        Sets an element at the given path

        >>> x = LockedDict('doctest')
        >>> x.set('a', {'b': 1})
        {'b': 1}
        >>> x.get('a')
        {'b': 1}
        >>> x.get('a', 'b')
        1
        >>> x.set('a', 'b', 2)
        2
        >>> x.get('a', 'b')
        2
        >>> x.get('a', 'c')
        """
        args = list(args)
        val = args.pop()
        args = [str(x) for x in args]
        if not args:
            raise ValueError
        self.log("Setting %s to %s" % ('/'.join(args), val))
        self.lock.acquire()
        try:
            d = self.cache
            for k in args[:-1]:
                if k not in d:
                    d[k] = {}
                d = d[k]
            if args[-1] in d and type(val) is dict:
                d[args[-1]].update(val)
            else:
                d[args[-1]] = val
            key = tuple(args)
            for func in self.on_set_queues[key]:
                log.debug("DeQueueing %s for %s" % (key, func))
                func()
            del self.on_set_queues[key]
        finally:
            self.lock.release()
        # pprint.pprint(self.cache)
        return self.get(*args)

    def on_set(self, func, *args):
        """
        Given func is queue until the path referred by *args is set

        >>> x = LockedDict("doctest")
        >>> def foo():
        ...      raise ValueError
        >>> x.get('a', 'c')
        >>> x.on_set(foo, 'a', 'b')
        >>> x.set('a','b', 1)
        Traceback (most recent call last):
        ...
        ValueError
        """
        self.lock.acquire()
        try:
            if not self.get(*args):
                key = tuple(args)
                log.debug("Queueing %s for %s" % (key, func))
                self.on_set_queues[key].append(func)
            else:
                func()
        finally:
            self.lock.release()

    def flush_on_set_queues(self):
        """
        Flushes all the queues assuming that the key is set

        >>> x = LockedDict("doctest")
        >>> def foo():
        ...      raise ValueError
        >>> x.on_set(foo, 'a', 'b')
        >>> x.flush_on_set_queues()
        Traceback (most recent call last):
        ...
        ValueError
        """
        self.lock.acquire()
        try:
            for key, lst_of_funcs in self.on_set_queues.items():
                for func in lst_of_funcs:
                    self.log("Flushing %s for %s" % (key, func))
                    func()
                del self.on_set_queues[key]
        finally:
            self.lock.release()

    def get_on_set_queue_state(self):
        """
        Returns the number of on_set queues and the total size of the queueus

        >>> x = LockedDict("doctest")
        >>> def foo():
        ...      raise ValueError
        >>> x.on_set(foo, 'a', 'b')
        >>> x.get_on_set_queue_state()
        (1, 1)
        """

        no_of_queues = len(self.on_set_queues.keys())
        total_size = sum([len(q) for k, q in self.on_set_queues.items()])
        return no_of_queues, total_size

    def print_on_set_queue_state(self):
        """
        Prints the number of on_set queues and the total size of the queueus
        """
        log.warn("on_set_queue state: no_of_queues=%s, total_size=%s" %
                 self.get_on_set_queue_state())

    def dump(self):
        """
        Dumps the content of the dict to json file
        """
        fname = '/tmp/autopology-%s.json' % self.name
        with open(fname, 'w') as f:
            json.dump(self.cache, f, sort_keys=True, indent=4)
        fname = '/tmp/autopology-%s-queues.json' % self.name
        with open(fname, 'w') as f:
            json.dump([[k, str(v)] for k, v in self.on_set_queues.items()],
                      f, sort_keys=True, indent=4)

    def get(self, *args):
        """
        Gets an element at the given path

        >>> x = LockedDict('doctest')
        >>> x.set('a', {'b': {'c': 1}})
        {'b': {'c': 1}}
        >>> x.get('a')
        {'b': {'c': 1}}
        >>> x.get('a', 'b')
        {'c': 1}
        >>> x.get('a', 'b', 'c')
        1
        """
        args = [str(x) for x in args]
        # XXX self.lock.acquire()
        try:
            if len(args) == 0:
                return self.cache
            # TRACE self.log("Getting %s ..." % ('/'.join(args)))
            d = self.cache
            for k in args[:-1]:
                if k in d:
                    d = d[k]
                else:
                    d = {}
                    break
            res = d.get(args[-1])
            # TRACE self.log("Getting %s: returned %s" %
            # TRACE          ('/'.join(args), str(res)[:32]))
            return res
        finally:
            # XXX self.lock.release()
            pass

if __name__ == '__main__':
    import argparse
    import doctest

    parser = argparse.ArgumentParser()
    parser.add_argument('--doctest', action='store_true', default=False)
    args = parser.parse_args(sys.argv[1:])
    if args.doctest:
        doctest.testmod(optionflags=doctest.ELLIPSIS)
        sys.exit(0)
