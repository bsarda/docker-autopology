window.api = {
    getToken: function() {
      var me = this;
      $.ajax({
          url: data.URL + "api/v2/csrf_token/",
          type: "GET",
          cache: false
      })
      .done(function(response) {
          me.setAjaxHeader(response);
      })
      .fail(function(jqXHR, textStatus, errorThrown) {
          console.error("Failed to obtain token!");
      });
    },
    setAjaxHeader: function(token) {
      $.ajaxSetup({
          headers: { 'X-CSRFToken': token }
      });
    },
    getManagerIp: function() {
        $.ajax({
            url: data.URL + "api/v2/manager-ip/",
            type: "GET",
            cache: false
        })
        .done(function(response) {
            ui.setManagerIp(response);
        })
        .fail(function(jqXHR, textStatus, errorThrown) {
            console.log("error");
        });
    },
    getInventory: function() {
        $.ajax({
            url: data.URL + "api/v2/inventory/",
            contentType: "application/json; charset=utf-8",
            type: "GET",
            cache: false,
            dataType: "json"
        })
        .done(function(response) {
            data.parseHvData(response);
        })
        .fail(function(jqXHR, textStatus, errorThrown) {
            console.log("error");
        });
    },
    deploy: function(topology) {
        $(".status").removeClass().addClass("status inprogress");
        $.ajax({
            url: data.URL + "api/v2/topologies/",
            crossDomain: true,
            contentType: "application/json; charset=utf-8",
            type: "POST",
            data: JSON.stringify(topology),
            dataType: "json"
        })
        .done(function(response) {
            api.pollForUpdates(response.id, "DEPLOY");
            api.getExistingTopologies(response.id);
        })
        .fail(function(jqXHR, textStatus, errorThrown) {
            $(".status").removeClass().addClass("status failure");
            ui.toast.show({
              target: $(".canvas-toolbar")[0],
              type: "danger",
              text: errorThrown
            });
        });
    },
    delete: function(topologyId) {
        $(".status").removeClass().addClass("status inprogress");
        $.ajax({
            url: data.URL + "api/v2/topologies/" + topologyId,
            type: "DELETE",
            crossDomain: true,
            contentType: "application/json; charset=utf-8",
            dataType: "json"
        })
        .done(function(response) {
            api.pollForUpdates(response.id, "DELETE");
            // api.getExistingTopologies(response.id);
        })
        .fail(function(jqXHR, textStatus, errorThrown) {
            $(".status").removeClass().addClass("status failure");
            ui.toast.show({
              target: $(".canvas-toolbar")[0],
              type: "danger",
              text: errorThrown
            });
        });
    },
    getExistingTopologies: function(currId) {
         $.ajax({
             url: data.URL + "api/v2/topologies/",
             crossDomain: true,
             contentType: "application/json; charset=utf-8",
             type: "GET",
             cache: false,
             dataType: "json"
         })
         .done(function(response){
            ui.updateTopoDropdown(currId, response);
            data.existingTopologies = response;
         })
         .fail(function(jqXHR, textStatus, errorThrown){
             console.log("Request error: ", textStatus, errorThrown);
         });
    },
    pollForUpdates: function(id, action) {
        var me = this;
        setTimeout(function() {
            $.ajax({
                 url: data.URL + "api/v2/topologies/" + id,
                 crossDomain: true,
                 contentType: "application/json; charset=utf-8",
                 cached: false,
                 dataType: "json"
             })
            .done(function(response) {
                var newCls = response.status.toLowerCase();
                data.updateSchema(response);
                $(".status").removeClass().addClass("status " + newCls);
                if (response.status == "INPROGRESS") {
                     me.pollForUpdates(id, action);
                }
                if (action === "DELETE") {
                    // go to new template
                    $("#saved-topo").val("new-topology");
                    vis.resetCanvas();
                }
                api.getExistingTopologies(id);
            })
            .fail(function(jqXHR, textStatus, errorThrown) {
                console.log("Request error: ", textStatus, errorThrown);
            });
         }, 3000);
    }
};
