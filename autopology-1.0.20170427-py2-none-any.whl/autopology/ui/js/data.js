window.data = {
    URL: "/",
    MANAGER: "",
    existingTopologies: {},
    schema: {},
    hypervisors: {},
    objSpec: {
        LS: {
            keys: [{
                key: "replication_mode",
                defaultVal: "MTEP"
            }]
        },
        TLR: {
            keys: [{
                key: "route_advertisement",
                defaultVal: "enabled"
            }]
        },
        VLS: {
            keys: [{
                key: "VLANID",
                defaultVal: ""
            }, {
                key: "REMOTEAS",
                defaultVal: ""
            }, {
                key: "NBRIP",
                defaultVal: ""
            }]
        },
        PLR: {
            keys: []
        },
        VM: {
            keys: []
        }
    },
    editMenuMap: {
        TLR: {
            route_advertisement: {
                label: "Route Advertisement",
                values: ["enabled", "disabled"]
            }
        },
        LS: {
            replication_mode: {
                label: "Replication Mode",
                values: ["MTEP", "SOURCE"]
            }
        },
        VLS: {
            VLANID: {
                label: "VLAN Id",
                values: []
            },
            REMOTEAS:{
                label: "BGP Remote AS Number",
                values: []
            },
            NBRIP: {
                label: "BGP Neighbor IP",
                values: []
            }
        }
    },
    getDefautObj: function(type) {
        var nodeSpec = {};
        this.objSpec[type].keys.forEach(function(o) {
            nodeSpec[o.key] = o.defaultVal;
        });
        return nodeSpec;
    },
    getCountByType: function(type){
        var count = 0;
        for (var node in this.schema) {
            if (this.schema[node]["resource_type"] === type) {
                count++;
            }
        }
        return count;
    },
    getDepthById: function(id) {
        switch (data.schema[id].resource_type) {
            case "PLR":
                return 0;
            case "TLR":
                return 1;
            case "LS":
                return 2;
            case "VM":
                return 3;
            case "VLS":
                return 1;
        }
    },
    prepareDeployData: function(topologyName) {
        var topology = {
            tag: topologyName,
            spec: {}
        };
        var svgRect = $("svg")[0].getBoundingClientRect();
        for(var nodeId in this.schema) {
            if (!this.schema[nodeId]['parent']) {
                if (!topology['spec'][this.schema[nodeId]['resource_type']]) {
                    topology['spec'][this.schema[nodeId]['resource_type']] = {}
                }
                var idx = Object.keys(topology['spec'][this.schema[nodeId]['resource_type']]).length + 1;
                topology['spec'][this.schema[nodeId]['resource_type']][idx] = _.omit(this.schema[nodeId], ['resource_type', 'parent']);
                topology['spec'][this.schema[nodeId]['resource_type']][idx]['borathonid'] = nodeId;
                if (this.schema[nodeId]['resource_type'] !== 'FN') {
                    topology['spec'][this.schema[nodeId]['resource_type']][idx]['x'] = d3.transform(d3.select("#" + nodeId).attr("transform")).translate[0]/svgRect.width;
                    topology['spec'][this.schema[nodeId]['resource_type']][idx]['y'] = d3.transform(d3.select("#" + nodeId).attr("transform")).translate[1]/svgRect.height;
                }
            }
        }
        for(var nodeId in this.schema) {
            var resourceType = this.schema[nodeId]['resource_type'];
            if (resourceType === "VLS" || resourceType === "TLR") {
                if (!topology['spec']["PLR"]["1"][resourceType]) {
                    topology['spec']["PLR"]["1"][resourceType] = {}
                }
                var idx = Object.keys(topology['spec']["PLR"]["1"][resourceType]).length + 1;
                topology['spec']["PLR"]["1"][resourceType][idx] = _.omit(this.schema[nodeId], ['resource_type', 'parent']);
                topology['spec']["PLR"]["1"][resourceType][idx]['borathonid'] = nodeId;
                topology['spec']["PLR"]["1"][resourceType][idx]['x'] = d3.transform(d3.select("#" + nodeId).attr("transform")).translate[0]/svgRect.width;
                topology['spec']["PLR"]["1"][resourceType][idx]['y'] = d3.transform(d3.select("#" + nodeId).attr("transform")).translate[1]/svgRect.height
            }
        }
        for(var nodeId in this.schema) {
            var resourceType = this.schema[nodeId]['resource_type'];
            for (var tlrIdx in topology['spec']['PLR']['1']['TLR']) {
                if (topology['spec']['PLR']['1']['TLR'][tlrIdx]['borathonid'] === this.schema[nodeId]['parent']) {
                    if (!topology['spec']['PLR']['1']['TLR'][tlrIdx][resourceType]) {
                        topology['spec']['PLR']['1']['TLR'][tlrIdx][resourceType] = {};
                    }
                    var idx = Object.keys(topology['spec']['PLR']['1']['TLR'][tlrIdx][resourceType]).length + 1;
                    topology['spec']['PLR']['1']['TLR'][tlrIdx][resourceType][idx] = _.omit(this.schema[nodeId], ['resource_type', 'parent']);
                    topology['spec']['PLR']['1']['TLR'][tlrIdx][resourceType][idx]['borathonid'] = nodeId;
                    topology['spec']['PLR']['1']['TLR'][tlrIdx][resourceType][idx]['x'] = d3.transform(d3.select("#" + nodeId).attr("transform")).translate[0]/svgRect.width;
                    topology['spec']['PLR']['1']['TLR'][tlrIdx][resourceType][idx]['y'] = d3.transform(d3.select("#" + nodeId).attr("transform")).translate[1]/svgRect.height
                }
            }
        }
        for(var nodeId in this.schema) {
            var resourceType = this.schema[nodeId]['resource_type'],
                parent = this.schema[nodeId]['parent'];
            if (resourceType === "VM") {
                var targetLS = this.nestedKeySearch(topology, "borathonid", parent)[0];
                if (targetLS["VNIC"]) {
                    var vmCount = Object.keys(targetLS["VNIC"]).length + 1;
                    targetLS["VNIC"][vmCount] = {};
                    Object.assign(targetLS["VNIC"][vmCount], {
                        UUID: this.getVmNodeByIp(this.schema[nodeId]['hv_ip'], this.schema[nodeId]['vm_ip'])['uid'],
                        borathonid: nodeId,
                        x: d3.transform(d3.select("#" + nodeId).attr("transform")).translate[0]/svgRect.width,
                        y: d3.transform(d3.select("#" + nodeId).attr("transform")).translate[1]/svgRect.height
                    });
                } else {
                    targetLS["VNIC"] = {};
                    targetLS["VNIC"]["1"] = {};
                    Object.assign(targetLS["VNIC"]["1"], {
                        UUID: this.getVmNodeByIp(this.schema[nodeId]['hv_ip'], this.schema[nodeId]['vm_ip'])['uid'],
                        borathonid: nodeId,
                        x: d3.transform(d3.select("#" + nodeId).attr("transform")).translate[0]/svgRect.width,
                        y: d3.transform(d3.select("#" + nodeId).attr("transform")).translate[1]/svgRect.height
                    });
                }
            }
        }
        api.deploy(topology);
    },
    getVmNodeByIp: function(hvIp, vmIp) {
        for(var hv in this.hypervisors) {
            if (this.hypervisors[hv]['ip'] === hvIp) {
                for (var vm in this.hypervisors[hv]["vm"]) {
                    if (this.hypervisors[hv]["vm"][vm]["ip"] === vmIp) {
                        return this.hypervisors[hv]["vm"][vm];
                    }
                }
            }
        }
    },
    addFabricNode: function(nodeId, nodeType, nodeIp) {
        this.schema[nodeId] = {
            type: nodeType,
            hostnode: nodeIp,
            resource_type: "FN"
        };
    },
    copyNodeData: function(nodeId, newNodeId) {
        data.schema[newNodeId] = Object.assign({}, data.schema[nodeId]);
    },
    removeNodeData: function(nodeId) {
        if (data.schema[nodeId]["resource_type"] === "VM") {
            data.updateNic("vm-" + data.schema[nodeId]["vm_ip"].replace(/\./gi, "_"), data.schema[nodeId]["hv_ip"], true);
        }
        delete data.schema[nodeId];
    },
    setRelationship: function(elem1Id, elem2Id) {
        var parent, child;
        if (this.getDepthById(elem1Id) > this.getDepthById(elem2Id)) {
            parent = elem2Id;
            child = elem1Id;
        } else {
            parent = elem1Id;
            child = elem2Id;
        }
        this.schema[child]['parent'] = parent;
    },
    updateSchema: function(topology) {
        (function nestedKeyQuery(topology) {
            for (var key in topology) {
                if (typeof topology[key] === "object") {
                    nestedKeyQuery(topology[key]);
                }
                if (key === "borathonid") {
                    Object.assign(this.data.schema[topology[key]], _.omit(topology, ['borathonid']));
                }
            }
        })(topology);
    },
    parseHvData: function(hvData) {
        for(var hvIdx in hvData["hv"]) {
            var hvId = "node_" + uuid();
            this.hypervisors[hvId] = {
                ip: hvData["hv"][hvIdx]["ip"],
                os_type: hvData["hv"][hvIdx]["os_type"],
                vm: hvData["hv"][hvIdx]["vm"]
            }
            for (vm in this.hypervisors[hvId]["vm"]) {
                this.hypervisors[hvId]["vm"][vm]["availableNics"] = 9;
            }
        }
        ui.hvMenu.renderVms(this.hypervisors);
    },
    updateNic: function(domId, hvIp, isIncrement) {
        var vmIp = domId.split("-")[1].replace(/_/gi, ".");
        for(hv in this.hypervisors) {
            if (this.hypervisors[hv].ip === hvIp) {
                for (vm in this.hypervisors[hv]["vm"]) {
                    if (this.hypervisors[hv]["vm"][vm]["ip"] === vmIp) {
                        this.hypervisors[hv]["vm"][vm]["availableNics"] -= (isIncrement ? -1 : 1);
                        ui.hvMenu.updateNicCount(domId, this.hypervisors[hv]["vm"][vm]["availableNics"]);
                        if (!isIncrement) {
                            ui.drawNode("VM", vmIp, hvIp);
                        }
                    }
                }
            };
        }
        return;
    },
    nestedKeySearch: function(obj, key, val) {
        var me = this;
        if (_.has(obj, key) && obj[key] === val)
            return [obj];
        return _.flatten(_.map(obj, function(v) {
            return typeof v == "object" ? me.nestedKeySearch(v, key, val) : [];
        }), true);
    },
    // resetData: function() {
    //     this.schema = {};
    // },
    loadData: function(spec) {
        var me = this;
        if (_.keys(spec).length > 0) {
            (function dfs(node) {
                for (var key in node) {
                    if (node.hasOwnProperty('borathonid')) {
                        me.schema[node["borathonid"]] = {
                            url: node["url"],
                            display_name: node["display_name"]
                        };
                    }
                    if (typeof node[key] === "object") {
                        dfs(node[key]);
                    }
                }
            })(spec);
        } else {
            this.schema = {};
        }
    }
}
