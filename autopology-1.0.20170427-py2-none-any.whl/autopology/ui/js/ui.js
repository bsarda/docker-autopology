// XXX TODO: Avoid using template string as broweser support w/ IE is limited
window.ui = {
    addHandler: function() {
        $("#saved-topo").on('change', function() {
            vis.resetCanvas();
            // data.resetData();
            if ($(this).val() !== "new-topology") {
                data.loadData(data.existingTopologies[$(this).val()].spec);
                vis.loadGraph(data.existingTopologies[$(this).val()].spec);
                var status = data.existingTopologies[$(this).val()].spec.status || "FAILURE";
                $(".status").removeClass().addClass("status " + status.toLowerCase());
                $("#deploy").attr("role", "delete").attr('disabled', true);
                // uncomment when delete function is up & running [more changes required though]
                /*if (status === "SUCCESS" || status === "FAILURE") {
                    $("#deploy").attr("role", "delete").text("Delete").removeClass("deploy-btn").addClass('delete-btn');
                } else {
                    $("#deploy").attr("role", "deploy").text("Deploy").removeClass("delete-btn").addClass('deploy-btn');
                }*/
            } else {
                $(".status").removeClass().addClass("status");
                $("#deploy").attr("role", "deploy").attr('disabled', false);
                data.loadData({});
            }
            ui.chkCountConstraints();
        });
        $("#reset").on('click', function() {
            vis.resetCanvas();
            data.loadData({});
            // data.resetData();
            ui.chkCountConstraints();
        });
        $("#topology-name").on('keydown', function(e) {
            if (e.which === 32 || (e.which === 189 && e.shiftKey === true))
            return false;
        });
    },
    setManagerIp: function(ip) {
        $("#manager-ip").text(ip).attr("href", "https://" + ip);
    },
    ctxMenu: {
        nodeId: null
    },
    hideCtxMenu: function() {
        if (this.ctxMenu.nodeId) {
            $(".ctx-menu").removeClass("visible").addClass("hidden");
            this.saveNodeData(this.ctxMenu.nodeId);
            this.ctxMenu.nodeId = null;
        }
    },
    openCtxMenu: function (node) {
        var nodeRect = d3.select("#" + node.id).node().getBoundingClientRect(),
            targetPos = [nodeRect.left + nodeRect.width, nodeRect.top + nodeRect.height/2];

        vis.clearSelection();
        ui.setToolbarState(false);

        $(".ctx-menu").css({position: 'fixed', left: targetPos[0], top: targetPos[1]});
        $(".ctx-menu").removeClass("hidden").addClass("visible");

        $(".ctx-menu .ctx-menu-body").empty();
        ui.getCtxMenuItems(data.schema[node.id]);

        ui.ctxMenu.nodeId = node.id;
    },
    setToolbarState: function(isEnabled) {
        if (isEnabled) {
            $(".canvas-toolbar .canvas-toolbar-btn#copy").removeClass('disabled');
            $(".canvas-toolbar .canvas-toolbar-btn#delete").removeClass('disabled');
        } else {
            $(".canvas-toolbar .canvas-toolbar-btn#copy").addClass('disabled');
            $(".canvas-toolbar .canvas-toolbar-btn#delete").addClass('disabled');
        }
    },
    chkCountConstraints: function() {
        if (data.getCountByType("PLR") >= 1) {
            $(".icon-ct[type='PLR']").addClass('disabled');
        } else {
            $(".icon-ct[type='PLR']").removeClass('disabled');
        }
    },

    getCtxMenuItems: function(nodeData) {
        var menuMap = data.editMenuMap[nodeData["resource_type"]];
        for (menukey in menuMap) {
            var input,
            label = "<label>" + menuMap[menukey]["label"] + ": </label>";
            if (menuMap[menukey].values.length === 0) {
                var value = nodeData[menukey];
                input = "<input type='text' class='input-el' value='" + value + "'/>";
            } else {
                input = "<div class='select'><select class='input-el'>";
                    menuMap[menukey]["values"].forEach(function(value) {
                        if (nodeData[menukey] === value) {
                            input += "<option value='" + value + "'  selected='selected'>" + value + "</option>";
                        } else {
                            input += "<option value='" + value + "'>" + value + "</option>";
                        }
                    });
                input += "</select></div>";
            }
            $(".ctx-menu .ctx-menu-body").append("<div class='menu-item' key='" + menukey +  "'>" + label + input + "</div>");
        }
        if (nodeData['url']) {
            $(".ctx-menu .mp-link").removeClass('disabled');
            $(".ctx-menu .mp-link").attr("href", nodeData['url']);
        } else {
            $(".ctx-menu .mp-link").addClass('disabled');
            $(".ctx-menu .mp-link").attr("href", "#");
        }
    },

    saveNodeData: function(nodeId) {
        $(".menu-item").each(function(id, el) {
            var key = el.getAttribute('key');
            var val = $(el).find(".input-el").val();
            data.schema[nodeId][key] = val;
        });
    },

    toast: {
        show: function (config) {
            var dom = "<div class='toast " + config.type + "'>" + config.text + "</div>";
            $(config.target).append(dom);
            $(".toast").on("animationend webkitAnimationEnd oAnimationEnd MSAnimationEnd", function() {
                 $(this).remove();
            })
        }
    },

    copyForm: {
        isVisible: false,
        showHide: function() {
            this.isVisible ? $(".copy-form").fadeOut() : $(".copy-form").fadeIn();
            if (!this.isVisible) {
                $(".copy-form input").focus().val('');
            }
            this.isVisible = !this.isVisible;
        },
        onSubmit: function() {
            vis.copyNodes(Number($(".copy-form input").val()));
            this.showHide();
        }
    },

    hideNodeDlg: function() {
        $("#node-dlg .modal-dialog").removeClass('in');
        $(".modal-backdrop").removeClass('in').css('display', 'none');
        $("#node-dlg").css('display', 'none');
    },

    showNameDlg: function() {
        $("#name-dlg").show();
        $("#name-dlg input").val('');
        $("#name-dlg .modal-dialog").addClass('in');
        $(".modal-backdrop").addClass('in').show();
    },

    updateTopoDropdown: function(currId, topologies) {
        $("#saved-topo").empty();
        $("#saved-topo").append('<option value="new-topology">New Topology</option>');
        for(key in topologies) {
            $("#saved-topo").append($("<option></option>")
                .attr("value", key)
                .attr("id", key)
                .text(topologies[key].tag));
        }
        $("#saved-topo").val(currId);
    },

    hvMenu: {
        renderVms: function(hypervisors) {
            for (hv in hypervisors) {
                $hvDom = `<div id="${"hv-" + hypervisors[hv]["ip"].replace(/\./gi, "_")}" class="dropdown-item ${this.getHvClsName(hypervisors[hv]["os_type"])}">
                <span class="ip">${hypervisors[hv]["ip"]}</span>
                <ul class="list vm-list"></ul>
                </div>`;
                if (hypervisors[hv]["os_type"] === "ESXI") {
                    $(".hv-menu .dropdown-divider").before($hvDom);
                } else {
                    $(".hv-menu .dropdown-divider").after($hvDom);
                }
                for (var vm in hypervisors[hv]["vm"]) {
                    $vmDom = `<li id="${"vm-" + hypervisors[hv]["vm"][vm]["ip"].replace(/\./gi, "_")}">
                    <span class="vm-name">${hypervisors[hv]["vm"][vm]["name"]}</span>
                    <span class="badge badge-info">9</span>
                    </li>`;
                    $("#hv-" + hypervisors[hv]["ip"].replace(/\./gi, "_")).find("ul.vm-list").append($vmDom);

                }
            }
            $(".dropdown-item").on('click', function(evt) {
                ui.hvMenu.expandHvItem(this, evt);
            });
            $(".dropdown-item li").on('click', function(evt) {
                data.updateNic(this.id, $(this).parents(".dropdown-item").attr("id").split("-")[1].replace(/_/gi, "."), false);
            });
        },
        getHvClsName: function(type) {
            switch(type) {
                case "ESXI":
                    return "esx";
                case "RHELKVM":
                case "UBUNTUKVM":
                    return "kvm";
            }
        },
        expandHvItem: function(el, evt) {
            $(".hv-menu").find(".dropdown-item").each(function(idx, item) {
                $(item).removeClass('expanded');
            });
            $(el).toggleClass('expanded');
            evt.stopPropagation();
        },
        updateNicCount: function(domId, nicCount) {
            $("#" + domId).find('.badge-info').text(nicCount);
            nicCount === 0 ? $("#" + domId).addClass('disabled') : $("#" + domId).removeClass('disabled');
        },
        hide: function() {
            $("div.icon-ct[type='VM']").removeClass('open');
        }
    },

    drawNode: function(resourceType, vmIp, hvIp) {
        var nodeId = "node_" + uuid();
        data.schema[nodeId] = data.getDefautObj(resourceType);
        data.schema[nodeId]["resource_type"] = resourceType;
        if (vmIp) {
            data.schema[nodeId]["vm_ip"] = vmIp;
        }
        if (hvIp) {
            data.schema[nodeId]["hv_ip"] = hvIp;
        }
        graph.addNode(nodeId, resourceType.toLowerCase(), resourceType, getLastNodePos());
    }
}

ui.addHandler();

$("body").append(`
    <div class='ctx-menu hidden'>
    <div class='ctx-menu-body'></div>
    <div class='ctx-menu-links'>
    <a href='#' class='build-link'>Build link</a>
    <span class='spacer'></span>
    <a href='#' class='mp-link disabled' target='_blank'>Show in MP</a>
    </div>
    <div class='ctx-menu-footer'></div>
    </div>`);

$(".sidebar").on('click', "div.icon-ct", function(evt) {
    if ($(this).attr('type') !== 'VM') {
        ui.drawNode(this.getAttribute("type"))
    } else {
        $(this).toggleClass('open');
    }
});

$(".build-link").on('click', function(evt) {
    vis.startDragLink(ui.ctxMenu.nodeId);
});

$("#copy").on('click', function() {
    ui.copyForm.showHide();
});

$(".copy-form .copy-num-btn").on('click', function() {
    ui.copyForm.onSubmit();
});

$("#delete").on('click', function() {
    vis.deleteNodes();
});

$("#settings").on('click', function() {
    $(this).parent(".settings-menu").toggleClass('open');
});

$("#deploy").on('click', function() {
    switch ($(this).attr("role")) {
        case "deploy":
            $("#node-dlg").show();
            $("#node-dlg .modal-dialog").addClass('in');
            $(".modal-backdrop").addClass('in').show();
            return;
        case "delete":
            // delete happens
            api.delete($("#saved-topo").val());
    }
});

$("#node-configure-yes").on('click', function() {
    ui.hideNodeDlg();
    $("#node-config-dlg").show();
    $("#node-config-dlg .node-values").html('');
    $("#node-config-dlg input").val('');
    $("#node-config-dlg select option:selected").removeAttr('selected');
    $("#node-config-dlg .modal-dialog").addClass('in');
    $(".modal-backdrop").addClass('in').show();
});

$("#node-configure-no").on('click', function() {
    ui.hideNodeDlg();
    ui.showNameDlg();
});

$("#node-config-dlg .modal-footer > .btn").on('click', function() {
    $("#node-config-dlg .modal-dialog").removeClass('in');
    $(".modal-backdrop").removeClass('in').css('display', 'none');
    $("#node-config-dlg").css('display', 'none');
    ui.showNameDlg();
});

$("#name-dlg-deploy").on('click', function() {
    $("#name-dlg .modal-dialog").removeClass('in');
    $(".modal-backdrop").removeClass('in').css('display', 'none');
    $("#name-dlg").css('display', 'none');
    data.prepareDeployData($("#topology-name").val());
});

$(".node-values").on('click', 'span', function() {
    $(this).parent(".node-info").fadeOut("fast", function() {
        $(this).remove();
        delete data.schema[this.id];
    });
});

$("#add-node").on('click', function() {
    var nodeType = $("#node-config-dlg").find("select").find(":selected").text(),
        nodeIp = $("#node-config-dlg").find("input").val(),
        nodeId = "node_" + uuid();
    $("#node-config-dlg").find(".node-values").append("<span class='node-info' id='" + nodeId + "'>" + nodeType + " (" + nodeIp + ")" + "<span class='node-del'>&times;</span></span>");
    data.addFabricNode(nodeId, nodeType, nodeIp);
});

$(document).ready(function() {
    api.getToken();
    api.getManagerIp();
    api.getExistingTopologies("new-topology");
    api.getInventory();
});
