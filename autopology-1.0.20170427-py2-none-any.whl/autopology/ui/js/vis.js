var graph;
var NODE_RADIUS = 16;

window.vis = {
  dragNode: null,

  isClickableNode: function(node) {
    if (node.classList.contains('graph')) {
      return false;
    }
    if (node.classList.contains('node')) {
      return true;
    }
    return this.isClickableNode($(node).parent()[0]);
  },

  onVisClick: function(evt) {
    if (this.isClickableNode(evt.target)) {
      this.selectNode(evt.target);
      ui.setToolbarState(true);
    } else {
      this.clearSelection();
      ui.setToolbarState(false);
      if (ui.copyForm.isVisible) {
        ui.copyForm.showHide();
      }
    }
    ui.hideCtxMenu();
    ui.hvMenu.hide();
  },

  clearSelection: function() {
    d3.selectAll(".node").classed("selected", false);
  },

  selectNode: function(node) {
    var groupNode = this.getGroupEl(node);
    this.clearSelection();
    d3.select(groupNode).classed("selected", true);
  },

  getGroupEl: function(node) {
    if (node.classList.contains('node')) {
      return node;
    }
    return this.getGroupEl($(node).parent()[0]);
  },

  startDragLink: function(startNodeId) {
    this.dragNode = d3.select("#" + startNodeId);
    var t = d3.transform(this.dragNode.attr("transform")).translate;
    d3.select(".vis-ct")
      .append("line")
      .attr("class", "drag-link")
      .attr("x1", t[0])
      .attr("y1", t[1])
      .attr("x2", t[0])
      .attr("y2", t[1]);
    keepNodesOnTop();
    ui.hideCtxMenu();
  },

  moveDragLink: function() {
    if (vis.dragNode) {
      var t = d3.transform(vis.dragNode.attr("transform")).translate;
      d3.select(".drag-link")
        .attr("x1", t[0])
        .attr("y1", t[1])
        .attr("x2", d3.event.clientX - $("svg").offset().left)
        .attr("y2", d3.event.clientY - $("svg").offset().top);
    }
  },

  endDragLink: function() {
    if (vis.dragNode) {
      var targetNode = vis.checkIfValidLink([d3.event.clientX - $("svg").offset().left, d3.event.clientY - $("svg").offset().top]);
      if (targetNode) {
        // XXX TODO: check for VM connected to same LS
        var result = vis.checkIfDupVm(vis.dragNode.attr("id"), targetNode.id);
        if (result.isDup) {
          ui.toast.show({
            target: $(".canvas-toolbar")[0],
            type: "danger",
            text: `VM with IP: ${data.schema[result.vmId]["vm_ip"]} is already attached to this Logical Switch!`
          });
        } else {
          graph.addLink(vis.dragNode.attr('id'), targetNode.id, '');
          keepNodesOnTop();
          data.setRelationship(vis.dragNode.attr('id'), targetNode.id);
        }
      }
      d3.select(".drag-link").remove();
      vis.dragNode = null;
    }
  },

  checkIfDupVm: function(dragNodeId, targetNodeId) {
    var vmId, lsId, isDup = false,
      links = d3.selectAll("line.link").data();
    if (data.schema[dragNodeId]["resource_type"] === "VM" && data.schema[targetNodeId]["resource_type"] === "LS") {
      vmId = dragNodeId;
      lsId = targetNodeId;
    } else if (data.schema[dragNodeId]["resource_type"] === "LS" && data.schema[targetNodeId]["resource_type"] === "VM") {
      vmId = targetNodeId;
      lsId = dragNodeId;
    }
    if (vmId && lsId) {
      links.forEach(function(l, i) {
        if (l.source.id === lsId && data.schema[l.target.id]["resource_type"] === "VM") {
          if (data.schema[l.target.id]["vm_ip"] === data.schema[vmId]["vm_ip"]) {
            isDup = true;
          }
        } else if (l.target.id === lsId && data.schema[l.source.id]["resource_type"] === "VM") {
          if (data.schema[l.source.id]["vm_ip"] === data.schema[vmId]["vm_ip"]) {
            isDup = true;
          }
        }
      });
    }
    return {
      isDup: isDup,
      vmId: vmId,
      lsId: lsId
    };
  },

  checkIfValidLink: function(dragEndCoords) {
    var targetNode;
    d3.selectAll(".node").each(function(node) {
      var t = d3.transform(d3.select("#" + node.id).attr("transform")).translate,
        x1 = dragEndCoords[0],
        y1 = dragEndCoords[1],
        x2 = t[0],
        y2 = t[1];
      if (Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2) <= Math.pow(NODE_RADIUS * 2, 2)) {
          targetNode = node;
      }
    });
    return targetNode;
  },

  copyNodes: function(numCopy) {
    var root = this.getSelectedNode(),
      nodeId,
      count,
      resourceType,
      targetId,
      coords,
      srcToTargetMap = {},
      rootResourceType = data.schema[root.attr("id")]["resource_type"];
    if (rootResourceType === "PLR" || rootResourceType === "VM") {
      ui.toast.show({
        target: $(".canvas-toolbar")[0],
        type: "danger",
        text: `Nodetype: ${rootResourceType} can't be copied!`
      });
    } else {
      var subtree = vis.dfsNodes(root.attr("id"));
      subtree.nodes.forEach(function(nodeId) {
        for (count = 0; count < numCopy; count++) {
          newNodeId = "node_" + uuid();
          var o = {}; o[nodeId] = newNodeId;
          if (!srcToTargetMap[count]) {
            srcToTargetMap[count] = o;
          } else {
            srcToTargetMap[count][nodeId] = newNodeId;
          }
          resourceType = data.schema[nodeId]["resource_type"];
          coords = d3.transform(d3.select("#" + nodeId).attr("transform")).translate.map(function(c, i) {
            if (i === 0) {
              return c+100*(count+1);
            } else {
              return c;
            }
          });
          graph.addNode(newNodeId, resourceType.toLowerCase(), resourceType, coords);
          data.copyNodeData(nodeId, newNodeId);
        }
      });
      subtree.links.forEach(function(link) {
        for (count = 0; count < numCopy; count++) {
          var srcId = srcToTargetMap[count][link.source.id] ? srcToTargetMap[count][link.source.id] : link.source.id,
            targetId = srcToTargetMap[count][link.target.id] ? srcToTargetMap[count][link.target.id] : link.target.id;
          graph.addLink(srcId, targetId, '');
          data.setRelationship(srcId, targetId);
        }
      });
      keepNodesOnTop();
      ui.toast.show({
        target: $(".canvas-toolbar")[0],
        type: "success",
        text: "Copy successful"
      });
    }
  },

  deleteNodes: function() {
    var root = this.getSelectedNode();
    var subtree = this.dfsNodes(root.attr("id"));
    subtree.nodes.forEach(function(nodeId) {
      graph.removeNode(nodeId);
      data.removeNodeData(nodeId);
    });
    this.clearSelection();
    ui.setToolbarState(false);
    ui.toast.show({
      target: $(".canvas-toolbar")[0],
      type: "success",
      text: "Delete successful"
    });
  },

  getSelectedNode: function() {
    return d3.select(".node.selected");
  },

  onNodeRightClick: function() {
    d3.event.preventDefault();
    if (this.id !== ui.ctxMenu.nodeId) {
      ui.hideCtxMenu();
      ui.openCtxMenu(this);
    }
  },

  dfsNodes: function(startId) {
    var nodes = d3.selectAll("g.node").data(),
      links = d3.selectAll("line.link").data(),
      nodesToCopy = new Set(),
      linksToCopy = new Set();
    nodesToCopy.add(startId);
    nodesToCopy.forEach(function(nodeId) {
      links.forEach(function(link) {
        if (link.source.id === nodeId) {
          if (data.schema[link.target.id]['resource_type'] !== 'VM') {
            linksToCopy.add(link);
            if (data.getDepthById(link.target.id) >= data.getDepthById(startId)) {
              nodesToCopy.add(link.target.id);
            }
          }
        } else if (link.target.id === nodeId) {
          if (data.schema[link.source.id]['resource_type'] !== 'VM') {
            linksToCopy.add(link);
            if (data.getDepthById(link.source.id) >= data.getDepthById(startId)) {
              nodesToCopy.add(link.source.id);
            }
          }
        }
      });
    });
    return {
      nodes: nodesToCopy,
      links: linksToCopy
    };
  },

  loadGraph: function(spec) {
    var type, coords;
    (function dfs(node, parent) {
      for (var key in node) {
        if (typeof node[key] === "object") {
          if (isNaN(key)) {
            parent = node;
          } else {
            parent = parent;
            coords = [node[key].x * $("svg")[0].getBoundingClientRect().width, node[key].y * $("svg")[0].getBoundingClientRect().height];
            type = _.intersection(Object.keys(parent), ["PLR", "TLR", "VLS", "LS", "VNIC"])[0];
            type = (type === "VNIC") ? "VM" : type;
            graph.addNode(node[key]["borathonid"], type.toLowerCase(), type, coords);
          }
          dfs(node[key], parent);
        }
      }
    })(spec, null);
    (function dfs(node, parent) {
      for (var key in node) {
        if (typeof node[key] === "object") {
          if (isNaN(key)) {
            parent = node;
          } else {
            parent = parent;
            graph.addLink(node[key]["borathonid"], parent["borathonid"], "");
          }
          dfs(node[key], parent);
        }
      }
    })(spec["PLR"]["1"], null);
    keepNodesOnTop();
  },

  resetCanvas: function() {
    graph.removeAllLinks();
    graph.removeAllNodes();
  }
};

function myGraph(el) {
  // Add and remove elements on the graph object
  this.addNode = function(id, cls, type, coords) {
    if (coords) {
      nodes.push({
        "id": id,
        "cls": cls,
        "type": type,
        "x": coords[0],
        "y": coords[1]
      });
    } else {
      nodes.push({
        "id": id,
        "cls": cls,
        "type": type
      });
    }
    update();
    ui.chkCountConstraints();
  };

  this.removeNode = function(id) {
    var i = 0;
    var n = findNode(id);
    while (i < links.length) {
      if ((links[i]['source'] == n) || (links[i]['target'] == n)) {
        links.splice(i, 1);
      } else i++;
    }
    nodes.splice(findNodeIndex(id), 1);
    update();
    ui.chkCountConstraints();
  };

  this.removeLink = function(source, target) {
    for (var i = 0; i < links.length; i++) {
      if (links[i].source.id == source && links[i].target.id == target) {
        links.splice(i, 1);
        break;
      }
    }
    update();
  };

  this.removeAllLinks = function() {
    links.splice(0, links.length);
    update();
  };

  this.removeAllNodes = function() {
    nodes.splice(0, nodes.length);
    update();
  };

  this.addLink = function(source, target, value) {
    links.push({
      "source": findNode(source),
      "target": findNode(target),
      "value": value
    });
    update();
  };

  var findNode = function(id) {
    for (var i in nodes) {
      if (nodes[i]["id"] === id) return nodes[i];
    };
  };

  var findNodeIndex = function(id) {
    for (var i = 0; i < nodes.length; i++) {
      if (nodes[i].id == id) {
        return i;
      }
    };
  };

  // set up the D3 visualisation in the specified element
  var w = $(".graph").width(),
    h = $(".graph").height();

  var tip = d3.tip()
  .attr('class', 'd3-tip')
  .offset([-10, 0])
  .html(function (d) {
      if (data.schema[d.id]['display_name']) {
        return "<span class='jamz-tip-text'>" + data.schema[d.id]['display_name'] + "</span>";
      } else {
        return "<span class='jamz-tip-text'>" + data.schema[d.id]['resource_type'] + "</span>";
      }
  });

  function zoomed() {
      d3.select(".vis-ct").attr("transform", "translate(" + d3.event.translate + ")scale(" + d3.event.scale + ")");
  }

  var zoom = d3.behavior.zoom()
      .scaleExtent([0, 2])
      .on("zoom", zoomed);

  var svg = d3.select(el)
    .append("svg:svg")
    .attr("width", w)
    .attr("height", h)
    .attr("id", "svg")
    .attr("pointer-events", "all")
    .attr("viewBox", "0 0 " + w + " " + h)
    .attr("perserveAspectRatio", "xMinYMid");
  svg.append('svg:g')
    .call(tip)
    .call(zoom)
    .attr("class", "vis-ct");

  var force = d3.layout.force();

  var nodes = force.nodes(),
    links = force.links();

  var update = function() {
    var link = svg.selectAll("line.link")
      .data(links, function(d) {
        return d.source.id + "-" + d.target.id;
      });

    link.enter().append("line")
      .attr("id", function(d) {
        return d.source.id + "-" + d.target.id;
      })
      .attr("class", "link");
    link.append("title")
      .text(function(d) {
        return d.value;
      });
    link.exit().remove();

    var node = svg.selectAll("g.node")
      .data(nodes, function(d) {
        return d.id;
      });

    var nodeEnter = node.enter().append("g")
      .attr("id", function(d) {
        return d.id;
      })
      .attr("class", function(d) {
        return "node " + d.cls;
      })
      .attr("d", function(d) {
        d.fixed = true;
      })
      .on('contextmenu', vis.onNodeRightClick)
      .on('mouseover', tip.show)
      .on('mouseout', tip.hide)
      .call(force.drag);

    nodeEnter.append("svg:circle")
      .attr("r", NODE_RADIUS)
      .attr("class", "node-circle");

    nodeEnter.append("svg:text")
      .attr("class", "node-text")
      .attr("dy", 4)
      .text(function(d) {
        return d.type;
      });

    node.exit().remove();
    force.on("tick", function(e) {

      node.attr("transform", function(d) {
        return "translate(" + d.x + "," + d.y + ")";
      });

      link.attr("x1", function(d) {
          return d.source.x;
        })
        .attr("y1", function(d) {
          return d.source.y;
        })
        .attr("x2", function(d) {
          return d.target.x;
        })
        .attr("y2", function(d) {
          return d.target.y;
        });

        // var k = 6 * e.alpha;

        //     // Push sources up and targets down to form a weak tree.
        //     link
        //         .each(function(d) { d.source.y -= k, d.target.y += k; })
        //         .attr("x1", function(d) { return d.source.x; })
        //         .attr("y1", function(d) { return d.source.y; })
        //         .attr("x2", function(d) { return d.target.x; })
        //         .attr("y2", function(d) { return d.target.y; });
    });

    // Restart the force layout.
    force
      .gravity(.05)
      .distance(50)
      .linkDistance(50)
      .size([w, h])
      .start();
  };

  // Make it all go
  update();
}

function drawGraph() {
  graph = new myGraph(".graph");
  // graph.addNode('A', "ls", "LS", 100, 100);
  // graph.addNode('B', "tlr", "TLR", 200, 100);
  // graph.addNode('C', "plr", "PLR", 200, 300);
  // graph.addLink('A', 'B', '');
  // graph.addLink('A', 'C', '8');
  // graph.addLink('B', 'C', '15');
}

$(document).ready(function() {
  drawGraph();
  keepNodesOnTop();
});

function keepNodesOnTop() {
  $(".node-circle").each(function(index) {
    var gnode = this.parentNode;
    gnode.parentNode.appendChild(gnode);
  });
}

function getLastNodePos() {
  var coords = [200, 200],
    svgCtRect = d3.select('.graph').node().getBoundingClientRect(),
    centroid = [(svgCtRect.width - svgCtRect.left)/2, (svgCtRect.height - svgCtRect.top)/2];
  return checkForNodes(centroid);
}

function checkForNodes(seed) {
  while(findNodesAtPt(seed)) {
    seed = [seed[0]+10, seed[1]+10];
  }
  return seed;
}

function findNodesAtPt(seed) {
  var isFound = false;
  d3.selectAll("g.node").each(function(o) {
    var node = d3.select("#" + o.id),
      t = d3.transform(node.attr("transform")).translate;
      if (_.isEqual(seed, t)) {
        isFound = true;
      }
  });
  return isFound;
}




$(".graph").on('click', function(evt) {
    vis.onVisClick(evt);
});

d3.select(".graph").on("mousemove", vis.moveDragLink);
d3.select(".graph").on("mousedown", vis.endDragLink);
