from pyVmomi import vim
from pyVmomi import vmodl
import logging
import random
import time
import uuid
from xml.dom import minidom

import config as config
import host as host

log = logging.getLogger('autopology')


class GuestVM(host.Host):
    """
    Abstract base class for guest VM
    """
    @staticmethod
    def get_vm_obj(parent=None, **kwargs):
        if parent.os_type == "ESXI":
            return EsxGuestVM(parent=parent, **kwargs)
        if parent.os_type == "KVM":
            return KvmGuestVM(parent=parent, **kwargs)

    def __init__(self, ip=None, username=None, password=None, parent=None,
                 name=None):
        super(GuestVM, self).__init__(ip=ip, username=username,
                                      password=password)
        self.name = name
        self.parent = parent
        if config.ALLOW_VM_SSH:
            self.ssh_copy_id(ip, username, password)
            import spur
            self.shell = spur.SshShell(
                hostname=self.ip, username=self.username, password=self.password,  # noqa
                missing_host_key=spur.ssh.MissingHostKey.accept)

    def add_interface(self):
        raise NotImplementedError

    def set_interface(self, mac, ip, prefix=None):
        """
        Method to set interface IP and route.

        Params:
            mac: mac address to ifentify the interface
            ip: ip address to set
            prefix: TODO
        """
        interface_name = self.get_interface_name(mac)
        self.set_interface_ip(interface_name, ip)
        net_ip = self.net_ip_from_ip(ip)
        net_mask = "255.0.0.0"
        gateway = self.gateway_from_ip(ip)
        self.set_route(net_ip, net_mask, gateway)

    def get_interface_name(self, mac):
        command = "ifconfig -a | grep %s | cut -c-5" % mac
        result = self.shell.run(["sh", "-c", command])
        return result.output.strip()

    def set_interface_ip(self, interface_name, ip):
        self.shell.run(["ifconfig", interface_name, ip, "netmask",
                        "255.255.255.0", "up"])
        if self.get_interface_ip(interface_name) != ip:
            raise ValueError("Failed to set IP on interface.")

    def get_interface_ip(self, interface_name):
        cmd = ("ifconfig %s | grep 'inet addr:' | cut -d: -f2 | awk '{print $1"
               "}'") % interface_name
        result = self.shell.run(["sh", "-c", cmd])
        return result.output.strip()

    def gateway_from_ip(self, ip):
        array = (ip.split('.'))
        array[3] = '1'
        return '.'.join(array)

    def net_ip_from_ip(self, ip):
        return "%s.0.0.0" % ip.split('.')[0]

    def set_route(self, net_ip, net_mask, gateway):
        result = self.shell.run(["route", "add", "-net", net_ip, "netmask",
                                 net_mask, "gw", gateway])
        command = "route -n | grep %s" % net_ip
        result = self.shell.run(["sh", "-c", command])
        parts = result.output.strip().split(" ")
        cleaned = [x for x in parts if x]
        log.debug(cleaned)
        if (cleaned[0] == net_ip and cleaned[1] == gateway and
                cleaned[2] == net_mask):
            return True
        else:
            log.error("Failed to set route on VM '%s'" % self.ip)
            return False

    def ping(self, dst_ip):
        command = "ping -c 5 %s" % dst_ip
        result = self.shell.run(command.split(), allow_error=True)
        return result.output.strip().splitlines()


class EsxGuestVM(GuestVM):
    def add_interface(self, ls_id=None, ip=None):
        try:
            hv_vm_obj = self.parent.find_guest_vm(self.name)
            existing_nics = []
            log.debug("Adding a vnic to LS-ID '%s' on vm '%s'" %
                      (ls_id, hv_vm_obj.name))
            devices = hv_vm_obj.config.hardware.device
            for device in devices:
                if not isinstance(device, vim.vm.device.VirtualEthernetCard):
                    continue
                existing_nics.append(device.key)
            # network configuration
            back = vim.vm.device.VirtualEthernetCard.OpaqueNetworkBackingInfo()
            back.opaqueNetworkId = ls_id
            back.opaqueNetworkType = 'nsx.LogicalSwitch'
            # creating network object
            vnic = vim.vm.device.VirtualE1000()
            vnic.backing = back
            vnic.wakeOnLanEnabled = True
            vnic.deviceInfo = vim.Description()
            vnic.connectable = vim.vm.device.VirtualDevice.ConnectInfo()
            vnic.connectable.startConnected = True
            vnic.connectable.allowGuestControl = True
            # defining operation
            devSpec = vim.vm.device.VirtualDeviceSpec()
            devSpec.operation = vim.vm.device.VirtualDeviceSpec.Operation.add
            devSpec.device = vnic

            vmconf = vim.vm.ConfigSpec(deviceChange=[devSpec])
            task = hv_vm_obj.ReconfigVM_Task(spec=vmconf)
            self.wait_for_task(task, "addNic", hv_vm_obj)

            # checking for the added nic
            devices = hv_vm_obj.config.hardware.device
        except vmodl.MethodFault as error:
            error = error.msg
            raise RuntimeError("Unable to add vnic on the vm '%s': [%s]"
                               % (hv_vm_obj.name, error))
        for device in devices:
            if not isinstance(device, vim.vm.device.VirtualEthernetCard):
                continue
            if device.key not in existing_nics:
                log.debug("Created VNIC '%s' with mac '%s', setting IP '%s'" %
                          (device.key, device.macAddress, ip))
                if config.ALLOW_VM_SSH:
                    self.set_interface(device.macAddress, ip)
                return device.externalId
        log.error("Failed to add vnic to LS-ID '%s' on vm '%s'" %
                  (ls_id, hv_vm_obj.name))
        return False

    def wait_for_task(self, task, actionName, vm):
        """Waits and provides updates on a vSphere task"""
        while task.info.state == vim.TaskInfo.State.running:
                time.sleep(1)
        if task.info.state == vim.TaskInfo.State.success:
                log.debug("VM '%s' successfully reconfigured for '%s'" %
                          (vm, actionName))
                return True
        else:
                log.error("Error '%s' while reconfiguring vm '%s' for '%s'" %
                          (task.info.error, vm, actionName))
                return False


class KvmGuestVM(GuestVM):
    def random_mac_address(self, oui):
        assert len(oui) == len("XX:XX:XX"), "Bad OUI supplied: %s" % oui
        tail = ":".join("%02x" % random.randrange(16 ** 2) for _ in xrange(3))
        mac = "%s:%s" % (oui, tail)
        return mac

    def get_interface_count(self, raw_xml):
        host_xml = minidom.parseString(raw_xml)
        interfaceTypes = host_xml.getElementsByTagName('interface')
        return len(interfaceTypes)

    def generate_interface_schema(self, br_port_number, domain_name=None,
                                  mac=None):
        vif_id = str(uuid.uuid4())
        interface_xml = "<interface type='bridge'> \
            <model type='virtio'/> \
            <mac address='" + mac + "'/>" + \
            "<source network='nsx-managed'/> \
            <source bridge='nsx-managed'/> \
            <target dev='" + domain_name + "-" + \
            str(br_port_number).zfill(2) + "'/>" + \
            "<virtualport type='openvswitch'> \
            <parameters interfaceid='" + vif_id + "'/> \
            </virtualport> \
            </interface>"
        interface_xml.replace(",", "\\'")
        return interface_xml, vif_id

    def add_interface(self, ip=None, **kwargs):
        _qemu_oui = "52:54:00"
        dom = self.parent.find_guest_vm(self.name)
        if dom is None:
            log.error("Failed to get the domain by name '%s'" % self.name)
            return False
        raw_xml = dom.XMLDesc(0)
        interface_count = self.get_interface_count(raw_xml)
        domain_name = dom.name()
        mac = self.random_mac_address(_qemu_oui)
        interface_schema, vif_id = self.generate_interface_schema(
            interface_count, domain_name=domain_name, mac=mac)
        dom.attachDevice(interface_schema)
        if config.ALLOW_VM_SSH:
            self.set_interface(mac, ip)
        return vif_id
