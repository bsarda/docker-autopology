import argparse
import doctest
import itertools
import logging
import pprint
import Queue
import re
import sys
import threading
import time

import errors
import hypervisor
import config
import guest_vm
import locked_dict
import nsx_manager

DEFAULT_NUM_THREADS = 16
HIGHEST_PRIORITY = 0
log = logging.getLogger('autopology')

urlmap = {'logical-switches': 'https://%s/nsxapi/#view=switching/switches/editor/summary&id=%s',  # noqa
          'logical-routers': 'https://%s/nsxapi/#view=routing/routers/editor/summary&id=%s',  # noqa
          'create-nic': 'https://%s/nsxapi/#view=switching/ports/editor/summary&id=%s',  # noqa
          'logical-ports': 'https://%s/nsxapi/#view=switching/ports/editor/summary&id=%s'}  # noqa

CACHE_KEY = 'id'


class Topology(object):
    """
    Class to retrieve and check for topological information like which port is
    on which ls/lr and which lr/ls are connected etc.

    >>> plr = {'id': 1234}
    >>> tlr = {'id': 2345}
    >>> plrp = {'logical_router_id': 1234, 'resource_type': 'LogicalRouterLinkPortOnTIER0'}  # noqa
    >>> tlrp = {'logical_router_id': 2345, 'resource_type': 'LogicalRouterLinkPortOnTIER1'}  # noqa
    >>> Topology.is_plrp(plr, plrp)
    True
    >>> Topology.is_plrp(tlr, plrp)
    False
    >>> any(x(plr, plrp) for x in (Topology.is_lsp, Topology.is_dlrp, Topology.is_tlrp, Topology.is_ulrp))  # noqa
    False
    >>> Topology.is_tlrp(tlr, tlrp)
    True
    >>> Topology.is_tlrp(plr, tlrp)
    False
    >>> any(x(tlr, tlrp) for x in (Topology.is_lsp, Topology.is_dlrp, Topology.is_plrp, Topology.is_ulrp))  # noqa
    False
    """
    inventory = None

    def __init__(self, testbed, num_threads=None):
        if num_threads is None:
            num_threads = DEFAULT_NUM_THREADS
        self.lr = []
        self.lrp = []
        self.ls = []
        self.lsp = []
        self.workers = []
        self.nsxmanagers = self.setup_nsxmanagers(testbed)
        for _ in range(num_threads):
            self.add_worker()
        self.miter = itertools.cycle(self.nsxmanagers)
        self.qiter = itertools.cycle(q for t, q in self.workers)
        self.bulkdict = locked_dict.LockedDict('BULK')
        self.topodict = locked_dict.LockedDict('TOPO')
        self.monitordict = locked_dict.LockedDict('MONITOR')

    def setup_nsxmanagers(self, testbed):
        """
        Setup the NSX Manager objects from the testbed information given

        >>> tb = { 'nsxmanager': {1: {
        ...     'ip': '10.0.0.1', 'username': 'admin', 'password': 'default'}}}
        >>> t = Topology(tb)
        >>> len(t.nsxmanagers)
        1

        @type testbed: dict
        @param testbed: nsx manager details like ip/username/password
        @rtype: list
        @return: list of nsx manager objects
        """
        nsxmanagers = []
        for i, m in testbed.get('nsxmanager', {}).iteritems():
            nsxmanagers.append(nsx_manager.NSXManager(
                m['ip'], m['username'], m['password'], m['nsx_cert_file']))
        return nsxmanagers

    def api_worker(self, q):
        while True:
            p, item = q.get()
            try:
                item[0](*item[1:])
            except errors.WaitError as e:
                self.queue_dependency(item, e.name, e.handler, p)
            except Exception as e:
                log.exception("%s failed: %s" % (item, e))
            q.task_done()

    def queue_dependency(self, item, name, func, priority):
        if func:
            def bar():
                self.queue.put((HIGHEST_PRIORITY, item))
            log.debug("Waiting for %s ..." % name)
            func(bar)
        else:
            log.debug("Requeuing with lower priority %s ..." % name)
            self.queue.put((priority + 1, item))

    def add_worker(self, **kwargs):
        q = Queue.PriorityQueue()
        i = len(self.workers)
        t = threading.Thread(target=self.api_worker, name='api_worker%s' % i,
                             args=[q], kwargs=kwargs)
        t.daemon = True
        t.start()
        self.workers.append((t, q))
        return t, q

    def resize_workers(self):
        """
        Resizes the list of workers based on the amount of remaining work,
        Current logic just adds one more worker if none of the workers have
        less than 100 items queued.
        """
        for t, q in self.workers[:]:
            if q.qsize() < 100:
                break
        else:
            self.add_worker()
        self.qiter = itertools.cycle(q for t, q in self.workers)

    def dump(self):
        """
        Dumps all the queue states to the log file and all the internal state
        maintained in locked_dict objects is serialized, written to json file
        """
        self.print_queue_state()
        self.persist_internal_state()

    def persist_internal_state(self):
        """
        Persist the internal state maintained in locked_dict to json file
        """
        self.bulkdict.dump()
        self.topodict.dump()

    def print_queue_state(self):
        """
        Logs the amount of work remaining in worker queues and on_set_queues
        """
        sizes = [q.qsize() for t, q in self.workers]
        log.warn('Remaining work: %s %s', sum(sizes), sizes)
        self.bulkdict.print_on_set_queue_state()

    @property
    def mgr(self):
        """
        Returns the next manager for api calls iteratively
        """
        return self.miter.next()

    @property
    def queue(self):
        """
        Returns the next queue which has least amount of work queued
        """
        return min(*[q for t, q in self.workers], key=lambda q: q.qsize())

    def fetch(self):
        """
        Fetch all the zones/switches/routers from the testbed
        """
        self.tz = self.mgr.get('transport-zones')
        self.lr = self.mgr.get('logical-routers')
        self.ls = self.mgr.get('logical-switches')
        self.lsp = self.mgr.get('logical-ports')
        self.lrp = self.mgr.get('logical-router-ports')

    def clean(self):
        """
        Clean/Delete all the zones/switches/routers on the testbed
        """
        log.info('%s %s %s %s' % (len(self.lr), len(self.ls), len(self.lrp),
                                  len(self.lsp)))
        for x in self.lrp:
            self.queue.put(
                (1, [self.mgr.delete, 'logical-router-ports', x['id']]))
        for x in self.lsp:
            self.queue.put(
                (2, [self.mgr.delete, 'logical-ports', x['id']]))
        for x in self.ls:
            self.queue.put(
                (3, [self.mgr.delete, 'logical-switches', x['id']]))
        for x in self.lr:
            self.queue.put(
                (4, [self.mgr.delete, 'logical-routers', x['id']]))
        for x in self.tz:
            self.queue.put(
                (5, [self.mgr.delete, 'transport-zones', x['id']]))

        while not all(q.empty() for t, q in self.workers):
            log.info("%s" % ([q.qsize() for t, q in self.workers]))
            time.sleep(5)

    def is_plr(self, x):
        if x['router_type'] == 'TIER0':
            x['tree'] = ['PLR', x[CACHE_KEY]]
            return True
        elif x['router_type'] == 'TIER1':
            x['tree'] = ['TLR', x[CACHE_KEY]]
            return False
        else:
            raise ValueError

    @staticmethod
    def is_dlrp(lr, p):
        return (p['resource_type'] == 'LogicalRouterDownLinkPort' and
                lr['id'] == p['logical_router_id'])

    @staticmethod
    def is_plrp(lr, p):
        return (p['resource_type'] == 'LogicalRouterLinkPortOnTIER0' and  # noqa
                lr['id'] == p['logical_router_id'])

    @staticmethod
    def is_tlrp(lr, p):
        return (p['resource_type'] == 'LogicalRouterLinkPortOnTIER1' and  # noqa
                lr['id'] == p['logical_router_id'])

    @staticmethod
    def is_ulrp(lr, p):
        return (p['resource_type'] == 'LogicalRouterUpLinkPort' and
                lr['id'] == p['logical_router_id'])

    @staticmethod
    def is_lsp(ls, p):
        return (p['resource_type'] == 'LogicalPort' and
                ls['id'] == p['logical_switch_id'])

    @staticmethod
    def get_linked_vifid(lsp):
        if lsp.get('attachment', {}).get('attachment_type') == 'VIF':
            return lsp.get('attachment').get('id')

    def add_lswitch_datapath_event(self, monitor_id, vif_uuid,
                                   ls_id, ls_name):
        # Get LS status
        hv_obj = Topology.get_hv_obj_from_vif_id(self.inventory, vif_uuid)
        self.add_pif_datapath_event(monitor_id, hv_obj)
        ls_status, ls_event = hv_obj.validate_logical_switch(ls_id, ls_name)

        # Put this status in monitordict
        self.monitordict.append(monitor_id, 'events', ls_event)

        if not ls_status:
            if self.monitordict.get(monitor_id, 'autobot'):
                remediate_event = {}
                remediate_event['id'] = ls_event['id']
                remediate_event['name'] = ls_event['name']
                remediate_event['type'] = 'FAILURE'
                remediate_event['message'] = 'Unable to fix'
                remediate_event['url'] = 'https://kb.vmware.com'
                self.monitordict.append(monitor_id, 'events', remediate_event)

    def add_pif_datapath_event(self, monitor_id, hv_obj):
        pif_status, pif_event = hv_obj.get_pif_state(hv_obj.TUNNEL_PIF)
        # Put this status in monitordict
        self.monitordict.append(monitor_id, 'events', pif_event)

        if not pif_status:
            if self.monitordict.get(monitor_id, 'autobot'):
                pif_status, pif_event = hv_obj.fix_pif_state(hv_obj.TUNNEL_PIF)
                if not pif_status:
                    pif_event['type'] = 'FAILURE'
                    pif_event['message'] = 'Unable to fix'
                    pif_event['url'] = 'https://kb.vmware.com'
                else:
                    pif_event['type'] = 'SUCCESS'
                    pif_event['message'] = 'I fixed %s on %s %s' % (hv_obj.TUNNEL_PIF, hv_obj.os_type, hv_obj.ip)  # noqa
            # Put the new event in monitordict
            self.monitordict.append(monitor_id, 'events', pif_event)

    def add_lrouter_datapath_event(self, monitor_id, vif_uuid,
                                   lr_id, lr_name):
        # Get LR status
        hv_obj = Topology.get_hv_obj_from_vif_id(self.inventory, vif_uuid)
        lr_status, lr_event = hv_obj.validate_logical_router(lr_id, lr_name)

        # Put this status in monitordict
        self.monitordict.append(monitor_id, 'events', lr_event)

        if not lr_status:
            if self.monitordict.get(monitor_id, 'autobot'):
                remediate_event = {}
                remediate_event['id'] = lr_event['id']
                remediate_event['name'] = lr_event['name']
                remediate_event['type'] = 'FAILURE'
                remediate_event['message'] = 'Unable to fix'
                remediate_event['url'] = 'https://kb.vmware.com'
                self.monitordict.append(monitor_id, 'events', remediate_event)

    def connectivity_check(self, monitor_id, vif_list):
        vm_objs = []
        for index, vif in enumerate(vif_list):
            hv_os_type, hv_ip, vm_name, vm_ip = vif.split('/')
            # XXX: We are using '_' as a special separator so
            # we need replacement with another character.
            vm_name = vm_name.replace('$', '_')
            # Create HV object.
            hv_username, hv_password = config.get_auth_userpass(
                hv_os_type, hv_ip)
            hv_obj = hypervisor.Hypervisor.get_hv_obj(ip=hv_ip,
                                                      username=hv_username,
                                                      password=hv_password,
                                                      os_type=hv_os_type)
            # Create VM Object.
            vm_username, vm_password = config.get_auth_userpass(
                'vm', vm_ip)
            vm_obj = guest_vm.GuestVM.get_vm_obj(ip=vm_ip,
                                                 username=vm_username,
                                                 password=vm_password,
                                                 parent=hv_obj,
                                                 name=vm_name)
            vm_objs.append(vm_obj)
        src_vm = vm_objs[0]
        dst_vm = vm_objs[1]
        test_interface = 'eth1'
        src_ip = src_vm.get_interface_ip(test_interface)
        dst_ip = dst_vm.get_interface_ip(test_interface)
        result = src_vm.ping(dst_ip)
        connectivity_status = True
        ping_re = r'^(\d+)([\s\w]+),\s+(\d+)([\s\w]+),([+d\s\w+,]*)\s(?P<loss>\d+)%([\s\w]+),.*'  # noqa
        if result:
            try:
                for line in result:
                    if "% packet loss" in line:
                        log.debug('ping output: %s' % line)
                        result = re.match(ping_re, line)
                        if result:
                            loss = result.group('loss')
                            if int(loss) > 10:
                                connectivity_status = False
            except:
                pass
        msg = ['I checked connectivity between servers']
        msg.append('%s and %s.' % (src_ip, dst_ip))
        msg.append('[Loss: %d%%].' % (int(loss)))
        msg.append('It was %s' % (connectivity_status and 'OK' or 'NOT OK'))
        msg_text = ' '.join(msg)
        remediate_event = {}
        remediate_event['name'] = 'Connectivity Check'
        remediate_event['type'] = connectivity_status and 'SUCCESS' or 'FAILURE'  # noqa
        remediate_event['message'] = msg_text
        remediate_event['url'] = ''
        self.monitordict.append(monitor_id, 'events', remediate_event)

    @staticmethod
    def get_hv_obj_from_vif_id(inventory, vif_uuid):
        hv_dict = Topology.get_hv(inventory, vif_uuid)
        os_type = hv_dict['os_type']
        username = hv_dict['username']
        password = hv_dict['password']
        ip = hv_dict['ip']
        return hypervisor.Hypervisor.get_hv_obj(os_type=os_type, ip=ip,
                                                username=username,
                                                password=password)

    @staticmethod
    def get_vm(inventory, vif_uuid):
        for _, hv in inventory['hv'].iteritems():
            for _, vm in hv['vm'].iteritems():
                for _, nic in vm['nics'].iteritems():
                    if nic['id'] == vif_uuid:
                        return vm
        else:
            log.error("Failed to find VM from vif-uuid '%s'." % vif_uuid)
            log.debug("Inventory:\n%s" % pprint.pformat(inventory))
            return False

    @staticmethod
    def get_hv(inventory, vif_uuid):
        for _, hv in inventory['hv'].iteritems():
            for _, vm in hv['vm'].iteritems():
                for _, nic in vm['nics'].iteritems():
                    if nic['id'] == vif_uuid:
                        return hv
        else:
            log.error("Failed to find HV from vif-uuid '%s'." % vif_uuid)
            log.debug("Inventory:\n%s" % pprint.pformat(inventory))
            return False

    def is_linked_llrp(self, plrp, tlrp):
        try:
            if None in (plrp, tlrp):
                return False
            return plrp['id'] == plrp['linked_logical_router_port_id']
        except KeyError:
            log.error(pprint.pformat(plrp))
            log.error(pprint.pformat(tlrp))
            return False

    def is_linked_lrplsp(self, lrp, lsp):
        try:
            if None in (lrp, lsp):
                return False
            return (lrp['linked_logical_switch_port_id']['target_id'] ==
                    lsp['id'])
        except KeyError:
            log.error(pprint.pformat(lrp))
            log.error(pprint.pformat(lsp))
            return False

    def is_linked_ulrplsp(self, ulrp, lsp):
        try:
            if None in (ulrp, lsp):
                return False
            return (ulrp['linked_logical_switch_port_id']['target_id'] ==
                    lsp['id'])
        except KeyError:
            log.error(pprint.pformat(ulrp))
            log.error(pprint.pformat(lsp))
            return False

    def is_connected_plrtlr(self, plr, tlr):
        if None in (plr, tlr):
            return False
        for p in self.lrp:
            if not self.is_plrp(plr, p):
                continue
            for q in self.lrp:
                if not self.is_tlrp(tlr, q):
                    continue
                if self.is_linked_llrp(p, q):
                    tlr['parent'] = plr
                    return True

    def is_connected_lrls(self, x, y):
        if None in (x, y):
            return False
        for p in self.lrp:
            if ((not self.is_dlrp(x, p) and
                 not self.is_ulrp(x, p))):
                continue

            for q in self.lsp:
                if not self.is_lsp(y, q):
                    continue
                if self.is_linked_lrplsp(p, q):
                    y['parent'] = x
                    return True
                if self.is_linked_ulrplsp(p, q):
                    y['parent'] = x
                    y['tree'] = ['ULS', y[CACHE_KEY]]
                    return True

    def get_path(self, x, path=None):
        if path is None:
            path = []
        path = x['tree'] + path
        if x.get('parent'):
            return self.get_path(x['parent'], path=path)
        else:
            return path

    def add_admin_status_event(self, monitor_id, path, obj):
        name = obj['display_name']
        uid = obj['id']
        if obj['admin_state'] == 'UP':
            type = 'INFO'
            message = 'Admin status is UP'
            remediate = False
        else:
            type = 'ERROR'
            message = 'Admin status is DOWN'
            remediate = True
        url = None
        event = dict(name=name, id=uid, type=type, message=message, url=url)
        log.debug("Adding event %s with monitor-id %s" % (event, monitor_id))
        self.monitordict.append(monitor_id, 'events', event)

        autobot = self.monitordict.get(monitor_id, 'autobot')
        if autobot and remediate:
            for key in obj.keys():
                if key.startswith("_") and key != "_revision":
                    del obj[key]
            obj['admin_state'] = "UP"
            # Sleep to avoid super-quick fix
            time.sleep(5)
            self.mgr.put(path, obj['id'], obj)
            event = dict(name=name, id=uid, type="SUCCESS", message="I fixed admin_state on %s %s" % (obj['resource_type'], obj['display_name']))  # noqa
            log.debug("Adding event %s with monitor-id %s" % (event,
                                                              monitor_id))
            self.monitordict.append(monitor_id, 'events', event)

    def get_monitor_events(self, monitor_id):
        try:
            events = self.monitordict.clear(monitor_id, 'events')
        except ValueError:
            events = []
        return dict(events=events)

    def start_monitor(self, monitor_id, topology_id, entity_id):
        self.queue.put(
            (1, [self.run_monitor, monitor_id, topology_id, entity_id]))

    def run_monitor(self, monitor_id, topology_id, entity_id=None):
        topo = self.topodict.get(topology_id)
        while True:
            for _, plr in topo.get('spec', {}).get('PLR', {}).iteritems():
                chk_plr = chk_tlr = chk_ls = False
                plrobj = self.mgr.get('logical-routers', plr['id'])
                if entity_id is None or entity_id == plr['id']:
                    chk_plr = True
                for _, tlr in plr.get('TLR', {}).iteritems():
                    tlrobj = self.mgr.get('logical-routers', tlr['id'])
                    if chk_plr or entity_id == tlr['id']:
                        chk_tlr = True
                    vif_list = []
                    for _, ls in tlr.get('LS', {}).iteritems():
                        lsobj = self.mgr.get('logical-switches', ls['id'])
                        if chk_tlr or entity_id == ls['id']:
                            chk_ls = True
                        if chk_ls:
                            self.add_admin_status_event(
                                monitor_id, 'logical-switches', lsobj)
                        else:
                            continue
                        for _, lsp in ls.get('LSP', {}).iteritems():
                            lspobj = self.mgr.get('logical-ports', lsp['id'])
                            self.add_admin_status_event(
                                monitor_id, 'logical-ports', lspobj)
                            vif_uuid = self.get_linked_vifid(lspobj)
                            vm_vif = self.get_vm(self.inventory, vif_uuid)
                            vif_list.append(vm_vif['uid'])
                            self.add_lswitch_datapath_event(
                                monitor_id, vif_uuid,
                                lsobj['id'], lsobj['display_name'])
                            if chk_tlr:
                                self.add_lrouter_datapath_event(
                                    monitor_id, vif_uuid,
                                    tlrobj['id'], tlrobj['display_name'])
                            if chk_plr:
                                self.add_lrouter_datapath_event(
                                    monitor_id, vif_uuid,
                                    plrobj['id'], plrobj['display_name'])
                    autobot = self.monitordict.get(monitor_id, 'autobot')
                    if len(vif_list) == 2 and autobot:
                        self.connectivity_check(monitor_id, vif_list)
            if entity_id is None:
                break
            time.sleep(1)

    def build(self, inventory=None):
        """
        Build a topological view of all the zones/switches/routers

        @rtype: dict
        @return: Topological view of all the switches/routers
        """
        if inventory:
            log.debug("Intentory:\n%s" % pprint.pformat(inventory))
        sysdict = locked_dict.LockedDict('SYSTEM')
        for x in self.lr:
            if self.is_plr(x):
                x['resource_type'] = 'PLR'
                for y in self.lr:
                    if not self.is_plr(y):
                        y['resource_type'] = 'TLR'
                        self.is_connected_plrtlr(x, y)
            for ls in self.ls:
                ls['tree'] = ['LS', ls[CACHE_KEY]]
                if self.is_connected_lrls(x, ls):
                    ls['parent'] = x

        for ls in self.ls:
            for lsp in self.lsp:
                if self.is_lsp(ls, lsp):
                    vif_uuid = self.get_linked_vifid(lsp)
                    if vif_uuid:
                        lsp['tree'] = ['LSP', lsp[CACHE_KEY]]
                        lsp['parent'] = ls
                        vm = self.get_vm(inventory, vif_uuid)
                        if vm:
                            lsp['vm_ip'] = vm['ip']
                            lsp['vm_uuid'] = vm['uid']

        for x in self.lr:
            d = dict(
                url=urlmap['logical-routers'] % (self.nsxmanagers[0].ip, x['id']),  # noqa
                id=x['id'],
                display_name=x['display_name'],
                resource_type=x['resource_type'],
                )
            sysdict.set(*(self.get_path(x) + [d]))
        for x in self.ls:
            d = dict(
                url=urlmap['logical-switches'] % (self.nsxmanagers[0].ip, x['id']),  # noqa
                id=x['id'],
                display_name=x['display_name'],
                resource_type=x['resource_type'],
                )
            sysdict.set(*(self.get_path(x) + [d]))
        for x in self.lsp:
            if not x.get('tree'):
                continue
            d = dict(
                url=urlmap['logical-ports'] % (self.nsxmanagers[0].ip, x['id']),  # noqa
                id=x['id'],
                display_name=x['display_name'],
                resource_type=x['resource_type'],
                vm_ip=x['vm_ip'],
                vm_uuid=x['vm_uuid'],
                )
            sysdict.set(*(self.get_path(x) + [d]))
        log.debug("SYSTEM state:\n%s" % pprint.pformat(sysdict.cache))
        return sysdict.cache

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--doctest', action='store_true', default=False)
    args = parser.parse_args(sys.argv[1:])
    if args.doctest:
        doctest.testmod(optionflags=doctest.ELLIPSIS)
        sys.exit(0)
