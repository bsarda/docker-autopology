#!/usr/bin/env python

import autopology
import os


def main():
    print "Starting autopology server in background..."
    os.system('python %s/server.py' % autopology.__path__[0])


if __name__ == "__main__":
    main()
