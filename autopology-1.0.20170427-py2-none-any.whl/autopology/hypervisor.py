from __future__ import print_function
import collections
import logging
import subprocess
import re
import time
from xml.dom import minidom

import host


log = logging.getLogger('autopology')


class Hypervisor(host.Host):
    """
    Abstract base class for Hypervisor
    """
    NSXCLI_SCRIPT_PATH = '/opt/vmware/nsx-cli/bin/scripts/nsxcli'

    @staticmethod
    def get_hv_obj(os_type=None, **kwargs):
        if os_type == "ESXI":
            return ESX(**kwargs)
        elif "KVM" in os_type:
            return KVM(**kwargs)
        else:
            raise AssertionError("Unable to determine HV OS.")

    def __init__(self, ip=None, username=None, password=None):
        super(Hypervisor, self).__init__(ip=ip, username=username,
                                         password=password)
        self.ssh_copy_id(ip, username, password)
        self.hostname = None
        self.connection = None

    def get_vm_inventory(self):
        raise NotImplementedError

    def _open_nsxcli_prompt(self):
        expect = ['bytes*', '>']
        # Adding this to make CLI calls.
        # XXX: Hack only for borathon. Need to fix this.
        import sys
        sys.path.append('/src/nsx-qe/vdnet/automation/pylib/')
        import vmware.common.connections.expect_connection as expect_connection
        self.connection = expect_connection.ExpectConnection(
            ip=self.ip, username=self.username, password=self.password)
        self.connection.request(command=self.NSXCLI_SCRIPT_PATH, expect=expect)

    def _close_nsxcli_prompt(self):
        expect = ['bytes*', '#', ']', '$']
        # Adding this to make CLI calls.
        # XXX: Hack only for borathon. Need to fix this.
        import sys
        sys.path.append('/src/nsx-qe/vdnet/automation/pylib/')
        import vmware.common.connections.expect_connection as expect_connection
        self.connection = expect_connection.ExpectConnection(
            ip=self.ip, username=self.username, password=self.password)
        self.connection.request(command='exit', expect=expect)

    def run_nsxcli(self, cli):
        """
        Helper to run nsxcli commands.
        """
        # Open NSXCLI prompt
        self._open_nsxcli_prompt()

        # Run desired command
        if self.hostname:
            expect = ['bytes*', self.hostname + '>']
        else:
            expect = ['bytes*', '>']
        result = self.connection.request(command=cli, expect=expect)

        # Close NSXCLI prompt
        self._close_nsxcli_prompt()
        return result

    def get_logical_switches(self, uuid=None):
        """
        Returns output of 'get logical switch' nsxcli on HV.
        """
        cli = ["get logical-switch"]
        if uuid:
            cli.append(uuid)
        cli = " ".join(cli)
        # TODO: Parse/Process this data. Returning blindly for now.
        # Different platforms will need different parsing of output.
        return self.run_nsxcli(cli).response_data

    def validate_logical_switch(self, ls_id=None, ls_name=None):
        """
        Returns dict as below:

        {'id': <ls_id>,
         'name': <ls_name>,
         'type': 'INFO'/'ERROR',
         'message': <message about status'}
        """
        ls_status = {}
        ls_status['id'] = ls_id
        ls_status['name'] = ls_name
        result = self.get_logical_switches()
        if ls_id not in result:
            ls_status['type'] = 'ERROR'
            ls_status['message'] = 'lswitch NOT FOUND on %s %s' % (self.os_type, self.ip)  # noqa
            ret = False
        else:
            ls_status['type'] = 'INFO'
            ls_status['message'] = 'Datapath status OK'
            ret = True
        return (ret, ls_status)

    def get_logical_routers(self):
        """
        Returns output of 'get logical switch' nsxcli on HV.
        """
        cli = "get logical-router"
        return self.run_nsxcli(cli).response_data

    def validate_logical_router(self, lr_id=None, lr_name=None):
        """
        Returns dict as below:

        {'id': <lr_id>,
         'name': <lr_name>,
         'type': 'INFO'/'ERROR',
         'message': <message about status'}
        """
        lr_status = {}
        lr_status['id'] = lr_id
        lr_status['name'] = lr_name
        result = self.get_logical_routers()
        if lr_id not in result:
            lr_status['type'] = 'ERROR'
            lr_status['message'] = 'lrouter NOT FOUND on %s %s' % (self.os_type, self.ip)  # noqa
            ret = False
        else:
            lr_status['type'] = 'INFO'
            lr_status['message'] = 'Datapath status OK'
            ret = True
        return (ret, lr_status)


class ESX(Hypervisor):
    os_type = "ESXI"
    VM_VNIC_TYPES = ('vim.vm.device.VirtualE1000',
                     'vim.vm.device.VirtualVmxnet3')
    NSX_BACKING_TYPE = 'vim.vm.device.VirtualEthernetCard.OpaqueNetworkBackingInfo'  # noqa
    TUNNEL_PIF = 'vmnic1'  # BAD hardcoding

    def __init__(self, ip=None, username=None, password=None):
        super(ESX, self).__init__(ip=ip, username=username, password=password)
        self.connectToHypervisor()

    def get_pif_state(self, pif_name):
        pif_status = {}
        pif_status['name'] = pif_name
        process = subprocess.Popen(['ssh', '%s@%s' % (self.username, self.ip),
                                    'esxcli', 'network', 'nic', 'get', '-n', pif_name],  # noqa
                                   shell=False, stdout=subprocess.PIPE,
                                   stderr=subprocess.STDOUT)
        process.wait()
        state = None
        for line in process.stdout:
            line = line.strip()
            if "Link Status: Up" in line:
                pif_status['type'] = 'INFO'
                state = 'UP'
                ret = True
            elif "Link Status: Down" in line:
                pif_status['type'] = 'ERROR'
                state = 'DOWN'
                ret = False

        if not state:
            raise RuntimeError
        pif_status['message'] = '%s on %s (%s) %s' % (pif_name, self.os_type, self.ip, state)  # noqa
        return (ret, pif_status)

    def fix_pif_state(self, pif_name):
        # Sleep to avoid super-quick fixing
        time.sleep(5)
        process = subprocess.Popen(['ssh', '%s@%s' % (self.username, self.ip),
                                    'esxcli', 'network', 'nic', 'up', '-n',
                                    pif_name], shell=False,
                                   stdout=subprocess.PIPE,
                                   stderr=subprocess.STDOUT)
        process.wait()
        return self.get_pif_state(pif_name)

    def get_vm_inventory(self):
        from pyVmomi import vim
        content = self.service_instance.RetrieveContent()
        container = content.rootFolder  # starting point to look into
        viewType = [vim.VirtualMachine]  # object types to look for
        recursive = True  # whether we should look into it recursively
        containerView = content.viewManager.CreateContainerView(container,
                                                                viewType,
                                                                recursive)
        # Get the list of VM in the hv
        vms = containerView.view
        vm_json = {}
        index = 1
        for vm in vms:
            vm_json[index] = {}
            # XXX: We are using '_' as a special separator so
            # we need replacement with another character.
            vm_name = vm.config.name.replace('_', '$')
            vm_vnics = collections.defaultdict(dict)
            vif_index = 1
            all_vm_devices = vm.config.hardware.device
            for device in all_vm_devices:
                if type(device).__name__ in self.VM_VNIC_TYPES:
                    if type(device.backing).__name__ == self.NSX_BACKING_TYPE:
                        vm_vnics[vif_index]['id'] = device.externalId
                        vif_index += 1
            vm_json[index]['name'] = vm_name
            vm_json[index]['ip'] = vm.guest.ipAddress
            vm_json[index]['uid'] = "ESXI/%s/%s/%s" % (self.ip, vm_name,
                                                       vm.guest.ipAddress)
            vm_json[index]['nics'] = dict(vm_vnics)
            index += 1
        return vm_json

    def connectToHypervisor(self):
        from pyVim import connect
        from pyVmomi import vmodl
        import ssl
        import atexit
        try:
            default_context = ssl._create_default_https_context
            ssl._create_default_https_context = ssl._create_unverified_context
            # create a connection and retrieve data
            # (XXX) Not sure why we need below 2 lines.
            context = ssl.SSLContext(ssl.PROTOCOL_SSLv23)
            context.verify_mode = ssl.CERT_NONE
            self.service_instance = connect.SmartConnect(
                host=self.ip, user=self.username, pwd=self.password,
                sslContext=context)
            if not self.service_instance:
                log.error(("Could not connect to the host using the specified "
                           "user id and password"))
                return -1
            ssl._create_default_https_context = default_context
            atexit.register(connect.Disconnect, self.service_instance)
            service_instance = connect.SmartConnect(host=self.ip,
                                                    user=self.username,
                                                    pwd=self.password,
                                                    sslContext=context)
            atexit.register(connect.Disconnect, service_instance)
            self.content = service_instance.RetrieveContent()
        except vmodl.MethodFault as error:
            log.error("Caught vmodl fault : " + error.msg)
            atexit.register(connect.Disconnect, self.service_instance)
            return -1

    def find_object(self, view_type, name):
        if self.content is None:
            self.connectToHypervisor()
        obj = None
        container = self.content.viewManager.CreateContainerView(
            self.content.rootFolder, view_type, True)
        for c in container.view:
                if c.name == name:
                        obj = c
                        break
        if not obj:
            raise RuntimeError("VM: %s not found in ESX" % name)
        return obj

    def find_guest_vm(self, vm_name):
        from pyVmomi import vim
        view_type = [vim.VirtualMachine]
        return self.find_object(view_type, vm_name)


class KVM(Hypervisor):
    os_type = "KVM"
    MGMT_BRIDGE = 'breth0'
    NSX_BRIDGE = 'nsx-managed'
    TUNNEL_PIF = 'eth1'  # BAD hardcoding

    def __init__(self, ip=None, username=None, password=None):
        super(KVM, self).__init__(ip=ip, username=username, password=password)
        import libvirt
        uri = "qemu+ssh://%s@%s/system?no_verify=1" % (username, ip)
        self.conn = libvirt.open(uri)
        if not self.conn:
            raise RuntimeError(("Failed to create Libvirt connection object "
                                "for %s") % ip)

    def get_pif_state(self, pif_name):
        pif_status = {}
        pif_status['name'] = pif_name
        process = subprocess.Popen(['ssh', '%s@%s' % (self.username, self.ip),
                                    'cat', '/sys/class/net/%s/operstate' % pif_name],  # noqa
                                   shell=False, stdout=subprocess.PIPE,
                                   stderr=subprocess.STDOUT)
        process.wait()
        for state in process.stdout:
            state = state.strip()
            pif_status['message'] = '%s on %s (%s) %s' % (pif_name, self.os_type, self.ip, state.upper())  # noqa
            if state == 'up':
                pif_status['type'] = 'INFO'
                ret = True
            elif state == 'down':
                pif_status['type'] = 'ERROR'
                ret = False
            else:
                raise RuntimeError
        return (ret, pif_status)

    def fix_pif_state(self, pif_name):
        # Sleep to avoid super-quick fixing
        time.sleep(5)
        process = subprocess.Popen(['ssh', '%s@%s' % (self.username, self.ip),
                                    'ifconfig', pif_name, 'up'], shell=False,
                                   stdout=subprocess.PIPE,
                                   stderr=subprocess.STDOUT)
        process.wait()
        return self.get_pif_state(pif_name)

    def get_vm_vif_info(self, raw_xml, bridge):
        """
        Sample raw_xml:
        <interface type='bridge'>
          <mac address='00:23:20:75:2a:3b'/>
          <source bridge='breth0'/>
          <virtualport type='openvswitch'>
            <parameters interfaceid='bd2ac4f2-258d-4116-9751-110c67a44c5b'/>
          </virtualport>
          <target dev='vme54f-00'/>
          <model type='virtio'/>
          <alias name='net0'/>
          <address type='pci' domain='0x0000' bus='0x00' slot='0x04' function='0x0'/>  # noqa
        </interface>
        <interface type='bridge'>
          <mac address='00:23:20:7f:3f:25'/>
          <source bridge='nsx-managed'/>
          <virtualport type='openvswitch'>
            <parameters interfaceid='8de7feb1-191f-4b92-91cf-44988b51ab0b'/>
          </virtualport>
          <target dev='vme54f-01'/>
          <model type='virtio'/>
          <alias name='net1'/>
          <address type='pci' domain='0x0000' bus='0x00' slot='0x05' function='0x0'/>  #noqa
        </interface>
        """
        vifs = collections.defaultdict(dict)
        host_xml = minidom.parseString(raw_xml)
        interfaceTypes = host_xml.getElementsByTagName('interface')
        index = 1
        for interfaceType in interfaceTypes:
            source = interfaceType.getElementsByTagName('source')
            if source[0].getAttribute('bridge') == bridge:
                macAddr = interfaceType.getElementsByTagName('mac')
                vifId = interfaceType.getElementsByTagName('virtualport')
                vifs[index]['mac'] = macAddr[0].getAttribute('address')
                vifs[index]['id'] = vifId[0].getElementsByTagName('parameters')[0].getAttribute('interfaceid')  # noqa
                index += 1
        return dict(vifs)

    def get_vm_ip(self, raw_xml):
        vifs = self.get_vm_vif_info(raw_xml, self.MGMT_BRIDGE)
        mac = vifs[1]['mac']
        process = subprocess.Popen(
            ['ssh', '%s@%s' % (self.username, self.ip), 'arp', '-a'],
            shell=False, stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT)
        process.wait()
        for line in process.stdout:
            if mac in line:
                # TODO: Separate helper with doctest
                ip_match = re.search('\((.*?)\)', line)
                ip = ip_match.groups(1)[0]
                log.debug('VM with MAC Address %s is using IP %s' % (mac, ip))
                return ip

    def get_vm_inventory(self):
        # List active VMs
        active_domains = self.conn.listDomainsID()
        if active_domains is None:
            log.error("Failed to get active domains for KVM '%s'" % self.ip)
            return -1
        vm_json = {}
        if len(active_domains) != 0:
            vm_count = 0
            for domain_id in active_domains:
                vmdetails_dict = {}
                dom = self.conn.lookupByID(domain_id)
                raw_xml = dom.XMLDesc(0)
                # XXX: We are using '_' as a special separator so
                # we need replacement with another character.
                domain_name = dom.name().replace('_', '$')
                vmdetails_dict["name"] = domain_name
                vm_mgmt_ip = self.get_vm_ip(raw_xml)
                vmdetails_dict["ip"] = vm_mgmt_ip
                vmdetails_dict["uid"] = ("KVM/%s/%s/%s" %
                                         (self.ip, domain_name, vm_mgmt_ip))
                vmdetails_dict['nics'] = self.get_vm_vif_info(raw_xml,
                                                              self.NSX_BRIDGE)
                vm_count = vm_count + 1
                vm_json[str(vm_count)] = vmdetails_dict
        self.conn.close()
        log.debug("VMs on KVM '%s':\n%s" % (self.ip, vm_json))
        return vm_json

    def find_guest_vm(self, vm_name):
        return self.conn.lookupByName(vm_name)
