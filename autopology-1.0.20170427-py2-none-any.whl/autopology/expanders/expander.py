import copy
import os
import pprint
import re
import sys
import yaml
import workload_expander
import jinja2

TAG = 'TAG'
TAGS = 'tags'
SPEC = 'spec'
SCOPE = 'SCOPE'
TAG_SCOPE = 'autopology'

# Regexes
delim_group = "(.*)<<(.*)>>(.*)"
digit_group = "^\[\s*(\d+)\s*\]$"
range_group = "^\[\s*(\d+)\s*\-\s*(\d+)\s*\]$"


def get_data_in_delim(input_str):
    """
    >>> get_data_in_delim("<<something>>")
    '{{ something }}'
    >>> get_data_in_delim("Have some << random >> template")
    'Have some {{  random  }} template'
    >>> get_data_in_delim("Have some << random >> template << called >> "
    ...                   "template1")
    'Have some << random >> template {{  called  }} template1'

    # Instance of failed nested delimiter.
    >>> get_data_in_delim("<< Nested << delim>> >>")
    '<< Nested {{  delim>>  }}'
    """
    # XXX This is unlikely to work with nested templates in the string.
    matches = re.findall(delim_group, input_str)
    if not matches:
        # No match, return the string as-is.
        return input_str
    strings = []
    for (before, template_data, after) in matches:
        strings.append("%s{{ %s }}%s" % (before, template_data, after))
    return "".join(strings)


def expand_spec(input_dict):
    """
    >>> input_dict = {
    ...     'tag': 'demo1',
    ...     'spec': {
    ...         'transport-zones': {
    ...             '[1-2]': {
    ...                 'display_name': 'TZ.<<x>>',
    ...                 'transport_zone_type': 'OVERLAY'
    ...                 }
    ...         }
    ...     }
    ... }
    >>> pprint.pprint(yaml.load(expand_spec(input_dict)))
    {'1': {'display_name': 'TZ.1',
           'tags': [{'scope': 'autopology', 'tag': 'demo1'}],
           'transport_zone_type': 'OVERLAY'},
     '2': {'display_name': 'TZ.2',
           'tags': [{'scope': 'autopology', 'tag': 'demo1'}],
           'transport_zone_type': 'OVERLAY'}}
    """
    REQUIRED_ATTRS = (TAG.lower(), SPEC)
    for req_attr in REQUIRED_ATTRS:
        if req_attr not in input_dict:
            print("%r is not provided in:\n%s" %
                  (req_attr, pprint.pformat(input_dict)))
            raise ValueError("%r is not provided" % req_attr)
    spec = input_dict[SPEC]
    jinja_str = ""
    for component in spec:
        # First level keys would be the component keys.
        for custom_range in spec[component]:
            # Second level keys are the indices.
            # XXX Converting anything to loop format regardless.
            jinja_range = custom_range_to_jinja(custom_range)
            value = {}
            sub_value = {}
            for key, val in spec[component][custom_range].iteritems():
                # Third level keys are the schema specs (no nested data
                # structures allowed as of now.)
                if type(val) not in (str, int):
                    # XXX This can be extended later if needed.
                    print ("Got a nested data structure:\n%s" %
                           pprint.pformat(val))
                    raise ValueError("Nested data structures are not allowed!")
                sub_value[get_data_in_delim(key)] = get_data_in_delim(val)
                sub_value[TAGS.lower()] = [
                    {'scope': TAG_SCOPE, 'tag': input_dict[TAG.lower()]}
                ]
            value["{{ x }}"] = sub_value
        jinja_str = ("%s%s%s%s" % (jinja_str, jinja_range,
                                   yaml.dump(value), _end_for_jinja()))
        spec[component][jinja_range] = value
    return jinja2_render(jinja_str)


def jinja2_render(data):
    """ Helper method to load all the jinja2 environment and render them """
    loader = jinja2.FileSystemLoader(".")
    ENV = jinja2.Environment(loader=loader, undefined=jinja2.StrictUndefined,
                             extensions=["jinja2.ext.do"])
    tmpl = ENV.from_string(data)
    return tmpl.render()


def _for_jinja(min_, max_):
    return "\n{%% for x in range(%s, %s) %%}\n" % (min_, max_)


def _end_for_jinja():
    return "\n{% endfor %}\n"


def custom_range_to_jinja(input_str):
    """
    >>> custom_range_to_jinja("[1-100]")
    '\\n{% for x in range(1, 101) %}\\n'
    >>> custom_range_to_jinja("[1]")
    '\\n{% for x in range(1, 2) %}\\n'
    """
    range_match = re.match(range_group, input_str)
    digit_match = None
    if not range_match:
        digit_match = re.match(digit_group, input_str)
        if not digit_match:
            raise ValueError("%r is not in the right '[min-max]' range or "
                             "'[index]' format" % input_str)
    if range_match:
        min_, max_ = map(int, range_match.groups())
        if min_ > max_:
            raise ValueError("Starting index should be strictly less than the "
                             "ending index, got: %r" % input_str)
        # XXX: This will fail if the user tries to use any other index instead
        # of 'x' in the template body.
        return _for_jinja(min_, max_ + 1)
    digit = int(digit_match.groups()[0])
    # XXX HAX to make the caller work seamlessly.
    return _for_jinja(digit, digit + 1)


class Topology(object):
    PLR = 'PLR'
    TLR = 'TLR'
    LS = 'LS'
    LSP = 'LSP'
    ULRP = 'ULRP'
    DLRP = 'DLRP'
    LLRP = 'LLRP'
    FN = 'FN'
    TN = 'TN'
    VLS = 'VLS'
    VNIC = 'VNIC'
    # FN Schema params.
    TYPE = 'type'
    # Component types.
    relational_components = (PLR, TLR, LS, VLS, VNIC)
    derived_components = (LSP, ULRP, DLRP, LLRP)
    # Host types
    HOSTNODE = "hostnode"
    KVM = "KVM"
    ESX = "ESX"
    EDGE = "EDGE"
    host_type_hv = "Host"
    host_type_edge = "Edge"
    # These components are not related to any parent (though we could have
    # created association if we had exposed the internally created logical
    # component e.g. TN for FN to the user)
    standalone_components = (FN)
    BORATHON_ID = 'borathonid'  # Unique per component.
    BORA = 'BORA'
    HARDCODED_WORKLOADS = (
        "CreateUPROF_NAME-UPROF1", "CreateTZ_NAME-TZ1_TZTYPE-OVERLAY",
        "CreateTZ_NAME-TZ2_TZTYPE-VLAN",
        "CreateIPPool_NAME-IPP1_RANGES-1:192.1.0.10,192.1.250.250_CIDR-192.1.0.0/16",  # noqa
        "CreateCPROF_NAME-CPROF1")

    EDGE_CLUSTER_NAME = "EC1"  # XXX Only one EDGE cluster is allowed.
    # XXX Only 255 downlink ports per router.
    DL_SUBNET = "%s.1_PREFIX-24"
    UL_SUBNET_OFFSET = 50  # Randomly chosen.
    # XXX Only 255 - UL_SUBNET_OFFSET subnets allowed for uplink VLSes.
    UL_SUBNET = "IP-192.168.%s.1_PREFIX-24"
    FILTER_PARAMS = ('x', 'y', BORATHON_ID)

    # WokloadsToDict Constants
    short_to_long = {'TZ': 'transport-zones',
                     'IPPool': 'ip-pool',
                     'TN': 'transport-nodes',
                     'PLR': 'logical-routers',
                     'LS': 'logical-switches',
                     'VLS': 'logical-switches',
                     'LSP': 'logical-ports',
                     'CPROF': 'cluster-profiles',
                     'EdgeCluster': 'edge-clusters',
                     'TLR': 'logical-routers',
                     'ULRP': 'logical-router-ports',
                     'DLRP': 'logical-router-ports',
                     'UPROF': 'uplink-profiles',
                     'PlrLLRP': 'logical-router-ports',
                     'AdvertisementGlobalConfigOnLR': '/logical-routers/%s/routing/advertisement',  # noqa
                     'LRBGP': '/logical-routers/%s/routing/bgp',
                     'LRBGPNbr': '/logical-routers/%s/routing/bgp/neighbors',  # noqa
                     'LRRedistributionConfig': '/logical-routers/%s/routing/redistribution',  # noqa
                     'TlrLLRP': 'logical-router-ports',
                     'VNIC': 'create-nic'}

    # WokloadsToDict Code
    @classmethod
    def get_key(cls, line):
        """
        >>> line = 'CreateTZ_NAME-TZ1'
        >>> expected = Topology.short_to_long['TZ']
        >>> Topology.get_key(line) == expected
        True
        >>> line = 'CreateLRBGPNbr_NAME-PLR1VLS1'
        >>> expected = '/logical-routers/PLR1/routing/bgp/neighbors'
        >>> Topology.get_key(line) == expected
        True
        >>> line = 'CreateLRRedistributionConfig_NAME-PLR1'
        >>> expected = '/logical-routers/PLR1/routing/redistribution'
        >>> Topology.get_key(line) == expected
        True
        >>> line = 'CreateAdvertisementGlobalConfigOnLR_NAME-PLR1TLR1'
        >>> expected = '/logical-routers/PLR1TLR1/routing/advertisement'
        >>> Topology.get_key(line) == expected
        True
        """
        key_separator = '_'
        create_key = 'Create'
        # XXX(Autopology): 1st element will always be the Create key.
        create_key_index = 0
        # XXX(Autopology): 2nd element will always be the Name key.
        name_key_index = 1
        # XXX: name will be found at 12345<value>
        # XXX: name will be found at NAME-<value>
        name_offset = 5
        # XXX: name will be in format PLRx
        tier0_lr = 'PLR'
        max_plr_num = '9'
        plr_name_len = len(tier0_lr) + len(max_plr_num)
        if line.startswith('# '):
            return None
        lines = line.split(key_separator)
        start_of_short_index = len(create_key)
        short_str = lines[create_key_index][start_of_short_index:]
        name = lines[name_key_index][name_offset:]
        if short_str in ['LRBGP', 'LRBGPNbr', 'LRRedistributionConfig']:
            name = name[:plr_name_len]
        long_str = cls.short_to_long[short_str]
        # XXX: replace %s with NAME value in long string
        if '%s' in long_str:
            long_str = long_str % name
        return long_str

    @classmethod
    def list_to_dict(cls, wl_list):
        wl_dict = {}
        for line in wl_list:
            key = cls.get_key(line)
            if key is None:
                continue
            value = line[0:len(line)]
            if key not in wl_dict:
                wl_dict[key] = [value]
            else:
                wl_dict[key].append(value)
        return wl_dict

    # ComplextToCompact Code
    @classmethod
    def merge_dicts(cls, expanded, compact, expanded_original, dict1Key):
        """
        Merges url and id values into dict2 for corresponding keys in dict1
        """
        return cls._merge_dicts(expanded, compact['spec'],
                                expanded_original, dict1Key)

    @classmethod
    def _merge_dicts(cls, expanded, compact, expanded_original, dict1Key):
        """
        >>> a = {'logical-routers':
        ...         {'PLR1':
        ...             {'id': 1, 'url': 1, 'display_name': 'name'}}}
        >>> b = {'PLR': {'1': {}}}
        >>> Topology._merge_dicts(a, b, a, '')
        {'PLR': {'1': {'url': 1, 'display_name': 'name', 'id': 1}}}
        >>> d1 = {
        ...     'logical-routers': {
        ...         'PLR1': {'display_name': 'somename', 'id': 1, 'url': 1},
        ...         'PLR1TLR2': {'display_name': 'name2', 'id': 2, 'url': 3},
        ...         'PLR1TLR1': {'display_name': 'name3', 'id': 3, 'url': 4},},
        ...     'logical-switches': {
        ...         'PLR1TLR1LS1': {'display_name': 5, 'id': 1, 'url': 3}},
        ...     'vifs': {
        ...         'PLR1TLR1LS1VNIC1':
        ...                 {'display_name': 'Vif1', 'id': 2, 'url': 5}
        ...             }
        ...     }
        >>> d2 = {'PLR': {'1':
        ...         {'TLR': {'1':
        ...                  {'name': 'name',
        ...                   "LS": {"1":
        ...                          {"VNIC": {1: {"display_name": "vif2"}}}}},
        ...                  '2': {'display_name': 'nameTLR1'}},
        ...                'display_name': 'somename'}
        ...              }
        ...      }
        >>> expected = {
        ...     'PLR': {'1': {'TLR': {'1': {'LS': {'1': {'VNIC': {1: {'display_name': 'Vif1',  # noqa
        ...                                                            'id': 2,
        ...                                                            'url': 5}},  # noqa
        ...                                               'display_name': 5,
        ...                                               'id': 1,
        ...                                               'url': 3}},
        ...                                  'display_name': 'name3',
        ...                                  'id': 3,
        ...                                  'name': 'name',
        ...                                  'url': 4},
        ...                            '2': {'display_name': 'name2', 'id': 2, 'url': 3}},  # noqa
        ...                    'display_name': 'somename',
        ...                    'id': 1,
        ...                    'url': 1}
        ...                    }
        ... }
        >>> Topology._merge_dicts(d1, d2, d1, '') == expected
        True
        """
        mapping = {'PLR': 'logical-routers', 'TLR': 'logical-routers',
                   'LS': 'logical-switches', 'VLS': 'logical-switches',
                   'VNIC': 'vifs'}
        for ckey in compact:
            try:
                val = int(ckey)
            except ValueError:
                val = None
            if val is not None:
                # TRACE print 'Handling', ckey
                d1Key = dict1Key + str(ckey)
                if d1Key in expanded:
                    compact[ckey]['url'] = expanded[d1Key].get('url', '')
                    compact[ckey]['id'] = expanded[d1Key]['id']
                    compact[ckey]['display_name'] = expanded[d1Key]['display_name']  # noqa
                else:
                    compact[ckey]['url'] = None
                    compact[ckey]['id'] = None
                for key2 in compact[ckey]:
                    if key2 not in ['PLR', 'TLR', 'LS', 'VLS', 'VNIC']:
                        pass
                    else:
                        if type(key2) is str:
                            if mapping[key2] in expanded_original:
                                cls._merge_dicts(
                                    expanded_original[mapping[key2]],
                                    compact[ckey][key2],
                                    expanded_original,
                                    d1Key + key2)
            elif ckey not in mapping:
                # TRACE print 'Ignoring', ckey
                pass
            elif type(ckey) is str and (mapping[ckey] in expanded):
                # TRACE print 'Recursing', ckey
                cls._merge_dicts(expanded_original[mapping[ckey]],
                                 compact[ckey], expanded_original,
                                 dict1Key + ckey)
            else:
                # TRACE print 'Ignoring', ckey
                pass
        return compact

    # Bulk expander
    @classmethod
    def generate_missing_workloads(cls, input_dict):
        data = {}
        for k in input_dict:
            dct = {}
            tds_list = input_dict[k]
            for x in sorted(list(set(tds_list))):
                dct.update(workload_expander.expand_template(x))
            data[k] = dct
        return data

    def __init__(self):
        # XXX Only 1 EDGE cluster is allowed and we maintain its membership
        # here.
        self.edges = []  # Number of edges.
        self.vlses = 0  # Number of VLS'es.
        self.edge_ips = []  # IP addresses for Edge TNs

    def filter_key(self, input_dict):
        """
        Helper to filter keys from a dict.

        >>> T = Topology()
        >>> input_dict = {
        ...     'a': 1,
        ...     'b': 2,
        ...     'x': 1,
        ...     'y': 2,
        ...     'borathonid': 5
        ... }
        >>> T.filter_key(input_dict)
        {'a': 1, 'b': 2}
        >>> input2= {
        ...     'a': 1,
        ...     'b': 2,
        ...     'x': 1,
        ...     'y': 2,
        ...     'borathonid': 5,
        ...     'k1': {
        ...         'v1': 10,
        ...         'borathonid': 12
        ...     },
        ...     'k2': [1, 2, 3, 5, 7, {'x': "whoops"}]
        ... }
        >>> pprint.pprint(T.filter_key(input2))
        {'a': 1, 'b': 2, 'k1': {'v1': 10}, 'k2': [1, 2, 3, 5, 7, {}]}
        """
        new_d = {}
        for k, v in input_dict.iteritems():
            if type(v) is dict:
                new_d[k] = self.filter_key(v)
            elif type(v) in (list, tuple):
                new_l = []
                for elem in v:
                    if type(elem) in (list, dict, tuple):
                        new_l.append(self.filter_key(elem))
                    elif k in self.FILTER_PARAMS:
                        continue
                    else:
                        new_l.append(elem)
                new_d[k] = new_l
            elif k in self.FILTER_PARAMS:
                continue
            else:
                new_d[k] = v
        return new_d

    def convert_ui_schema_to_workload_list(self, input_dict):
        """
        >>> T = Topology()
        >>> final_count_down = {
        ...     "tag": "demo",
        ...     "spec": {
        ...         "PLR": {
        ...             "1": {
        ...                 "x": 176,
        ...                 "y": 137,
        ...                 "borathonid": "PLR_c0c78a13d27341c23c7d722301c6b5b7",  # noqa
        ...                 "TLR": {
        ...                     "1": {
        ...                         "x": 237,
        ...                         "y": 232,
        ...                         "borathonid": "TLR_bff1ee32de8fe6ad249ceaabdd8d78e6",  # noqa
        ...                         "route_advertisement": "enabled",
        ...                         "LS": {
        ...                             "1": {
        ...                                 "x": 153,
        ...                                 "y": 294,
        ...                                 "borathonid": "LS_e60d11dc99b6220c75ee4b6f1947ed8f",  # noqa
        ...                                 "replication_mode": "SOURCE"
        ...                             },
        ...                             "2": {
        ...                                 "x": 290,
        ...                                 "y": 329,
        ...                                 "borathonid": "LS_bff1ee32de8fe6ad249ceaabdd8d78e6",  # noqa
        ...                                 "replication_mode": "MTEP",
        ...                                 "VNIC":
        ...                                        {'1':
        ...                                              {
        ...                                                  'UUID': 'KVM/10.10.10.10/testvm2/1'
        ...                                              },
        ...                                         '2':
        ...                                              {
        ...                                                  'UUID': 'ESXI/10.10.10.10/testvm2/2'
        ...                                              }
        ...                                        }
        ...                             }
        ...                         }
        ...                     },
        ...                     "2": {
        ...                         "x": 337,
        ...                         "y": 232,
        ...                         "borathonid": "TLR_0dcbeed26fffe94377b7ba07dc9f90e4",  # noqa
        ...                         "route_advertisement": "enabled",
        ...                         "LS": {
        ...                             "1": {
        ...                                 "x": 253,
        ...                                 "y": 294,
        ...                                 "borathonid": "LS_e8b44ae9c184f5381d1528e9e1896bf6",  # noqa
        ...                                 "replication_mode": "SOURCE"
        ...                             },
        ...                             "2": {
        ...                                 "x": 390,
        ...                                 "y": 329,
        ...                                 "borathonid": "LS_0dcbeed26fffe94377b7ba07dc9f90e4",  # noqa
        ...                                 "replication_mode": "MTEP"
        ...                             }
        ...                         }
        ...                     },
        ...                     "3": {
        ...                         "x": 437,
        ...                         "y": 232,
        ...                         "borathonid": "TLR_a6135217fa8c293bb921d408e3c7f1bc",  # noqa
        ...                         "route_advertisement": "enabled",
        ...                         "LS": {
        ...                             "1": {
        ...                                 "x": 353,
        ...                                 "y": 294,
        ...                                 "borathonid": "LS_607933abfe86702ebac6db9f04101845",  # noqa
        ...                                 "replication_mode": "SOURCE"
        ...                             },
        ...                             "2": {
        ...                                 "x": 490,
        ...                                 "y": 329,
        ...                                 "borathonid": "LS_a6135217fa8c293bb921d408e3c7f1bc",  # noqa
        ...                                 "replication_mode": "MTEP"
        ...                             }
        ...                         }
        ...                     },
        ...                     "4": {
        ...                         "x": 137,
        ...                         "y": 232,
        ...                         "borathonid": "TLR_c7788a63e3376163d848ab0f9fd57f94",  # noqa
        ...                         "route_advertisement": "enabled",
        ...                         "LS": {
        ...                             "1": {
        ...                                 "x": 53,
        ...                                 "y": 294,
        ...                                 "borathonid": "LS_c644ef9eac738d13f41f07137ed498cc",  # noqa
        ...                                 "replication_mode": "SOURCE"
        ...                             },
        ...                             "2": {
        ...                                 "x": 190,
        ...                                 "y": 329,
        ...                                 "borathonid": "LS_5dcc03d4b27e351147f4348285e81c7e",  # noqa
        ...                                 "replication_mode": "MTEP"
        ...                             }
        ...                         }
        ...                     },
        ...                     "5": {
        ...                         "x": 590,
        ...                         "y": 226,
        ...                         "borathonid": "TLR_bed61a66873c473b3cb765ee085e1fe9",  # noqa
        ...                         "route_advertisement": "disabled",
        ...                         "LS": {
        ...                             "1": {
        ...                                 "x": 686,
        ...                                 "y": 327,
        ...                                 "borathonid": "LS_b7b25c313a51a296f8d3343ce24f6efc",  # noqa
        ...                                 "replication_mode": "SOURCE"
        ...                             }
        ...                         }
        ...                     },
        ...                     "6": {
        ...                         "x": 690,
        ...                         "y": 226,
        ...                         "borathonid": "TLR_dd6e2f9ab961893e76c33cd0e70ccae6",  # noqa
        ...                         "route_advertisement": "disabled",
        ...                         "LS": {
        ...                             "1": {
        ...                                 "x": 786,
        ...                                 "y": 327,
        ...                                 "borathonid": "LS_624a50c3a8068a81598016b612354850",  # noqa
        ...                                 "replication_mode": "SOURCE"
        ...                             }
        ...                         }
        ...                     },
        ...                     "7": {
        ...                         "x": 490,
        ...                         "y": 226,
        ...                         "borathonid": "TLR_facfa53abdaf2f0d0a548d0521adae5e",  # noqa
        ...                         "route_advertisement": "disabled",
        ...                         "LS": {
        ...                             "1": {
        ...                                 "x": 586,
        ...                                 "y": 327,
        ...                                 "borathonid": "LS_f634e6a5d9ad92437c3f5603b210b8eb",  # noqa
        ...                                 "replication_mode": "SOURCE"
        ...                             }
        ...                         }
        ...                     }
        ...                 },
        ...                 "VLS": {
        ...                     "1": {
        ...                         "x": 426,
        ...                         "y": 149,
        ...                         "borathonid": "VLS_2a978021c3651fde691e776063d532e9",  # noqa
        ...                         "vlan_id": "1111"
        ...                     },
        ...                     "50": {
        ...                         "x": 4,
        ...                         "y": 1,
        ...                         "borathonid": "VLS_50",  # noqa
        ...                         "vlan_id": "222",
        ...                         "REMOTEAS": "some_as",
        ...                         "NBRIP": "some_ip",
        ...                     }
        ...                 }
        ...             }
        ...         },
        ...         "FN": {
        ...             "1": {
        ...                 "borathonid": "FN_b2beac4a34cd1e59686bb03a53c5c41b",  # noqa
        ...                 "type": "EDGE",
        ...                 "hostnode": "11111"
        ...             },
        ...             "2": {
        ...                 "borathonid": "FN_b2beac4a34cd1e59686bb03a53c5c41b",  # noqa
        ...                 "type": "EDGE",
        ...                 "hostnode": "11111"
        ...             }
        ...         }
        ...     }
        ... }
        >>> exp = [
        ...     'CreateUPROF_NAME-UPROF1',
        ...     'CreateTZ_NAME-TZ1_TZTYPE-OVERLAY',
        ...     'CreateTZ_NAME-TZ2_TZTYPE-VLAN',
        ...     'CreateIPPool_NAME-IPP1_RANGES-1:192.1.0.10,192.1.250.250_CIDR-192.1.0.0/16',  # noqa
        ...     'CreateCPROF_NAME-CPROF1',  # noqa
        ...     'CreateTN_NAME-TN1_SCOPE-autopology_TAG-demo_IPPOOL-IPP1_UPROF-UPROF1_FPETH-1_TZ-1-2_HOSTNODE-11111',  # noqa
        ...     'CreateTN_NAME-TN2_SCOPE-autopology_TAG-demo_IPPOOL-IPP1_UPROF-UPROF1_FPETH-1_TZ-1-2_HOSTNODE-11111',  # noqa
        ...     'CreateAdvertisementGlobalConfigOnLR_NAME-PLR1TLR1_ADVERTISECONNECTED-True_ADVERTISENAT-True_ADVERTISESTATIC-True',  # noqa
        ...     'CreateAdvertisementGlobalConfigOnLR_NAME-PLR1TLR2_ADVERTISECONNECTED-True_ADVERTISENAT-True_ADVERTISESTATIC-True',  # noqa
        ...     'CreateAdvertisementGlobalConfigOnLR_NAME-PLR1TLR3_ADVERTISECONNECTED-True_ADVERTISENAT-True_ADVERTISESTATIC-True',  # noqa
        ...     'CreateAdvertisementGlobalConfigOnLR_NAME-PLR1TLR4_ADVERTISECONNECTED-True_ADVERTISENAT-True_ADVERTISESTATIC-True',  # noqa
        ...     'CreateAdvertisementGlobalConfigOnLR_NAME-PLR1TLR5_ADVERTISECONNECTED-True_ADVERTISENAT-True_ADVERTISESTATIC-True',  # noqa
        ...     'CreateAdvertisementGlobalConfigOnLR_NAME-PLR1TLR6_ADVERTISECONNECTED-True_ADVERTISENAT-True_ADVERTISESTATIC-True',  # noqa
        ...     'CreateAdvertisementGlobalConfigOnLR_NAME-PLR1TLR7_ADVERTISECONNECTED-True_ADVERTISENAT-True_ADVERTISESTATIC-True',  # noqa
        ...     'CreateDLRP_NAME-PLR1TLR1LS1DLRP_LSP-LS1TLR1PLR1LSP_LR-PLR1TLR1_SCOPE-autopology_TAG-demo_IP-191.1.1.1_PREFIX-24',  # noqa
        ...     'CreateDLRP_NAME-PLR1TLR1LS2DLRP_LSP-LS2TLR1PLR1LSP_LR-PLR1TLR1_SCOPE-autopology_TAG-demo_IP-191.1.2.1_PREFIX-24',  # noqa
        ...     'CreateDLRP_NAME-PLR1TLR2LS1DLRP_LSP-LS1TLR2PLR1LSP_LR-PLR1TLR2_SCOPE-autopology_TAG-demo_IP-191.2.1.1_PREFIX-24',  # noqa
        ...     'CreateDLRP_NAME-PLR1TLR2LS2DLRP_LSP-LS2TLR2PLR1LSP_LR-PLR1TLR2_SCOPE-autopology_TAG-demo_IP-191.2.2.1_PREFIX-24',  # noqa
        ...     'CreateDLRP_NAME-PLR1TLR3LS1DLRP_LSP-LS1TLR3PLR1LSP_LR-PLR1TLR3_SCOPE-autopology_TAG-demo_IP-191.3.1.1_PREFIX-24',  # noqa
        ...     'CreateDLRP_NAME-PLR1TLR3LS2DLRP_LSP-LS2TLR3PLR1LSP_LR-PLR1TLR3_SCOPE-autopology_TAG-demo_IP-191.3.2.1_PREFIX-24',  # noqa
        ...     'CreateDLRP_NAME-PLR1TLR4LS1DLRP_LSP-LS1TLR4PLR1LSP_LR-PLR1TLR4_SCOPE-autopology_TAG-demo_IP-191.4.1.1_PREFIX-24',  # noqa
        ...     'CreateDLRP_NAME-PLR1TLR4LS2DLRP_LSP-LS2TLR4PLR1LSP_LR-PLR1TLR4_SCOPE-autopology_TAG-demo_IP-191.4.2.1_PREFIX-24',  # noqa
        ...     'CreateDLRP_NAME-PLR1TLR5LS1DLRP_LSP-LS1TLR5PLR1LSP_LR-PLR1TLR5_SCOPE-autopology_TAG-demo_IP-191.5.1.1_PREFIX-24',  # noqa
        ...     'CreateDLRP_NAME-PLR1TLR6LS1DLRP_LSP-LS1TLR6PLR1LSP_LR-PLR1TLR6_SCOPE-autopology_TAG-demo_IP-191.6.1.1_PREFIX-24',  # noqa
        ...     'CreateDLRP_NAME-PLR1TLR7LS1DLRP_LSP-LS1TLR7PLR1LSP_LR-PLR1TLR7_SCOPE-autopology_TAG-demo_IP-191.7.1.1_PREFIX-24',  # noqa
        ...     'CreateLRBGPNbr_NAME-PLR1VLS50_REMOTEAS-some_as_NBRIP-some_ip_HDTIMER-4_KATIMER-1',  # noqa
        ...     'CreateLRBGP_NAME-PLR1VLS1_ENABLED-True_ECMP-false_GR-false_LOCALAS-200',  # noqa
        ...     'CreateLRBGP_NAME-PLR1VLS50_ENABLED-True_ECMP-false_GR-false_LOCALAS-200',  # noqa
        ...     'CreateLSP_NAME-LS1TLR1PLR1LSP_LS-PLR1TLR1LS1_ATYPE-logicalrouter_SCOPE-autopology_TAG-demo',  # noqa
        ...     'CreateLSP_NAME-LS1TLR2PLR1LSP_LS-PLR1TLR2LS1_ATYPE-logicalrouter_SCOPE-autopology_TAG-demo',  # noqa
        ...     'CreateLSP_NAME-LS1TLR3PLR1LSP_LS-PLR1TLR3LS1_ATYPE-logicalrouter_SCOPE-autopology_TAG-demo',  # noqa
        ...     'CreateLSP_NAME-LS1TLR4PLR1LSP_LS-PLR1TLR4LS1_ATYPE-logicalrouter_SCOPE-autopology_TAG-demo',  # noqa
        ...     'CreateLSP_NAME-LS1TLR5PLR1LSP_LS-PLR1TLR5LS1_ATYPE-logicalrouter_SCOPE-autopology_TAG-demo',  # noqa
        ...     'CreateLSP_NAME-LS1TLR6PLR1LSP_LS-PLR1TLR6LS1_ATYPE-logicalrouter_SCOPE-autopology_TAG-demo',  # noqa
        ...     'CreateLSP_NAME-LS1TLR7PLR1LSP_LS-PLR1TLR7LS1_ATYPE-logicalrouter_SCOPE-autopology_TAG-demo',  # noqa
        ...     'CreateLSP_NAME-LS2TLR1PLR1LSP_LS-PLR1TLR1LS2_ATYPE-logicalrouter_SCOPE-autopology_TAG-demo',  # noqa
        ...     'CreateLSP_NAME-LS2TLR2PLR1LSP_LS-PLR1TLR2LS2_ATYPE-logicalrouter_SCOPE-autopology_TAG-demo',  # noqa
        ...     'CreateLSP_NAME-LS2TLR3PLR1LSP_LS-PLR1TLR3LS2_ATYPE-logicalrouter_SCOPE-autopology_TAG-demo',  # noqa
        ...     'CreateLSP_NAME-LS2TLR4PLR1LSP_LS-PLR1TLR4LS2_ATYPE-logicalrouter_SCOPE-autopology_TAG-demo',  # noqa
        ...     'CreateLSP_NAME-VLS1PLR1LSP_LS-PLR1VLS1',  # noqa
        ...     'CreateLSP_NAME-VLS50PLR1LSP_LS-PLR1VLS50',  # noqa
        ...     'CreateLS_NAME-PLR1TLR1LS1_replication_mode-SOURCE_SCOPE-autopology_TAG-demo_TZ-TZ1_IP-191.1.1.0_PREFIX-24',  # noqa
        ...     'CreateLS_NAME-PLR1TLR1LS2_replication_mode-MTEP_SCOPE-autopology_TAG-demo_TZ-TZ1_IP-191.1.2.0_PREFIX-24',  # noqa
        ...     'CreateLS_NAME-PLR1TLR2LS1_replication_mode-SOURCE_SCOPE-autopology_TAG-demo_TZ-TZ1_IP-191.2.1.0_PREFIX-24',  # noqa
        ...     'CreateLS_NAME-PLR1TLR2LS2_replication_mode-MTEP_SCOPE-autopology_TAG-demo_TZ-TZ1_IP-191.2.2.0_PREFIX-24',  # noqa
        ...     'CreateLS_NAME-PLR1TLR3LS1_replication_mode-SOURCE_SCOPE-autopology_TAG-demo_TZ-TZ1_IP-191.3.1.0_PREFIX-24',  # noqa
        ...     'CreateLS_NAME-PLR1TLR3LS2_replication_mode-MTEP_SCOPE-autopology_TAG-demo_TZ-TZ1_IP-191.3.2.0_PREFIX-24',  # noqa
        ...     'CreateLS_NAME-PLR1TLR4LS1_replication_mode-SOURCE_SCOPE-autopology_TAG-demo_TZ-TZ1_IP-191.4.1.0_PREFIX-24',  # noqa
        ...     'CreateLS_NAME-PLR1TLR4LS2_replication_mode-MTEP_SCOPE-autopology_TAG-demo_TZ-TZ1_IP-191.4.2.0_PREFIX-24',  # noqa
        ...     'CreateLS_NAME-PLR1TLR5LS1_replication_mode-SOURCE_SCOPE-autopology_TAG-demo_TZ-TZ1_IP-191.5.1.0_PREFIX-24',  # noqa
        ...     'CreateLS_NAME-PLR1TLR6LS1_replication_mode-SOURCE_SCOPE-autopology_TAG-demo_TZ-TZ1_IP-191.6.1.0_PREFIX-24',  # noqa
        ...     'CreateLS_NAME-PLR1TLR7LS1_replication_mode-SOURCE_SCOPE-autopology_TAG-demo_TZ-TZ1_IP-191.7.1.0_PREFIX-24',  # noqa
        ...     'CreatePLR_NAME-PLR1_SCOPE-autopology_TAG-demo_HA-ACTIVE-ACTIVE_EDGECLUSTER-EC1',  # noqa
        ...     'CreateLRRedistributionConfig_NAME-PLR1',  # noqa
        ...     'CreatePlrLLRP_NAME-PLR1TLR1LLRP_LR-PLR1_SCOPE-autopology_TAG-demo',  # noqa
        ...     'CreatePlrLLRP_NAME-PLR1TLR2LLRP_LR-PLR1_SCOPE-autopology_TAG-demo',  # noqa
        ...     'CreatePlrLLRP_NAME-PLR1TLR3LLRP_LR-PLR1_SCOPE-autopology_TAG-demo',  # noqa
        ...     'CreatePlrLLRP_NAME-PLR1TLR4LLRP_LR-PLR1_SCOPE-autopology_TAG-demo',  # noqa
        ...     'CreatePlrLLRP_NAME-PLR1TLR5LLRP_LR-PLR1_SCOPE-autopology_TAG-demo',  # noqa
        ...     'CreatePlrLLRP_NAME-PLR1TLR6LLRP_LR-PLR1_SCOPE-autopology_TAG-demo',  # noqa
        ...     'CreatePlrLLRP_NAME-PLR1TLR7LLRP_LR-PLR1_SCOPE-autopology_TAG-demo',  # noqa
        ...     'CreateTLR_NAME-PLR1TLR1_route_advertisement-enabled_SCOPE-autopology_TAG-demo',  # noqa
        ...     'CreateTLR_NAME-PLR1TLR2_route_advertisement-enabled_SCOPE-autopology_TAG-demo',  # noqa
        ...     'CreateTLR_NAME-PLR1TLR3_route_advertisement-enabled_SCOPE-autopology_TAG-demo',  # noqa
        ...     'CreateTLR_NAME-PLR1TLR4_route_advertisement-enabled_SCOPE-autopology_TAG-demo',  # noqa
        ...     'CreateTLR_NAME-PLR1TLR5_route_advertisement-disabled_SCOPE-autopology_TAG-demo',  # noqa
        ...     'CreateTLR_NAME-PLR1TLR6_route_advertisement-disabled_SCOPE-autopology_TAG-demo',  # noqa
        ...     'CreateTLR_NAME-PLR1TLR7_route_advertisement-disabled_SCOPE-autopology_TAG-demo',  # noqa
        ...     'CreateTlrLLRP_NAME-TLR1PLR1LLRP_LR-PLR1TLR1_PLRP-PLR1TLR1LLRP_SCOPE-autopology_TAG-demo',  # noqa
        ...     'CreateTlrLLRP_NAME-TLR2PLR1LLRP_LR-PLR1TLR2_PLRP-PLR1TLR2LLRP_SCOPE-autopology_TAG-demo',  # noqa
        ...     'CreateTlrLLRP_NAME-TLR3PLR1LLRP_LR-PLR1TLR3_PLRP-PLR1TLR3LLRP_SCOPE-autopology_TAG-demo',  # noqa
        ...     'CreateTlrLLRP_NAME-TLR4PLR1LLRP_LR-PLR1TLR4_PLRP-PLR1TLR4LLRP_SCOPE-autopology_TAG-demo',  # noqa
        ...     'CreateTlrLLRP_NAME-TLR5PLR1LLRP_LR-PLR1TLR5_PLRP-PLR1TLR5LLRP_SCOPE-autopology_TAG-demo',  # noqa
        ...     'CreateTlrLLRP_NAME-TLR6PLR1LLRP_LR-PLR1TLR6_PLRP-PLR1TLR6LLRP_SCOPE-autopology_TAG-demo',  # noqa
        ...     'CreateTlrLLRP_NAME-TLR7PLR1LLRP_LR-PLR1TLR7_PLRP-PLR1TLR7LLRP_SCOPE-autopology_TAG-demo',  # noqa
        ...     'CreateULRP_NAME-PLR1ULRP1_LR-PLR1_LSP-VLS1PLR1LSP_TN1_IP-192.168.51.1_PREFIX-24',  # noqa
        ...     'CreateULRP_NAME-PLR1ULRP50_LR-PLR1_LSP-VLS50PLR1LSP_TN2_IP-192.168.100.1_PREFIX-24',  # noqa
        ...     'CreateVLS_NAME-PLR1VLS1_vlan_id-1111_SCOPE-autopology_TAG-demo_TZ-TZ2',  # noqa
        ...     'CreateVLS_NAME-PLR1VLS50_NBRIP-some_ip_REMOTEAS-some_as_vlan_id-222_SCOPE-autopology_TAG-demo_TZ-TZ2',  # noqa
        ...     'CreateVNIC_NAME-PLR1TLR1LS2LSP1_UUID-KVM/10.10.10.10/testvm2/1_SCOPE-autopology_TAG-demo_ATYPE-VIF_IP-191.1.2.11_PREFIX-24_LS-PLR1TLR1LS2',  # noqa
        ...     'CreateVNIC_NAME-PLR1TLR1LS2LSP2_UUID-ESXI/10.10.10.10/testvm2/2_SCOPE-autopology_TAG-demo_ATYPE-VIF_IP-191.1.2.12_PREFIX-24_LS-PLR1TLR1LS2',  # noqa
        ...     'CreateTN_NAME-KVM10.10.10.10_SCOPE-autopology_TAG-demo_ATYPE-VIF_IP-191.1.2.11_PREFIX-24_LS-PLR1TLR1LS_IPPOOL-IPP1_UPROF-UPROF1_TZ-1_HOSTNODE-10.10.10.10_ETH-1',  # noqa
        ...     'CreateTN_NAME-ESX10.10.10.10_SCOPE-autopology_TAG-demo_ATYPE-VIF_IP-191.1.2.12_PREFIX-24_LS-PLR1TLR1LS_IPPOOL-IPP1_UPROF-UPROF1_TZ-1_HOSTNODE-10.10.10.10_VMNIC-1',  # noqa
        ...     'CreateEdgeCluster_NAME-EC1_TN-11111,11111_SCOPE-autopology_TAG-demo'  # noqa
        ... ]
        >>> T.convert_ui_schema_to_workload_list(
        ...         final_count_down) == exp
        True
        >>> final_count_down = {
        ...     "tag": "demo",
        ...     "spec": {
        ...         "PLR": {
        ...             "1": {
        ...                 "x": 176,
        ...                 "y": 137,
        ...                 "borathonid": "PLR_c0c78a13d27341c23c7d722301c6b5b7",  # noqa
        ...                 "LS":
        ...                     {
        ...                         "1": {
        ...                                 "RMODE": "SOURCE"
        ...                         }
        ...                     }
        ...                 }
        ...             }
        ...         }
        ... }
        >>> T = Topology()
        >>> exp = [
        ...     'CreateUPROF_NAME-UPROF1',
        ...     'CreateTZ_NAME-TZ1_TZTYPE-OVERLAY',
        ...     'CreateTZ_NAME-TZ2_TZTYPE-VLAN',
        ...     'CreateIPPool_NAME-IPP1_RANGES-1:192.1.0.10,192.1.250.250_CIDR-192.1.0.0/16',  # noqa
        ...     'CreateCPROF_NAME-CPROF1',  # noqa
        ...     'CreateDLRP_NAME-PLR1LS1DLRP_LSP-LS1PLR1LSP_LR-PLR1_SCOPE-autopology_TAG-demo_IP-191.0.1.1_PREFIX-24',  # noqa
        ...     'CreateLSP_NAME-LS1PLR1LSP_LS-PLR1LS1_ATYPE-logicalrouter_SCOPE-autopology_TAG-demo',  # noqa
        ...     'CreateLS_NAME-PLR1LS1_RMODE-SOURCE_SCOPE-autopology_TAG-demo_TZ-TZ1_IP-191.0.1.0_PREFIX-24',  # noqa
        ...     'CreatePLR_NAME-PLR1_SCOPE-autopology_TAG-demo_HA-ACTIVE-ACTIVE',
        ...     'CreateLRRedistributionConfig_NAME-PLR1']
        >>> T.convert_ui_schema_to_workload_list(
        ...         final_count_down) == exp
        True
        >>> final_count_down = {
        ...     "tag": "demo",
        ...     "spec": {
        ...         "PLR": {
        ...             "1": {
        ...                 "x": 176,
        ...                 "y": 137,
        ...                 "borathonid": "PLR_c0c78a13d27341c23c7d722301c6b5b7",  # noqa
        ...                 "LS":
        ...                     {
        ...                         "1": {
        ...                                 "RMODE": "SOURCE",
        ...                                 'VNIC':
        ...                                        {'1':
        ...                                              {
        ...                                                  'UUID': 'KVM/10.10.10.10/testvm2/1'
        ...                                              },
        ...                                         '2':
        ...                                              {
        ...                                                  'UUID': 'ESXI/10.10.10.10/testvm2/2'
        ...                                              }
        ...                                        }
        ...                        }
        ...                     }
        ...                 }
        ...             }
        ...         }
        ... }
        >>> T = Topology()
        >>> exp = [
        ...     'CreateUPROF_NAME-UPROF1',
        ...     'CreateTZ_NAME-TZ1_TZTYPE-OVERLAY',
        ...     'CreateTZ_NAME-TZ2_TZTYPE-VLAN',
        ...     'CreateIPPool_NAME-IPP1_RANGES-1:192.1.0.10,192.1.250.250_CIDR-192.1.0.0/16',  # noqa
        ...     'CreateCPROF_NAME-CPROF1',  # noqa
        ...     'CreateDLRP_NAME-PLR1LS1DLRP_LSP-LS1PLR1LSP_LR-PLR1_SCOPE-autopology_TAG-demo_IP-191.0.1.1_PREFIX-24',  # noqa
        ...     'CreateLSP_NAME-LS1PLR1LSP_LS-PLR1LS1_ATYPE-logicalrouter_SCOPE-autopology_TAG-demo',  # noqa
        ...     'CreateLS_NAME-PLR1LS1_RMODE-SOURCE_SCOPE-autopology_TAG-demo_TZ-TZ1_IP-191.0.1.0_PREFIX-24',  # noqa
        ...     'CreatePLR_NAME-PLR1_SCOPE-autopology_TAG-demo_HA-ACTIVE-ACTIVE',  # noqa
        ...     'CreateLRRedistributionConfig_NAME-PLR1',  # noqa
        ...     'CreateVNIC_NAME-PLR1LS1LSP1_UUID-KVM/10.10.10.10/testvm2/1_SCOPE-autopology_TAG-demo_ATYPE-VIF_IP-191.0.1.11_PREFIX-24_LS-PLR1LS1',  # noqa
        ...     'CreateVNIC_NAME-PLR1LS1LSP2_UUID-ESXI/10.10.10.10/testvm2/2_SCOPE-autopology_TAG-demo_ATYPE-VIF_IP-191.0.1.12_PREFIX-24_LS-PLR1LS1',  # noqa
        ...     'CreateTN_NAME-KVM10.10.10.10_SCOPE-autopology_TAG-demo_ATYPE-VIF_IP-191.0.1.11_PREFIX-24_LS-PLR1LS_IPPOOL-IPP1_UPROF-UPROF1_TZ-1_HOSTNODE-10.10.10.10_ETH-1',  # noqa
        ...     'CreateTN_NAME-ESX10.10.10.10_SCOPE-autopology_TAG-demo_ATYPE-VIF_IP-191.0.1.12_PREFIX-24_LS-PLR1LS_IPPOOL-IPP1_UPROF-UPROF1_TZ-1_HOSTNODE-10.10.10.10_VMNIC-1']  # noqa
        >>> T.convert_ui_schema_to_workload_list(
        ...         final_count_down)  == exp
        True
        """
        workloads_list = list(self.HARDCODED_WORKLOADS)
        REQUIRED_ATTRS = (TAG.lower(), SPEC)
        for req_attr in REQUIRED_ATTRS:
            if req_attr not in input_dict:
                print("%r is not provided in:\n%s" %
                      (req_attr, pprint.pformat(input_dict)))
                raise ValueError("%r is not provided" % req_attr)
        spec = input_dict[SPEC]
        tag = input_dict[TAG.lower()]
        spec = self.filter_key(spec)
        ret = None
        # EDGE requires special processing so we will handle it separately.
        if self.FN in spec:
            try:
                ret = self._process_ui_spec({self.FN: spec[self.FN]}, tag)
                related_workloads, remanant_schema = ret
                workloads_list.extend(related_workloads)
                del spec[self.FN]
            except ValueError:
                print "Got processed workload list:\n%s" % pprint.pformat(ret)
                raise
            if remanant_schema:
                raise RuntimeError("Parsing error, didn't expect any "
                                   "remaining schema, got:\n%s" %
                                   pprint.pformat(remanant_schema))
        # Process remaining workloads.
        ret = None
        try:
            ret = self._process_ui_spec(spec, tag)
            related_workloads, remanant_schema = ret
            workloads_list.extend(related_workloads)
        except ValueError:
            print "Got processed workload list:\n%s" % pprint.pformat(ret)
            raise
        if remanant_schema:
            raise RuntimeError("Parsing error, didn't expect any remaining "
                               "schema, got:\n%s" %
                               pprint.pformat(remanant_schema))
        workloads_list = self._ls_related_massage(workloads_list)
        workloads_list = self._ls_vnic_related_massage(workloads_list)
        workloads_list = self._dlrp_related_massage(workloads_list)
        workloads_list = self._generate_host_related_workloads(workloads_list)
        workloads_list = self._plr_related_massage(workloads_list)
        return self._edge_related_massage(workloads_list, tag)

    def _generate_host_related_workloads(self, workload_list):
        """
        Generates workloads based on what host is being used to attach the
        VNIC.
        """
        # XXX How to get borathon ID for the CreateTN.
        create_vnics = [
            workload for workload in workload_list
            if workload.startswith("CreateVNIC")]
        new_list = copy.deepcopy(workload_list)
        for ind, workload in enumerate(workload_list):
            if ((workload.startswith("CreateTN") and
                 not re.search("FPETH", workload) and
                 create_vnics)):
                # Remove other TN workloads if vnics are specified.
                # If vnics are not specified, user might have wanted to
                # add just TN and no vnics on it.
                new_list.pop(ind)
        nics = {"KVM": "ETH-1",
                "ESX": "VMNIC-1",
                "ESXI": "VMNIC-1"}
        tn_workloads = []  # Maintains the TN workloads.
        for workload in create_vnics:
            tag_match = re.search(".*SCOPE\-(\S+)_TAG-(\S+)[^_].*", workload)
            if not tag_match:
                raise ValueError("Did not find the tag param in correct "
                                 "format in the CreateVNIC workload: %r" %
                                 workload)
            scope, tag = tag_match.groups()
            uuid_match = re.search(
                ".*UUID\-(KVM|ESXI)/((?:[0-9]|\.)+)/.*", workload)
            if not uuid_match:
                raise ValueError("Did not find the UUID param in correct "
                                 "format in the CreateVNIC workload: %r" %
                                 workload)
            host_type, host_ip = uuid_match.groups()
            if host_type.lower().startswith('esx'):
                host_type = 'ESX'
            nic = nics[host_type]
            workload_name = (
                "CreateTN_NAME-%s%s_SCOPE-%s_TAG-%s_IPPOOL-IPP1_UPROF-UPROF1"
                "_TZ-1_HOSTNODE-%s_%s" %
                (host_type, host_ip, scope, tag, host_ip, nic))
            if workload_name not in tn_workloads:
                tn_workloads.append(workload_name)
        new_list.extend(tn_workloads)
        return new_list

    def _ls_related_massage(self, workloads_list):
        """
        Helper to modify the workloads list based on LS'es. LS'es are going to
        get param TZ 1 and VLS'es are going to get the param TZ2.
        """
        changed_list = []
        for workload in workloads_list:
            if re.match("(Create%s_\S+$|Create%s$)" %
                        (self.LS, self.LS), workload):
                changed_list.append("%s_TZ-TZ1" % (workload))
            elif re.match("(Create%s_\S+$|Create%s$)" %
                          (self.VLS, self.VLS), workload):
                changed_list.append("%s_TZ-TZ2" % (workload))
            else:
                changed_list.append(workload)
        return changed_list

    def _ls_vnic_related_massage(self, workloads_list):
        changed_list = []
        ls_ip_plr = ""
        ls_ip_tlr = ""
        ls_ip = ""
        ls_ip_vnic = ""
        ls_param = ""
        for workload in workloads_list:
            # Extract workload name
            workload_params = workload.split("_")
            for param in workload_params:
                if re.match("NAME-\S+$", param):
                    workload_name = param[5:]
            # Add IP to LS
            if re.match("(Create%s_\S+$|Create%s$)" %
                        (self.LS, self.LS), workload):
                if "PLR" not in workload_name:
                    workload_name = "PLR0" + workload_name
                if "TLR" not in workload_name:
                    workload_name = "TLR0" + workload_name
                name_components = filter(
                    None, re.split('(\d+)', workload_name))
                for idx, val in enumerate(name_components):
                    if val == "PLR":
                        ls_ip_plr = "19" + name_components[idx+1]
                    if val == "TLR":
                        ls_ip_tlr = name_components[idx+1]
                    if val == "LS":
                        ls_ip = name_components[idx+1]
                    final_ls_ip = (("%s.%s.%s.0_PREFIX-24") %
                                   (ls_ip_plr, ls_ip_tlr, ls_ip))
                changed_list.append("%s_IP-%s" % (workload, final_ls_ip))
            # Add IP to VNIC
            elif re.match("(Create%s_\S+$|Create%s$)" %
                          (self.VNIC, self.VNIC), workload):
                ls_param = workload_name[:-4]
                if "PLR" not in workload_name:
                    workload_name = "PLR0" + workload_name
                if "TLR" not in workload_name:
                    workload_name = "TLR0" + workload_name
                name_components = filter(
                    None, re.split('(\d+)', workload_name))
                for idx, val in enumerate(name_components):
                    if val == "PLR":
                        ls_ip_plr = "19" + name_components[idx+1]
                    if val == "TLR":
                        ls_ip_tlr = name_components[idx+1]
                    if val == "LS":
                        ls_ip = name_components[idx+1]
                    if val == "LSP":
                        ls_ip_vnic = str(10 + int(name_components[idx+1]))
                    final_ls_ip = (("%s.%s.%s.%s_PREFIX-24") %
                                   (ls_ip_plr, ls_ip_tlr, ls_ip, ls_ip_vnic))
                changed_list.append("%s_IP-%s_LS-%s" %
                                    (workload, final_ls_ip, ls_param))
            else:
                changed_list.append(workload)
        return changed_list

    def _dlrp_related_massage(self, workloads_list):
        changed_list = []
        ip_plr = ""
        ip_tlr = ""
        ls_ip = ""
        for workload in workloads_list:
            # Extract workload name
            workload_params = workload.split("_")
            for param in workload_params:
                if re.match("NAME-\S+$", param):
                    workload_name = param[5:]
            if re.match("(Create%s_\S+$|Create%s$)" %
                        (self.DLRP, self.DLRP), workload):
                if "PLR" not in workload_name:
                    workload_name = "PLR0" + workload_name
                if "TLR" not in workload_name:
                    workload_name = "TLR0" + workload_name
                name_components = filter(
                    None, re.split('(\d+)', workload_name))
                for idx, val in enumerate(name_components):
                    if val == "PLR":
                        ip_plr = "19" + name_components[idx+1]
                    if val == "TLR":
                        ip_tlr = name_components[idx+1]
                    if val == "LS":
                        ls_ip = name_components[idx+1]
                    final_ip = (
                        self.DL_SUBNET %
                        ("%s.%s.%s" % (ip_plr, ip_tlr, ls_ip)))
                changed_list.append("%s_IP-%s" % (workload, final_ip))
            else:
                changed_list.append(workload)
        return changed_list

    def _plr_related_massage(self, workloads_list):
        """
        Helper to modify the workloads list based on whether or not there were
        EDGE nodes present as fabric nodes.
        """
        changed_list = []
        PLR_REGEX = "Create%s_NAME-([^_]+)" % self.PLR
        for workload in workloads_list:
            if ((re.match(PLR_REGEX, workload) and
                 not re.search("_HA-", workload))):
                changed_list.append("%s_HA-ACTIVE-ACTIVE" % (workload))
                name = re.match(PLR_REGEX, workload).group(1)
                changed_list.append("CreateLRRedistributionConfig_NAME-%s" %
                                    name)
            else:
                changed_list.append(workload)
        return changed_list

    def _edge_related_massage(self, workloads_list, tag):
        """
        Helper to modify the workloads list based on whether or not there were
        EDGE nodes present as fabric nodes.
        """
        TAG_AND_SCOPE = "%s-%s_%s-%s" % (SCOPE, TAG_SCOPE, TAG, tag)
        if not self.edges:
            return workloads_list
        workloads_list.append(
            "CreateEdgeCluster_NAME-%s_TN-%s_%s" %
            (self.EDGE_CLUSTER_NAME, ",".join(self.edge_ips), TAG_AND_SCOPE))
        changed_list = []
        for workload in workloads_list:
            if re.match("(Create%s_\S+$|Create%s$)" %
                        (self.PLR, self.PLR), workload):
                changed_list.append("%s_EDGECLUSTER-%s" % (workload,
                                    self.EDGE_CLUSTER_NAME))
            else:
                changed_list.append(workload)
        return changed_list

    def _get_hidden_workloads(self, component_list, tag, child_schema=None):
        """
        Helper to return the workloads to needed to specify a relation between
        logical entities.

        >>> T = Topology()
        >>> exp1 = [
        ...     'CreatePlrLLRP_NAME-PLR1TLR1LLRP_LR-PLR1_SCOPE-autopology_TAG-tagged',  # noqa
        ...     'CreateTlrLLRP_NAME-TLR1PLR1LLRP_LR-PLR1TLR1_PLRP-PLR1TLR1LLRP_SCOPE-autopology_TAG-tagged',  # noqa
        ...     'CreateAdvertisementGlobalConfigOnLR_NAME-PLR1TLR1_ADVERTISECONNECTED-True_ADVERTISENAT-True_ADVERTISESTATIC-True']  # noqa
        >>> T._get_hidden_workloads(
        ...     ['PLR', '1', 'TLR', '1'], 'tagged') == exp1
        True
        >>> exp2 = [
        ...     'CreateDLRP_NAME-PLR1TLR2LS5DLRP_LSP-LS5TLR2PLR1LSP_LR-PLR1TLR2_SCOPE-autopology_TAG-tagged2',  # noqa
        ...     'CreateLSP_NAME-LS5TLR2PLR1LSP_LS-PLR1TLR2LS5_ATYPE-logicalrouter_SCOPE-autopology_TAG-tagged2']  # noqa
        >>> T._get_hidden_workloads(
        ...     ['PLR', '1', 'TLR', '2', 'LS', '5'], 'tagged2') == exp2
        True
        >>> exp = [
        ...     'CreateDLRP_NAME-PLR1LS1DLRP_LSP-LS1PLR1LSP_LR-PLR1_SCOPE-autopology_TAG-t2',  # noqa
        ...     'CreateLSP_NAME-LS1PLR1LSP_LS-PLR1LS1_ATYPE-logicalrouter_SCOPE-autopology_TAG-t2']  # noqa
        >>> T._get_hidden_workloads(
        ...     ['PLR', '1', 'LS', '1'], 't2') == exp
        True
        >>> exp3 =[
        ...     'CreateULRP_NAME-PLR1ULRP1_LR-PLR1_LSP-VLS1PLR1LSP_10.2.4.5_IP-192.168.51.1_PREFIX-24',  # noqa
        ...     'CreateLSP_NAME-VLS1PLR1LSP_LS-PLR1VLS1',  # noqa
        ...     'CreateLRBGP_NAME-PLR1VLS1_ENABLED-True_ECMP-false_GR-false_LOCALAS-200',  # noqa
        ...     'CreateLRBGPNbr_NAME-PLR1VLS1_NBRIP-1.1.1.1_HDTIMER-4_KATIMER-1']  # noqa
        >>> T.edges = ['10.2.4.5']  # noqa
        >>> T._get_hidden_workloads(
        ...     ['PLR', '1', 'VLS', '1'], 't', {'NBRIP': '1.1.1.1'}) == exp3
        True
        """
        ret = []
        TAG_AND_SCOPE = "%s-%s_%s-%s" % (SCOPE, TAG_SCOPE, TAG, tag)
        if len(component_list) % 2 != 0:
            raise ValueError("Expected component list to be of even length, "
                             "got: %r" % component_list)
        elif len(component_list) < 4:  # No relation to establish.
            return ret
        comp1_type = component_list[-4]
        comp2_type = component_list[-2]
        comp2_ind = component_list[-1]
        comp1_name = "".join(component_list[:-2]).upper()
        comp2_name = "".join(component_list).upper()
        comp1_connector_name = "".join(component_list).upper()
        # Create name of the second component connector.
        # Reversing the name also helps to keep the display names unique since
        # if a PLR is connected to a TLR then we have two logical router ports
        # that will end up having the same name if we don't reverse the
        # direction of the relation/connector being created.
        reverse_comp_list = component_list[::-1]
        for ind in range(1, len(reverse_comp_list) + 1, 2):
            elem = reverse_comp_list[ind]
            reverse_comp_list[ind] = reverse_comp_list[ind - 1]
            reverse_comp_list[ind - 1] = elem
        comp2_connector_name = "".join(reverse_comp_list).upper()
        if comp1_type == self.PLR and comp2_type == self.TLR:
            plr_name = ('CreatePlrLLRP_NAME-%sLLRP_LR-%s_%s' %
                        (comp1_connector_name, comp1_name, TAG_AND_SCOPE))
            tlr_name = ('CreateTlrLLRP_NAME-%sLLRP_LR-%s_PLRP-%sLLRP_%s' %
                        (comp2_connector_name, comp2_name,
                         comp1_connector_name, TAG_AND_SCOPE))
            set_advertisement_on_tlr = (
                "CreateAdvertisementGlobalConfigOnLR_NAME-%s_"
                "ADVERTISECONNECTED-True_ADVERTISENAT-True_"
                "ADVERTISESTATIC-True" % comp1_connector_name)
            return [plr_name, tlr_name, set_advertisement_on_tlr]
        elif comp1_type in (self.TLR, self.PLR) and comp2_type == self.LS:
            comp2_connector_name = "%sLSP" % (comp2_connector_name)
            lr_name = ('CreateDLRP_NAME-%sDLRP_LSP-%s_LR-%s_%s' %
                       (comp1_connector_name, comp2_connector_name,
                        comp1_name, TAG_AND_SCOPE))
            lsp_name = ('CreateLSP_NAME-%s_LS-%s_ATYPE-logicalrouter_%s' %
                        (comp2_connector_name, comp2_name, TAG_AND_SCOPE))
            return [lr_name, lsp_name]
        elif comp1_type == self.PLR and comp2_type == self.VLS:
            comp2_connector_name = "%sLSP" % (comp2_connector_name)
            self.vlses += 1
            if self.vlses > len(self.edges):
                raise ValueError("Number of edges in the spec (%r) are not "
                                 "sufficient to create VLSes (%r)" %
                                 (self.edges, self.vlses))
            tn_name = self.edges[self.vlses - 1]
            ulrp_subnet = self.UL_SUBNET % (self.UL_SUBNET_OFFSET +
                                            int(comp2_ind))
            ulrp_name = ("CreateULRP_NAME-%sULRP%s_LR-%s_LSP"
                         "-%s_%s_%s" % (comp1_name, comp2_ind, comp1_name,
                                        comp2_connector_name, tn_name,
                                        ulrp_subnet))
            lsp_name = ("CreateLSP_NAME-%s_LS-%s" %
                        (comp2_connector_name, comp2_name))
            # BGP related workloads/config follow:
            neighbor_opts = []
            for opt in ("REMOTEAS", "NBRIP"):
                if opt in child_schema:
                    neighbor_opts.append("%s-%s" % (opt, child_schema[opt]))
            # Shouldn't all these params be specified as part of PLR schema
            # instead of hardcoding here?
            apply_bgp_on_plr = (
                "CreateLRBGP_NAME-%s_ENABLED-True_ECMP-false_GR-false_LOCALAS-200"  # noqa
                % comp1_connector_name)
            if neighbor_opts:
                neighbor_opts.extend(["HDTIMER-4", "KATIMER-1"])
                neigh_config = (
                    "CreateLRBGPNbr_NAME-%s_%s" %
                    (comp1_connector_name, "_".join(neighbor_opts)))
                return [ulrp_name, lsp_name, apply_bgp_on_plr, neigh_config]
            return [ulrp_name, lsp_name, apply_bgp_on_plr]

        else:
            raise ValueError("Unexpected components are being connected: "
                             "%r, %r" % (comp1_type, comp2_type))

    @classmethod
    def _map_key(cls, k):
        if re.match("%s$" % cls.BORATHON_ID, k, re.IGNORECASE):
            return cls.BORA
        return k

    def _process_ui_spec(self, input_dict, tag, parents=None):
        """
        >>> T = Topology()
        >>> input_dict = {
        ...     'LS':
        ...         {'1':
        ...             {'replication_mode': 'MTEP'},
        ...          '2':
        ...             {'replication_mode': 'SOURCE'}
        ...          },
        ... }
        >>> pprint.pprint(T._process_ui_spec(input_dict, 'demo1'))
        (['CreateLS_NAME-LS1_replication_mode-MTEP_SCOPE-autopology_TAG-demo1',
          'CreateLS_NAME-LS2_replication_mode-SOURCE_SCOPE-autopology_TAG-demo1'],
         {})
        >>> input_dict = {
        ...     'TLR':
        ...        {'1':
        ...            {'LS':
        ...                {'1':
        ...                    {'replication_mode': 'MTEP'},
        ...                 '2':
        ...                    {'replication_mode': 'SOURCE'}
        ...                 }
        ...             },
        ...         'route_advertisement': 'enabled'
        ...        }
        ... }
        >>> exp = (
        ...     ['CreateDLRP_NAME-TLR1LS1DLRP_LSP-LS1TLR1LSP_LR-TLR1_SCOPE-autopology_TAG-demo1',  # noqa
        ...      'CreateDLRP_NAME-TLR1LS2DLRP_LSP-LS2TLR1LSP_LR-TLR1_SCOPE-autopology_TAG-demo1',  # noqa
        ...      'CreateLSP_NAME-LS1TLR1LSP_LS-TLR1LS1_ATYPE-logicalrouter_SCOPE-autopology_TAG-demo1',  # noqa
        ...      'CreateLSP_NAME-LS2TLR1LSP_LS-TLR1LS2_ATYPE-logicalrouter_SCOPE-autopology_TAG-demo1',  # noqa
        ...      'CreateLS_NAME-TLR1LS1_replication_mode-MTEP_SCOPE-autopology_TAG-demo1',  # noqa
        ...      'CreateLS_NAME-TLR1LS2_replication_mode-SOURCE_SCOPE-autopology_TAG-demo1',  # noqa
        ...      'CreateTLR_NAME-TLR1_SCOPE-autopology_TAG-demo1_route_advertisement-enabled'],  # noqa
        ...      {})
        >>> T._process_ui_spec(input_dict, 'demo1') == exp
        True
        >>> input_dict = {
        ...     'PLR':
        ...        {'1':
        ...            {'TLR':
        ...                {'1':
        ...                    {'LS':
        ...                        {'1':
        ...                            {'replication_mode': 'MTEP'},
        ...                         '2':
        ...                            {'replication_mode': 'SOURCE'}
        ...                        },
        ...                    },
        ...                  'route_advertisement': 'enabled'
        ...               }
        ...            }
        ...         }
        ... }
        >>> exp = (
        ...     ['CreateAdvertisementGlobalConfigOnLR_NAME-PLR1TLR1_ADVERTISECONNECTED-True_ADVERTISENAT-True_ADVERTISESTATIC-True',  # noqa
        ...      'CreateDLRP_NAME-PLR1TLR1LS1DLRP_LSP-LS1TLR1PLR1LSP_LR-PLR1TLR1_SCOPE-autopology_TAG-demo1',  # noqa
        ...      'CreateDLRP_NAME-PLR1TLR1LS2DLRP_LSP-LS2TLR1PLR1LSP_LR-PLR1TLR1_SCOPE-autopology_TAG-demo1',  # noqa
        ...      'CreateLSP_NAME-LS1TLR1PLR1LSP_LS-PLR1TLR1LS1_ATYPE-logicalrouter_SCOPE-autopology_TAG-demo1',  # noqa
        ...      'CreateLSP_NAME-LS2TLR1PLR1LSP_LS-PLR1TLR1LS2_ATYPE-logicalrouter_SCOPE-autopology_TAG-demo1',  # noqa
        ...      'CreateLS_NAME-PLR1TLR1LS1_replication_mode-MTEP_SCOPE-autopology_TAG-demo1',  # noqa
        ...      'CreateLS_NAME-PLR1TLR1LS2_replication_mode-SOURCE_SCOPE-autopology_TAG-demo1',  # noqa
        ...      'CreatePLR_NAME-PLR1_SCOPE-autopology_TAG-demo1',  # noqa
        ...      'CreatePlrLLRP_NAME-PLR1TLR1LLRP_LR-PLR1_SCOPE-autopology_TAG-demo1',  # noqa
        ...      'CreateTLR_NAME-PLR1TLR1_SCOPE-autopology_TAG-demo1_route_advertisement-enabled',  # noqa
        ...      'CreateTlrLLRP_NAME-TLR1PLR1LLRP_LR-PLR1TLR1_PLRP-PLR1TLR1LLRP_SCOPE-autopology_TAG-demo1'],  # noqa
        ...      {})
        >>> T._process_ui_spec(input_dict, 'demo1') == exp
        True
        >>> expected = (
        ...     ['CreateTN_NAME-TN1_SCOPE-autopology_TAG-demo1_IPPOOL-IPP1_UPROF-UPROF1_VMNIC-1_TZ-1_BORA-bora1_HOSTNODE-10.20.10.10',  # noqa
        ...      'CreateTN_NAME-TN2_SCOPE-autopology_TAG-demo1_IPPOOL-IPP1_UPROF-UPROF1_VMNIC-1_TZ-1_BORA-bora2_HOSTNODE-10.20.10.200',  # noqa
        ...      'CreateTN_NAME-TN3_SCOPE-autopology_TAG-demo1_IPPOOL-IPP1_UPROF-UPROF1_ETH-1_TZ-1_BORA-bora3_HOSTNODE-10.20.10.100',  # noqa
        ...      'CreateTN_NAME-TN4_SCOPE-autopology_TAG-demo1_IPPOOL-IPP1_UPROF-UPROF1_FPETH-1_TZ-1-2_BORA-bora4_HOSTNODE-10.20.10.150'],  # noqa
        ...      {})
        >>> input_dict = {
        ...     'FN': {
        ...         "1": {
        ...             'borathonid': "bora1",
        ...             'type': 'ESX',
        ...             'hostnode': '10.20.10.10',
        ...         },
        ...         "2": {
        ...             'borathonid': "bora2",
        ...             'type': 'ESX',
        ...             'hostnode': '10.20.10.200',
        ...         },
        ...         "3": {
        ...             'borathonid': "bora3",
        ...             'type': 'KVM',
        ...             'hostnode': '10.20.10.100',
        ...         },
        ...         "4": {
        ...             'borathonid': "bora4",
        ...             'type': 'EDGE',
        ...             'hostnode': '10.20.10.150',
        ...         },
        ...     }
        ... }
        >>> T._process_ui_spec(input_dict, 'demo1') == expected
        True
        >>> full_topo = {
        ...     'PLR':
        ...        {'1':
        ...            {'TLR':
        ...                {'1':
        ...                    {'LS':
        ...                        {'1':
        ...                            {'replication_mode': 'MTEP'},
        ...                         '2':
        ...                            {'replication_mode': 'SOURCE'}
        ...                        },
        ...                    },
        ...                  'route_advertisement': 'enabled'
        ...               }
        ...            }
        ...         },
        ...     'FN':
        ...         {
        ...             "1": {
        ...                 'borathonid': "bora1",
        ...                 'type': 'ESX',
        ...                 'hostnode': '10.20.10.10',
        ...             },
        ...             "2": {
        ...                 'borathonid': "bora2",
        ...                 'type': 'ESX',
        ...                 'hostnode': '10.20.10.200',
        ...             },
        ...             "3": {
        ...                 'borathonid': "bora3",
        ...                 'type': 'KVM',
        ...                 'hostnode': '10.20.10.100',
        ...             },
        ...             "4": {
        ...                 'borathonid': "bora4",
        ...                 'type': 'EDGE',
        ...                 'hostnode': '10.20.10.150',
        ...             },
        ...     }
        ... }
        >>> expected = (
        ...     ['CreateDLRP_NAME-PLR1TLR1LS1DLRP_LSP-LS1TLR1PLR1LSP_LR-PLR1TLR1_SCOPE-autopology_TAG-demo1',  # noqa
        ...     'CreateDLRP_NAME-PLR1TLR1LS2DLRP_LSP-LS2TLR1PLR1LSP_LR-PLR1TLR1_SCOPE-autopology_TAG-demo1',  # noqa
        ...     'CreateLSP_NAME-LS1TLR1PLR1LSP_LS-PLR1TLR1LS1_ATYPE-logicalrouter_SCOPE-autopology_TAG-demo1',  # noqa
        ...     'CreateLSP_NAME-LS2TLR1PLR1LSP_LS-PLR1TLR1LS2_ATYPE-logicalrouter_SCOPE-autopology_TAG-demo1',  # noqa
        ...     'CreateLS_NAME-PLR1TLR1LS1_replication_mode-MTEP_SCOPE-autopology_TAG-demo1',  # noqa
        ...     'CreateLS_NAME-PLR1TLR1LS2_replication_mode-SOURCE_SCOPE-autopology_TAG-demo1',  # noqa
        ...     'CreatePLR_NAME-PLR1_SCOPE-autopology_TAG-demo1_HA-ACTIVE-ACTIVE',  # noqa
        ...     'CreatePlrLLRP_NAME-PLR1TLR1LLRP_LR-PLR1_SCOPE-autopology_TAG-demo1',  # noqa
        ...     'CreateTLR_NAME-PLR1TLR1_SCOPE-autopology_TAG-demo1_route_advertisement-enabled',  # noqa
        ...     'CreateTN_NAME-TN1_SCOPE-autopology_TAG-demo1_IPPOOL-IPP1_UPROF-UPROF1_VMNIC-1_TZ-1_BORA-bora1_HOSTNODE-10.20.10.10',  # noqa
        ...     'CreateTN_NAME-TN2_SCOPE-autopology_TAG-demo1_IPPOOL-IPP1_UPROF-UPROF1_VMNIC-1_TZ-1_BORA-bora2_HOSTNODE-10.20.10.200',  # noqa
        ...     'CreateTN_NAME-TN3_SCOPE-autopology_TAG-demo1_IPPOOL-IPP1_UPROF-UPROF1_ETH-1_TZ-1_BORA-bora3_HOSTNODE-10.20.10.100',  # noqa
        ...     'CreateTN_NAME-TN4_SCOPE-autopology_TAG-demo1_IPPOOL-IPP1_UPROF-UPROF1_FPETH-1_TZ-1-2_BORA-bora4_HOSTNODE-10.20.10.150',  # noqa
        ...     'CreateTlrLLRP_NAME-TLR1PLR1LLRP_LR-PLR1TLR1_PLRP-PLR1TLR1LLRP_SCOPE-autopology_TAG-demo1'],  # noqa
        ...     {})
        >>> input_dict = {
        ...     'TLR':
        ...        {'1':
        ...            {'LS':
        ...                {'1':
        ...                    {'replication_mode': 'MTEP'},
        ...                 '2':
        ...                    {'replication_mode': 'SOURCE',
        ...                     'VNIC':
        ...                         {'1':
        ...                             {
        ...                                 'UUID': 'KVM/10.10.10.10/testvm2/1'
        ...                             },
        ...                         '2':
        ...                             {
        ...                                 'UUID': 'ESXI/10.10.10.10/testvm2/2'
        ...                             }
        ...                         }
        ...                     }
        ...                 }
        ...             },
        ...         'route_advertisement': 'enabled'
        ...        }
        ... }
        >>> exp = (
        ...     ['CreateDLRP_NAME-TLR1LS1DLRP_LSP-LS1TLR1LSP_LR-TLR1_SCOPE-autopology_TAG-demo1',  # noqa
        ...      'CreateDLRP_NAME-TLR1LS2DLRP_LSP-LS2TLR1LSP_LR-TLR1_SCOPE-autopology_TAG-demo1',  # noqa
        ...      'CreateLSP_NAME-LS1TLR1LSP_LS-TLR1LS1_ATYPE-logicalrouter_SCOPE-autopology_TAG-demo1',  # noqa
        ...      'CreateLSP_NAME-LS2TLR1LSP_LS-TLR1LS2_ATYPE-logicalrouter_SCOPE-autopology_TAG-demo1',  # noqa
        ...      'CreateLS_NAME-TLR1LS1_replication_mode-MTEP_SCOPE-autopology_TAG-demo1',  # noqa
        ...      'CreateLS_NAME-TLR1LS2_replication_mode-SOURCE_SCOPE-autopology_TAG-demo1',  # noqa
        ...      'CreateTLR_NAME-TLR1_SCOPE-autopology_TAG-demo1_route_advertisement-enabled',  # noqa
        ...      'CreateVNIC_NAME-TLR1LS2LSP1_UUID-KVM/10.10.10.10/testvm2/1_SCOPE-autopology_TAG-demo1_ATYPE-VIF',
        ...      'CreateVNIC_NAME-TLR1LS2LSP2_UUID-ESXI/10.10.10.10/testvm2/2_SCOPE-autopology_TAG-demo1_ATYPE-VIF'],
        ...      {})
        >>> T._process_ui_spec(input_dict, 'demo1') == exp
        True
        >>> full_topo = {
        ...     'PLR':
        ...        {'1':
        ...            {'TLR':
        ...                {'1':
        ...                    {'LS':
        ...                        {'1':
        ...                            {'replication_mode': 'MTEP'},
        ...                         '2':
        ...                            {'replication_mode': 'SOURCE',
        ...                             'VNIC':
        ...                                 {'1':
        ...                                    {
        ...                                      'UUID': 'KVM/10.10.10.10/testvm2/1'
        ...                                    },
        ...                                  '2':
        ...                                    {
        ...                                      'UUID': 'ESXI/10.10.10.10/testvm2/2'
        ...                                    }
        ...                                 }
        ...                            }
        ...                        }
        ...                    },
        ...                  'route_advertisement': 'enabled'
        ...               }
        ...            }
        ...     },
        ...     'FN':
        ...         {
        ...             "1": {
        ...                 'borathonid': "bora1",
        ...                 'type': 'ESX',
        ...                 'hostnode': '10.20.10.10',
        ...             },
        ...             "2": {
        ...                 'borathonid': "bora2",
        ...                 'type': 'ESX',
        ...                 'hostnode': '10.20.10.200',
        ...             },
        ...             "3": {
        ...                 'borathonid': "bora3",
        ...                 'type': 'KVM',
        ...                 'hostnode': '10.20.10.100',
        ...             },
        ...             "4": {
        ...                 'borathonid': "bora4",
        ...                 'type': 'EDGE',
        ...                 'hostnode': '10.20.10.150',
        ...             },
        ...     }
        ... }
        >>> expected = (
        ...     ['CreateAdvertisementGlobalConfigOnLR_NAME-PLR1TLR1_ADVERTISECONNECTED-True_ADVERTISENAT-True_ADVERTISESTATIC-True',  # noqa
        ...      'CreateDLRP_NAME-PLR1TLR1LS1DLRP_LSP-LS1TLR1PLR1LSP_LR-PLR1TLR1_SCOPE-autopology_TAG-demo1',  # noqa
        ...      'CreateDLRP_NAME-PLR1TLR1LS2DLRP_LSP-LS2TLR1PLR1LSP_LR-PLR1TLR1_SCOPE-autopology_TAG-demo1',  # noqa
        ...      'CreateLSP_NAME-LS1TLR1PLR1LSP_LS-PLR1TLR1LS1_ATYPE-logicalrouter_SCOPE-autopology_TAG-demo1',  # noqa
        ...      'CreateLSP_NAME-LS2TLR1PLR1LSP_LS-PLR1TLR1LS2_ATYPE-logicalrouter_SCOPE-autopology_TAG-demo1',  # noqa
        ...      'CreateLS_NAME-PLR1TLR1LS1_replication_mode-MTEP_SCOPE-autopology_TAG-demo1',  # noqa
        ...      'CreateLS_NAME-PLR1TLR1LS2_replication_mode-SOURCE_SCOPE-autopology_TAG-demo1',  # noqa
        ...      'CreatePLR_NAME-PLR1_SCOPE-autopology_TAG-demo1',  # noqa
        ...      'CreatePlrLLRP_NAME-PLR1TLR1LLRP_LR-PLR1_SCOPE-autopology_TAG-demo1',  # noqa
        ...      'CreateTLR_NAME-PLR1TLR1_SCOPE-autopology_TAG-demo1_route_advertisement-enabled',  # noqa
        ...      'CreateTN_NAME-TN1_SCOPE-autopology_TAG-demo1_IPPOOL-IPP1_UPROF-UPROF1_VMNIC-1_TZ-1_BORA-bora1_HOSTNODE-10.20.10.10',  # noqa
        ...      'CreateTN_NAME-TN2_SCOPE-autopology_TAG-demo1_IPPOOL-IPP1_UPROF-UPROF1_VMNIC-1_TZ-1_BORA-bora2_HOSTNODE-10.20.10.200',  # noqa
        ...      'CreateTN_NAME-TN3_SCOPE-autopology_TAG-demo1_IPPOOL-IPP1_UPROF-UPROF1_ETH-1_TZ-1_BORA-bora3_HOSTNODE-10.20.10.100',  # noqa
        ...      'CreateTN_NAME-TN4_SCOPE-autopology_TAG-demo1_IPPOOL-IPP1_UPROF-UPROF1_FPETH-1_TZ-1-2_BORA-bora4_HOSTNODE-10.20.10.150',  # noqa
        ...      'CreateTlrLLRP_NAME-TLR1PLR1LLRP_LR-PLR1TLR1_PLRP-PLR1TLR1LLRP_SCOPE-autopology_TAG-demo1',  # noqa
        ...      'CreateVNIC_NAME-PLR1TLR1LS2LSP1_UUID-KVM/10.10.10.10/testvm2/1_SCOPE-autopology_TAG-demo1_ATYPE-VIF',  # noqa
        ...      'CreateVNIC_NAME-PLR1TLR1LS2LSP2_UUID-ESXI/10.10.10.10/testvm2/2_SCOPE-autopology_TAG-demo1_ATYPE-VIF'],  # noqa
        ...     {})
        >>> T._process_ui_spec(full_topo, 'demo1') == expected
        True
        """
        TAG_AND_SCOPE = "%s-%s_%s-%s" % (SCOPE, TAG_SCOPE, TAG, tag)
        if parents is None:
            parents = []  # Start off with empty parents and workload name.
        children_workloads = []
        parent_schema = {}
        this_level_workloads = []
        this_level_schema = {}
        for key, val in input_dict.iteritems():
            if key not in self.relational_components:
                if key in self.standalone_components:
                    if parents:
                        raise ValueError("Standalone component %r is not "
                                         "expected to have any parents "
                                         "specified, got parents:" %
                                         (key, parents))
                    for nested_key, nested_val in val.iteritems():
                        if re.match("^\d+$", nested_key):
                            standalone_comp = "%s%s" % (key, nested_key)
                            children_workloads.append(
                                self._generate_standalone_workload_from_schema(
                                    standalone_comp, nested_val, tag))
                        else:
                            raise ValueError("No related components expected "
                                             "for standalone component %r" %
                                             key)
                    return sorted(children_workloads), parent_schema
                elif not parents:
                    raise ValueError("Bad input: Expected the parents to be "
                                     "defined before encountering any schema "
                                     "attrs, parents is: %r, schema:\n(%s, %s)"
                                     % (parents, key, pprint.pformat(val)))
                # This key should be part of schema of the component.
                key = self._map_key(key)
                parent_schema.update({key: val})
            elif key in self.relational_components:
                for nested_key, nested_val in val.iteritems():
                    if re.match("^\d+$", nested_key):
                        # Component Index is found.
                        parents.extend([key, nested_key])
                        # Resolve children workloads if any.
                        workloads, my_schema = self._process_ui_spec(
                            nested_val, tag, parents)
                        children_workloads.extend(workloads)
                        # Create workload name for this particular index.
                        workload_name = (
                            "Create%s_NAME-%s" % (
                                parents[-2].upper(), "".join(parents).upper()))
                        for k, v in my_schema.iteritems():
                            k = self._map_key(k)
                            workload_name = "%s_%s-%s" % (workload_name, k, v)
                        workload_name = ("%s_%s" % (workload_name,
                                                    TAG_AND_SCOPE))
                        if "CreateVNIC_" in workload_name:
                            workload_name = workload_name + "_ATYPE-VIF"
                            parts = workload_name.split("_", 1)
                            parts[-1] = parts[-1].replace("VNIC", "LSP")
                            workload_name = "_".join(parts)
                        this_level_workloads.append(workload_name)
                        # Figure out workloads that will be needed to establish
                        # relation with parent entity.
                        if "CreateVNIC_" not in workload_name:
                            # my_schema is passed in for cases where the
                            # related components have values in their schema
                            # that are needed for the creation of creation of
                            # hidden entities (e.g. with PLR and VLS
                            # connection, the ULRP would need to carry
                            # information about AS and neighbor IP and this is
                            # passed in via VLS schema)
                            related_workloads = self._get_hidden_workloads(
                                parents, tag, child_schema=my_schema)
                            children_workloads.extend(related_workloads)
                        parents.pop()  # Pop index.
                        parents.pop()  # Pop component name.
                    else:
                        nested_key = self._map_key(nested_key)
                        this_level_schema.update({nested_key: nested_val})
                for this_level_workload in this_level_workloads:
                    for k, v in this_level_schema.iteritems():
                        this_level_workload = (
                            "%s_%s-%s" % (this_level_workload, k, v))
                    children_workloads.append(this_level_workload)
                this_level_workloads = []  # Reset this level workloads.
            else:
                raise ValueError("%r is not a key nor a component" % key)
        return sorted(children_workloads), parent_schema  # noqa

    @classmethod
    def _get_comp_ind(cls, component_index):
        """
        Helper to return the component name and the index.

        >>> T = Topology()
        >>> T._get_comp_ind('TN1')
        ('TN', '1')
        >>> T._get_comp_ind('TN2FN')
        Traceback (most recent call last):
            ...
        ValueError: Malformed component_index provided: TN2FN
        """
        m = re.match("(\S+)(\d+)$", component_index)
        if not m:
            raise ValueError("Malformed component_index provided: %s" %
                             component_index)
        return m.groups()

    # Warning: This is such a hacky method, don't even bother to review.
    def _generate_standalone_workload_from_schema(self, component, schema,
                                                  tag):
        """
        Helper to discover fabric nodes/transport nodes.

        >>> T = Topology()
        >>> host_node_schema = {
        ...     'borathonID': "bora4",
        ...     'type': 'EDGE',
        ...     'hostnode': '10.20.10.150'
        ... }
        >>> expected = (
        ...     'CreateTN_NAME-TN1_SCOPE-autopology_TAG-tag1_IPPOOL-IPP1_UPROF'
        ...     '-UPROF1_FPETH-1_TZ-1-2_BORA-bora4_HOSTNODE-10.20.10.150')
        >>> T._generate_standalone_workload_from_schema(
        ...     'FN1', host_node_schema, 'tag1') == expected
        True
        >>> host_node_schema = {
        ...     'borathonID': "bora4",
        ...     'type': 'ESX',
        ...     'hostnode': '10.20.10.1'
        ... }
        >>> expected = (
        ...    'CreateTN_NAME-TN4_SCOPE-autopology_TAG-tag2_IPPOOL-IPP1_UPROF'
        ...    '-UPROF1_VMNIC-1_TZ-1_BORA-bora4_HOSTNODE-10.20.10.1')
        >>> T._generate_standalone_workload_from_schema(
        ...     'FN4', host_node_schema, 'tag2') == expected
        True
        """
        TAG_AND_SCOPE = "%s-%s_%s-%s" % (SCOPE, TAG_SCOPE, TAG, tag)
        if component.startswith(self.FN):
            # XXX: TZ is hardcoded to 1.
            component = component.upper()
            # Discover Host/Fabric node schema.
            platform_param = {
                self.KVM: ("ETH-1", "TZ-1"),
                self.ESX: ("VMNIC-1", "TZ-1"),
                self.EDGE: ("FPETH-1", "TZ-1-2")
            }
            platform = schema[self.TYPE]
            del schema[self.TYPE]
            if platform not in platform_param:
                raise ValueError("Unsupported platform provided: %r" %
                                 platform)
            # Create Transport node from host node.
            tn_name = component.replace(self.FN.upper(), self.TN.upper())
            tn_workload = (
                "CreateTN_NAME-%s_%s_IPPOOL-IPP1_UPROF-UPROF1_%s_%s" %
                (tn_name.upper(), TAG_AND_SCOPE, platform_param[platform][0],
                 platform_param[platform][1]))
            for k, v in schema.iteritems():
                k = self._map_key(k)
                tn_workload = "%s_%s-%s" % (tn_workload, k.upper(), v)
            # Maintain the list of EDGE nodes to be added to the EDGE cluster.
            if platform.upper() == self.EDGE:
                # XXX: Uplink, IPPool and TZ are hardcoded.
                self.edges.append(tn_name)
                self.edge_ips.append(schema['hostnode'])
            return tn_workload
        else:
            raise ValueError("%r is not a supported standalone component" %
                             component)


if __name__ == '__main__':
    import doctest
    doctest.testmod(optionflags=doctest.ELLIPSIS)
