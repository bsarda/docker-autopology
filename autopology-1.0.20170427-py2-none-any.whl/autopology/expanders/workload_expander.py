#!/usr/bin/env python

from __future__ import print_function
import os
import re
import sys
import yaml
import jinja2

import param_types


_ = param_types  # Loads all yamltags into namespace
SCRIPT_DIR = os.path.dirname(os.path.realpath(__file__))
WORKLOAD_SPEC_FILE = 'workload_spec.yaml'
WORKLOAD_REGEX_FILE = 'workload_regexes.yaml'
WORKLOADS_TMPL_FILE = 'workloads.tmpl'


TEMPLATE_KEY = 'template'
WORKLOADS_KEY = 'WORKLOADS'
NAMES_KEY = 'NAMES'
VALUE_SEP = '-'
KEY_SEP = '_'

TAB = "    "
NEWLINE_TAB = "\n    "

GENERIC_PARAMS = {
    'RETRIES': 'noofretries',
    'SLEEPBEFORE': 'sleepbetweenworkloads',
    'UNDISCOVER': 'skipmethod',
    'SKIPPOSTPROCESS': 'skippostprocess',
    'EXPECTEDRESULT': 'expectedresult',
}

TAG_PARAMS = {
    'TAG': 'tag',
    'SCOPE': 'scope',
}


def workload_name_to_params(workload_name):
    """
    Split the workload name into params based on separators '_', '-'
    >>> workload_name_to_params('SetDeviceStatus-UP_ESX-1_VTEP-1')
    ('SetDeviceStatus', {'VTEP': '1', 'SetDeviceStatus': 'UP', 'ESX': '1'})
    >>> workload_name_to_params('SetDeviceStatus-UP_ESX-1_VTEP-1_VTEP-2')
    Traceback (most recent call last):
    ...
    ValueError: Duplicate param VTEP not allowed
    """
    params = workload_name.split('_')
    name = None
    ret = {}
    for p in params:
        if '-' in p:
            k, v = p.split('-', 1)
        else:
            k, v = p, None
        if name is None:
            name = k
        if k in ret:
            raise ValueError('Duplicate param %s not allowed, workload: %s' %
                             (k, workload_name))
        ret[k] = v
    return name, ret


def map_implicit_names(params, workload_spec):
    """
    Replaces implict_names from workload specs in params
    >>> map_implicit_names({'VTEP': '1', 'SetDeviceStatus': 'UP', 'ESX': '1'},
    ...     {'SetDeviceStatus': {'implicit_name': 'DEVICESTATUS'}})
    {'DEVICESTATUS': 'UP', 'VTEP': '1', 'ESX': '1'}
    """
    found = None
    found_spec = None
    for k in params:
        if k in workload_spec:
            if found is None:
                found = k
                found_spec = workload_spec[found]
            else:
                raise ValueError(
                    "Conflict between %s, %s keys in workload spec" %
                    (found, k))
    if found_spec:
        if 'implicit_name' in found_spec:
            x, y = found_spec['implicit_name'], found
            params[x] = params[y]
        del params[found]
    else:
        raise ValueError(
            "Params=%s din't match any workload spec in %s" %
            (params, workload_spec))
    return params


def as_list(obj):
    """
    Helper for making the object iterable as a list.

    @type obj: Any
    @param obj: Object that needs to be converted to a list.
    @rtype: list
    @return: Passed in object as a list (if it is not already a list).
    """
    if not hasattr(obj, '__iter__'):
        obj = [obj]
    return obj


jinja_env = None
jinja_specs = {}
regex_specs = {}
specs_loaded = {}


def load_workload_specs(template_dir):
    global jinja_env, jinja_specs, regex_specs, specs_loaded
    if template_dir in specs_loaded:
        return
    rgx_path = os.path.join(template_dir, WORKLOAD_REGEX_FILE)
    regex_specs.update(yaml.load(open(rgx_path)))
    jinja_env = jinja2.Environment(
        loader=jinja2.FileSystemLoader(template_dir),
        extensions=["jinja2.ext.do"])
    workloads_tmpl = os.path.join(template_dir, WORKLOADS_TMPL_FILE)
    jinja_specs.update(yaml.load(open(workloads_tmpl)))
    specs_loaded.update({template_dir: True})


def try_jinja_expand(workload_name, template_dir):
    """
    >>> try_jinja_expand('CreateUPROF-1_FOO-2', SCRIPT_DIR)
    Traceback (most recent call last):
    ...
    ValueError: Param FOO passed in but unused in CreateUPROF template
    >>> try_jinja_expand('CreateUPROF-1_FOO-2_FOO-3', SCRIPT_DIR)
    Traceback (most recent call last):
    ...
    ValueError: Duplicate param FOO not allowed
    """
    name, user_params = workload_name_to_params(workload_name)
    workload_spec = jinja_specs.get(name)
    if workload_spec is None:
        return
    user_params = map_implicit_names(user_params, {name: workload_spec})
    params = param_types.get_supported_params(template_dir)
    for p, val in params.items():
        if p in user_params:
            params[p].value = user_params[p]
            user_params[p] = params[p]

    workload_template = workload_spec[TEMPLATE_KEY]
    generic_params = []
    tag_params = []
    for x in user_params.keys():
        if x not in workload_template:
            if x in GENERIC_PARAMS:
                generic_params.append(x)
                continue
            elif x in TAG_PARAMS:
                tag_params.append(x)
                continue
            # XXX (dhaval): removing fail fast for borathon
            # raise ValueError('Param %s passed in but unused in %s template' %
            #                             (x, name))

    template = jinja_env.from_string(workload_template)
    try:
        workload_str = template.render(**params)
    except:
        print_error("Cannot render the template for {}".format(workload_name))
        print_error(workload_template)
        raise

    try:
        workload = yaml.load(workload_str)
    except:
        print_error("Cannot load the yaml for {}".format(workload_name))
        print_error(workload_str)
        raise

    tags_dict = {}
    # XXX(Autopology): Assuming only 1 set of tags for now.
    for x in tag_params:
        tags_dict[TAG_PARAMS[x]] = user_params[x]
    if tags_dict:
        for k in workload:
            workload[k]['tags'] = []
            workload[k]['tags'].append(tags_dict)

    for x in generic_params:
        workload.update({GENERIC_PARAMS[x]: user_params[x].SPECIFIED})
        if x == 'RETRIES':
            workload.update({'sleepbetweenretry': 1})
    return yaml.dump({workload.keys()[0]: workload[workload.keys()[0]]},
                     default_flow_style=False,
                     default_style=False, indent=4)


def print_error(*args, **kwargs):
    print("ERROR: ", *args, file=sys.stderr, **kwargs)


def parse_config(template_dir):
    cfg_path = os.path.join(template_dir, WORKLOAD_SPEC_FILE)
    stream = open(cfg_path, 'r')
    config = yaml.load(stream)
    try:
        keys = config[NAMES_KEY]
        # TODO check to make sure key values match type
        workloads = config[WORKLOADS_KEY]
        return keys, workloads
    except TypeError:
        print_error('Expected root of {} to be a mapping node. Python parsed '
                    'it as {}'.format(WORKLOAD_SPEC_FILE, type(config)))
        sys.exit(1)
    except KeyError as e:
        print_error('Expected root of {} to contain key: {}. It was missing.'
                    .format(WORKLOAD_SPEC_FILE, e))
        sys.exit(1)


def expand_references(raw_string, keys, key_overrides):
    final_string = ''
    prev_index = 0
    matches = re.finditer('\?(\w+)\((\w+)\)', raw_string)
    for match in matches:
        attribute, key = match.groups()
        # TODO first look in overrides
        key_dict = keys.get(key)
        if not key_dict:
            print_error("Key {} doesn't exist in {}!"
                        .format(key, NAMES_KEY))
            sys.exit(1)
        # TODO harden this if key_dict isn't actually a dictionary
        # TODO this is icky?
        if attribute == 'value' and key in key_overrides:
            replacement = key_overrides[key]
        else:
            replacement = key_dict.get(attribute)
            if replacement is None:
                print_error("Key {} doesn't exist in {}!"
                            .format(attribute, key))
                sys.exit(1)
        replacement = str(replacement)
        # TODO Recursively expand the expansion
        replacement = expand_references(replacement, keys, key_overrides)

        # Indices of the current RE
        begin, end = match.span()
        final_string += raw_string[prev_index:begin]
        final_string += replacement
        prev_index = end
    # Grab what's after the last match. If no matches, this is the whole string
    final_string += raw_string[prev_index:]
    return final_string


def parse_workload_string(workload_string, implicit_name=None):
    """
    >>> sorted(parse_workload_string("CreateLS-2_NSXM-2", "LS").items())
    [('LS', '2'), ('NSXM', '2')]
    >>> parse_workload_string("CreateLS", "LS")
    {}
    >>> parse_workload_string("MyWorkload")
    {}
    >>> parse_workload_string("MyWorkload_RMODE-SOURCE")
    {'RMODE': 'SOURCE'}
    """
    key_overrides = {}
    split_string = re.split('([{}{}])'.format(KEY_SEP, VALUE_SEP),
                            workload_string, maxsplit=1)
    if len(split_string) == 1:
        # There was neither _ nor . after the workload name.
        return key_overrides
    elif len(split_string) == 3:
        items = split_string[2].split(KEY_SEP)
        if split_string[1] == VALUE_SEP:
            # We've been given an override for the implicit name
            if not items[0]:
                print_error('VALUE_SEP came after workload name and '
                            'no value was given for implicit name.')
                sys.exit(1)
            if not implicit_name:
                print_error('Value given immediately after workload, but this '
                            'workload has no "implicit_name" attribute')
                sys.exit(1)
            implicit_value = items[0]
            """
            if VALUE_SEP in implicit_value:
                # Technically we don't need to check for this, but I think it
                # would be really confusing to allow this
                print_error('Value given for implicit name must not contain '
                            'a <VALUE_SEP>')
                sys.exit(1)
            """
            key_overrides[implicit_name] = implicit_value
            items = items[1:]

        pn, pv = None, None
        for item in items:
            if pn is not None and item.startswith('index'):
                pv = "{}_{}".format(pv, item)
                key_overrides[pn] = pv
                continue
            try:
                name, value = item.split(VALUE_SEP, 1)
            except ValueError:
                print_error('Everything following workload name must be of '
                            'the form: <name>{}<value>. Instead we got: "{}".'
                            .format(VALUE_SEP, item))
                sys.exit(1)
            key_overrides[name] = value
            pn, pv = name, value
        return key_overrides
    else:
        raise AssertionError('Weird list returned from re.split')


def try_regex_expand(name, template_dir):
    for k, v in regex_specs.iteritems():
        if re.match(r"%s" % k, name):
            return re.sub(r"%s" % k, r"%s" % v, name)


def load_workload_str(name_str):
    obj = yaml.load(name_str)
    pretty_str = yaml.dump(obj, default_flow_style=False,
                           default_style=False, indent=4)
    print(pretty_str)
    return obj


def expand_template(workload_string, template_dir=None, keys=None,
                    workloads=None):
    if template_dir is None:
        template_dir = SCRIPT_DIR

    load_workload_specs(template_dir)

    out = try_regex_expand(workload_string, template_dir)
    if out is not None:
        return load_workload_str(out)

    out = try_jinja_expand(workload_string, template_dir)
    if out is not None:
        return load_workload_str(out)

    keys, workloads = parse_config(template_dir)  # DEPRECATED
    split_string = re.split('([{}{}])'.format(KEY_SEP, VALUE_SEP),
                            workload_string, maxsplit=1)
    template_name = split_string[0]

    try:
        workload = workloads[template_name]
    except:
        print_error("Couldn't get the workload with name: {}. Config file or "
                    "argument is malformed.".format(template_name))
        sys.exit(1)

    implicit_name = workload.get('implicit_name')   # defaults to None

    key_overrides = parse_workload_string(workload_string, implicit_name)

    try:
        template_string = workload[TEMPLATE_KEY]
        template_str = expand_references(template_string, keys, key_overrides)
        workload_str = yaml.dump({workload_string: yaml.load(template_str)},
                                 default_flow_style=False, default_style=False,
                                 indent=4)
        return load_workload_str(workload_str)
    except KeyError:
        print_error("Cannot find {} in workload {}"
                    .format(TEMPLATE_KEY, template_name))
        sys.exit(1)


if __name__ == '__main__':
    import argparse
    import doctest

    parser = argparse.ArgumentParser()
    parser.add_argument('--doctest', action='store_true', default=False)
    parser.add_argument('-w', '--workloads', action='append', nargs='+',
                        help='List of workloads names to expand')
    parser.add_argument('--template-dir',
                        help='Template directory containing various templates')

    args = parser.parse_args(sys.argv[1:])
    if args.doctest:
        doctest.testmod(optionflags=doctest.ELLIPSIS)
        sys.exit(0)
    for x in sum(args.workloads, []):
        expand_template(x, template_dir=args.template_dir)
