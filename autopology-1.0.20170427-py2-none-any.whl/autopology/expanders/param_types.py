import itertools
import os
import re
import yaml

SCRIPT_DIR = os.path.dirname(os.path.realpath(__file__))
supported_params = None
PARAMS_MAP = {'REASON': 'reason',
              'STATUSCODE': 'status_code'}


def get_supported_params(template_dir=None):
    if template_dir is None:
        template_dir = SCRIPT_DIR
    params_yaml = os.path.join(template_dir, "params.yaml")
    with open(params_yaml) as param_file:
        global supported_params
        supported_params = yaml.load(param_file)
    return supported_params


def str_to_list_dicts(s, to_tuples=False):
    """
    >>> str_to_list_dicts("a:vm1,b:vm2--c:vm3,d:vm4vnic1", to_tuples=True)
    [{'a': 'vm.[1]', 'b': 'vm.[2]'}, {'c': 'vm.[3]', 'd': 'vm.[4].vnic.[1]'}]
    """
    lst = [n.split(',') for n in s.split('--')]
    xlst = []
    for x in lst:
        dct = {}
        xlst.append(dct)
        for y in x:
            k, v = y.split(':')
            if to_tuples:
                # Convert strings to tuples
                v = re.sub('(\d)', '.[\\1].', v.strip())
                v = v.strip('.').lower()
            dct.update({k: v})
    return xlst


def expand_dict(s):
    """
    Helper to expand dicts like {'vm': '1', 'vif': '1-3'} into list
    >>> expand_dict({'vm': '1', 'vif': '1-3'})
    [{'vif': '1', 'vm': '1'}, {'vif': '2', 'vm': '1'}, {'vif': '3', 'vm': '1'}]
    """
    k = s.keys()
    v = [expand_list(x) for x in s.values()]
    arr = []
    for p in itertools.product(*v):
        arr.append(dict(zip(k, p)))
    return arr


def expand_list(s):
    """
    Helper to expand strings like 1-8 to full list
    >>> expand_list('1-4')
    ['1', '2', '3', '4']
    >>> expand_list('1-3,5,7-9')
    ['1', '2', '3', '5', '7', '8', '9']
    >>> expand_list('1')
    ['1']
    >>> expand_list('10.0.0.1/24,10.0.0.2/24')
    ['10.0.0.1/24', '10.0.0.2/24']
    """
    if s is None:
        return []
    s = str(s)
    arr = []
    for t in s.split(','):
        if '-' in t:
            (s, e) = t.split('-')
            arr.extend([str(x) for x in range(int(s), int(e)+1)])
        else:
            arr.append(str(t))
    return arr


class Param(yaml.YAMLObject):
    """
    Parameter class used to expand the user provided parameters and values.

    >>> p = Param()
    >>> p.value = "1:10.0.0.1/24,10.0.0.2/24--2:10.0.0.1--3:1-3"
    >>> import pprint
    >>> expected_result = pprint.pformat(
    ...     {'1': ['10.0.0.1/24', '10.0.0.2/24'],
    ...      '2': ['10.0.0.1'], '3': ['1', '2', '3']})
    >>> pprint.pformat(p.AS_DICT) == expected_result
    True

    >>> p.value = "STATUSCODE:BAD-REQUEST--REASON:Dont-Care"
    >>> pprint.pformat(p.AS_DICT) == pprint.pformat(
    ...     {'reason': 'Dont Care',
    ...      'status_code': 'BAD_REQUEST'})
    True
    """
    yaml_tag = u'!Param'

    default = None
    id = "%s"
    value = None
    to_tuples = None  # Useful for params that support LIST_OF_DICTS format.

    @property
    def VAL(self):
        return self.value or self.default

    @property
    def ID(self):
        return self.id % self.VAL

    @property
    def AS_LIST(self):
        return expand_list(self.VAL)

    @property
    def AS_IDLIST(self):
        return [self.id % x for x in self.AS_LIST]

    @property
    def AS_LIST_OF_DICTS(self):
        return str_to_list_dicts(self.VAL, to_tuples=self.to_tuples)

    @classmethod
    def _is_dict_format(cls, string):
        """
        Helper to determine if the provided string matches with with the
        convention of our dict format.

        >>> string = "1:10.0.0.1/24,10.0.0.2/24--2:10.0.0.1--3:1-3"
        >>> Param._is_dict_format(string)
        True
        >>> string = "1:a--2"
        >>> Param._is_dict_format(string)
        False
        """
        key_regex = "[a-zA-Z0-9]+"
        value_regex = ("([a-zA-Z0-9/\.]|[a-zA-Z0-9/\.]\-[a-zA-Z0-9/\.]|"
                       ",[a-zA-Z0-9/\.])+")
        pattern = ("^(%s:%s){1}(\-\-%s:%s)*$" %
                   (key_regex, value_regex, key_regex, value_regex))
        if re.search(pattern, string):
            return True
        return False

    @property
    def AS_DICT(self):
        """
        Convert the value provided as input to a dictionary.
        When trying to convert to a dictionary, the value should be in the
        format: '<key1>:<val1>--<key2>:<val2>'
        For <val>, it can be provided in 3 different ways:
        1. Normal string:
           This will be copied as-is to the value.
           E.g.:
           input: 1 or 'foo' or 'bar' or '10.0.0.1'
           output: 1 or 'foo' or 'bar' or '10.0.0.1'
        2. Multiple strings:
           This will be converted to a list and copied to the value.
           E.g.:
           input: '10.0.0.1/24,10.0.0.2/24'
           output: ['10.0.0.1/24', '10.0.0.2/24']
        3. Range of integers:
           This will be expanded to a list with all values in the range.
           E.g.:
           input: '1-3'
           output: ['1', '2', '3']

        E.g.:
        Input: '1:10.0.0.1/24,10.0.0.2/24--2:10.0.0.1--3:1-3'
        Output: {'1': ['10.0.0.1/24', '10.0.0.2/24'],
                 '2': ['10.0.0.1'],
                 '3': ['1', '2', '3']}
        """
        input_vals = self.VAL.split("--")
        ret_val = {}
        for input_val in input_vals:
            key, val = input_val.split(":")
            if key in supported_params:
                param_obj = eval("supported_params['%s']" % key)
                param_obj.value = val
                val = param_obj.VAL
                if key in PARAMS_MAP:
                    key = PARAMS_MAP[key]
            else:
                val = expand_list(val)
            ret_val[key] = val
        return ret_val

    @property
    def IS_SPECIFIED(self):
        return self.value is not None

    @property
    def IS_SPECIFIED_NULL(self):
        return self.value.upper() == "NULL"

    @property
    def SPECIFIED(self):
        if self.value is None:
            raise ValueError
        return self.VAL

    @property
    def SPECIFIED_ID(self):
        return self.id % self.SPECIFIED

    @property
    def SPECIFIED_AS_LIST(self):
        return expand_list(self.SPECIFIED)

    @property
    def SPECIFIED_AS_IDLIST(self):
        return [self.id % x for x in self.SPECIFIED_AS_LIST]


class IntParam(Param):
    yaml_tag = u'!IntParam'
    default = 1

    @property
    def VAL(self):
        value = self.value or self.default
        try:
            return int(value)
        except ValueError:
            return value


class StrParam(Param):
    yaml_tag = u'!StrParam'
    default = ''


class DelimStrParam(Param):
    """
    Class to expand a string based on user provided delimiters.

    >>> param = DelimStrParam()
    >>> param.value = "BAD-STATUS"
    >>> param.ID
    'BAD_STATUS'
    >>> param.out_delimiter = " "
    >>> param.ID
    'BAD STATUS'
    """
    yaml_tag = u'!DelimStrParam'
    default = ''
    in_delimiter = "-"
    out_delimiter = "_"

    @property
    def VAL(self):
        return self.out_delimiter.join(self.value.split(self.in_delimiter))

    @property
    def SPECIFIED(self):
        if self.value is None:
            raise ValueError
        return self.VAL


class StrOrDictParam(Param):
    """
    This param can take a value of a dict or a string.

    See the acceptable dict format for this param value in the documentation of
    'AS_DICT' property of 'PARAM' class.

    >>> p = StrOrDictParam()
    >>> p.value = "1:10.0.0.1/24,10.0.0.2/24--2:10.0.0.1--3:1-3"
    >>> import pprint
    >>> expected_result = pprint.pformat(
    ...     {'1': ['10.0.0.1/24', '10.0.0.2/24'],
    ...      '2': ['10.0.0.1'], '3': ['1', '2', '3']})
    >>> pprint.pformat(p.AS_DICT) == expected_result
    True

    >>> p.value = "STATUSCODE:BAD-REQUEST--REASON:Dont-Care"
    >>> pprint.pformat(p.SPECIFIED) == pprint.pformat(
    ...     {'reason': 'Dont Care', 'status_code': 'BAD_REQUEST'})
    True

    >>> p.value = "Some-string"
    >>> p.SPECIFIED
    'Some-string'
    """
    yaml_tag = u'!StrOrDictParam'
    default = ''

    @property
    def SPECIFIED(self):
        if self._is_dict_format(self.value):
            return self.AS_DICT
        return self.VAL


class BoolParam(Param):
    yaml_tag = u'!BoolParam'
    id = "!!str %s"


class AdapterParam(Param):
    """
    Class to specify Adapter parameters for workload expansion.

    For AdapterParam, we support providing a vnic or vif object as:
    vm.[1].vnic.[1] or vm.[1].vif[1] or IP address of the adapter (192.168.1.1)

    When a vnic or vif object is provided, there is an option to fetch an
    attribute of the vnic or vif, if needed.
    Users should indicate this by using the 'id' attribute of this class.

    For e.g.:
        NXTHOP: !AdapterParam
            id: ip
        In the above case, the user is indicating that he wants to use the 'ip'
        attribute of a vnic or vif object when vnic or vif object is provided.
        The expansion in this case would look like:
        >>> x = AdapterParam()
        >>> x.value = 'VM1VNIC1-2'
        >>> x.ID
        'vm.[1].vnic.[1-2]'
        >>> x.value = '192.168.1.1'
        >>> x.ID
        '192.168.1.1'
        >>> x.value = 'LLRP1-4'
        >>> x.ID
        'logicalrouterlinkport.[1-4]'
        >>> x.value = 'VM2VIF1-2'
        >>> x.ID
        'vm.[2].vif.[1-2]'
        >>> x.AS_LIST
        ['vm.[2].vif.[1]', 'vm.[2].vif.[2]']
        >>> x.value = 'ESX1VMNIC1'
        >>> x.ID
        'esx.[1].vmnic.[1]'
        >>> x.value = 'KVM1PIF1-2'
        >>> x.ID
        'kvm.[1].pif.[1-2]'
    """
    yaml_tag = u'!AdapterParam'
    id = None

    def _find_id_val(self):
        adapter_dict = {
            "vnic": ("(vm)(?P<vm>(\d|-|,)+)(vnic)(?P<vnic>(\d|-|,)+)", "vm.[%(vm)s].vnic.[%(vnic)s]"),  # noqa
            "vif": ("(vm)(?P<vm>(\d|-|,)+)(vif)(?P<vif>(\d|-|,)+)", "vm.[%(vm)s].vif.[%(vif)s]"),  # noqa
            "esxvtep": ("(esx)(?P<esx>(\d|-|,)+)(vtep)(?P<vtep>(\d|-|,)+)", "esx.[%(esx)s].vtep.[%(vtep)s]"),  # noqa
            "kvmvtep": ("(kvm)(?P<kvm>(\d|-|,)+)(vtep)(?P<vtep>(\d|-|,)+)", "kvm.[%(kvm)s].vtep.[%(vtep)s]"),  # noqa
            "esxvmnic": ("(esx)(?P<esx>(\d|-|,)+)(vmnic)(?P<vmnic>(\d|-|,)+)", "esx.[%(esx)s].vmnic.[%(vmnic)s]"),  # noqa
            "kvmpif": ("(kvm)(?P<kvm>(\d|-|,)+)(pif)(?P<pif>(\d|-|,)+)", "kvm.[%(kvm)s].pif.[%(pif)s]"),  # noqa
            "lrp": ("(lrp)(?P<lrp>(\d|-|,)+)", "logicalrouterport.[%(lrp)s]"),  # noqa
            "nsxmlrp": ("(nsxm)(?P<nsxm>(\d|-|,)+)(lrp)(?P<lrp>(\d|-|,)+)", "nsxmanager.[%(nsxm)s].logicalrouterport.[%(lrp)s]"),  # noqa
            "llrp": ("(llrp)(?P<llrp>(\d|-|,)+)", "logicalrouterlinkport.[%(llrp)s]"),  # noqa
            "nsxmllrp": ("(nsxm)(?P<nsxm>(\d|-|,)+)(llrp)(?P<llrp>(\d|-|,)+)", "nsxmanager.[%(nsxm)s].logicalrouterlinkport.[%(llrp)s]"),  # noqa
            "ulrp": ("(ulrp)(?P<ulrp>(\d|-|,)+)", "logicalrouteruplinkport.[%(ulrp)s]"),  # noqa
            "nsxmulrp": ("(nsxm)(?P<nsxm>(\d|-|,)+)(ulrp)(?P<ulrp>(\d|-|,)+)", "nsxmanager.[%(nsxm)s].logicalrouteruplinkport.[%(llrp)s]"),  # noqa
        }
        for name, info in adapter_dict.items():
            pattern, idstr = info[0], info[1]
            m = re.compile(pattern).match(self.VAL.lower())
            if m:
                return idstr, m.groupdict()
        else:
            return None, self.VAL

    @property
    def ID(self):
        idstr, val = self._find_id_val()
        if idstr is None:
            return val
        else:
            if self.id is not None:
                idstr = idstr + '->%s' % self.id
            return idstr % val

    @property
    def SPECIFIED_ID(self):
        idstr, val = self._find_id_val()
        if val is None:
            raise ValueError
        if idstr is None:
            return val
        else:
            if self.id is not None:
                idstr = idstr + '->%s' % self.id
            return idstr % val

    @property
    def AS_LIST(self):
        idstr, val = self._find_id_val()
        return [idstr % x for x in expand_dict(val)]

    @property
    def AS_IDLIST(self):
        idstr, val = self._find_id_val()
        if self.id is not None:
            idstr = idstr + '->%s' % self.id
        return [idstr % x for x in expand_dict(val)]


class TupleParam(Param):
    """
    Class to specify host parameters for workload expansion.

    >>> x = TupleParam()
    >>> x.value = 'ESX1-2'
    >>> x.SPECIFIED_ID
    'esx.[1-2]'
    >>> x.value = 'KVM1'
    >>> x.SPECIFIED_ID
    'kvm.[1]'
    """
    yaml_tag = u'!TupleParam'
    id = None

    def _find_id(self):
        host_dict = {
            "nsxm": ("(nsxm)(?P<nsxm>(\d|-|,)+)", "nsxmanager.[%(nsxm)s]"),
            "nsxc": ("(nsxc)(?P<nsxc>(\d|-|,)+)", "nsxcontroller.[%(nsxc)s]"),
            "kvm": ("(kvm)(?P<kvm>(\d|-|,)+)", "kvm.[%(kvm)s]"),
            "esx": ("(esx)(?P<esx>(\d|-|,)+)", "esx.[%(esx)s]"),
            "nsxedge": ("(nsxedge)(?P<nsxedge>(\d|-|,)+)", "nsxedge.[%(nsxedge)s]"),  # noqa
        }
        for name, (pattern, tuple_format) in host_dict.items():
            m = re.compile(pattern).match(self.VAL.lower())
            if m:
                return tuple_format % m.groupdict()

    @property
    def SPECIFIED_ID(self):
        id_ = self._find_id()
        if not id_:
            raise ValueError("Failed to get host ID from %r" % self.VAL)
        return id_


supported_params = get_supported_params()


if __name__ == '__main__':
    import argparse
    import doctest
    import sys

    parser = argparse.ArgumentParser()
    parser.add_argument('--doctest', action='store_true', default=False)

    args = parser.parse_args(sys.argv[1:])
    if args.doctest:
        doctest.testmod(optionflags=doctest.ELLIPSIS)
        sys.exit(0)
