class WaitError(Exception):
    def __init__(self, name, handler):
        self.name = name
        self.handler = handler
