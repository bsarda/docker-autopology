import logging
import os
import sys
import logging.handlers

log = None
DEFAULT_LOG_FORMATTER = logging.Formatter(
    '%(asctime)s %(levelname)-8s %(threadName)s '
    '%(filename)s:%(lineno)s - %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S')
DEFAULT_LOG_DIR = '/tmp'
DEFAULT_LOG_FILE = 'autopology.log'
USER_CONFIG = None
ALLOW_VM_SSH = False


def set_auth_config(config):
    global USER_CONFIG
    USER_CONFIG = config


def get_auth_userpass(host_type, ip):
    """
    >>> a = {'esx': { 'default': { 'username': 'foo', 'password': 'bar' } } }
    >>> set_auth_config(a)
    >>> get_auth_userpass('esx', '1.1.1.1')
    ('foo', 'bar')
    >>> get_auth_userpass('kvm', '1.1.1.1')
    ('root', 'default')

    >>> b = {'esx': { '1.1.1.1': { 'username': 'foo', 'password': 'bar' } } }
    >>> set_auth_config(b)
    >>> get_auth_userpass('esx', '0000')
    ('root', 'default')
    >>> get_auth_userpass('esx', '1.1.1.1')
    ('foo', 'bar')
    """
    global USER_CONFIG
    username, password = 'root', 'default'
    if host_type.lower().startswith('esx'):
        host_type = 'esx'
    if any(host_type.lower().startswith(x) for x in ('rhel', 'ubuntu', 'kvm')):
        host_type = 'kvm'

    def pop_up(dct, *keys):
        for k in keys:
            if k in dct:
                dct = dct[k]
        return dct.get('username', username), dct.get('password', password)

    username, password = pop_up(USER_CONFIG, host_type, 'default')
    username, password = pop_up(USER_CONFIG, host_type, ip)
    return username, password


def configure_logging(app=None, log_dir=None):
    """
    Configures a global logger for autopology, logging for flask app and sets
    WARN log level for some 3rd party modules.

    @type app: Flask instance
    @param app: A flask app
    @rtype: logger object
    @return: logger for autopology
    """
    # Configure autopology logger
    log = configure_autopology_logger(log_dir=log_dir)
    # Configure Flask logging
    configure_flask_logging(app=app, log_dir=log_dir)
    # Configure 3rd party module logging
    for m in ('requests', 'urllib3', 'werkzeug'):
        logging.getLogger(m).setLevel(logging.WARN)
    return log


def configure_autopology_logger(log_dir=None):
    """
    Configures the global autopology logger
    """
    global log
    if log is not None:
        raise RuntimeError("Autopology logger already configured, reuse that.")

    logging.basicConfig(level=logging.DEBUG)
    # Create logger named 'autopology'
    log = logging.getLogger('autopology')
    # Disable logging to console
    log.propagate = False

    # Create a file handler which logs debug messages.
    fh = get_rotating_file_handler(log_dir, logging.DEBUG)
    fh.doRollover()

    # Add handler to the logger.
    log.addHandler(fh)
    return log


def configure_flask_logging(app=None, log_dir=None):
    """
    Configures logging for flask app.
    """
    if not app:
        log.warn("Flask app not provided, skip flask log configuration.")
        return
    fh = get_rotating_file_handler(log_dir, logging.WARN)
    app.logger.addHandler(fh)


def get_rotating_file_handler(log_dir, log_level):
    """
    Gets rotating file handlers for logging purposes.

    @type log_dir: str
    @param log_dir: path to the log directory
    @type log_level: str
    @param log_level: log level
    @rtype: RotatingFileHandler instance
    @return: A rotating file handler for given log file and log level.
    """
    if log_dir is None:
        log_dir = DEFAULT_LOG_DIR
    log_file = os.path.join(log_dir, DEFAULT_LOG_FILE)
    fh = logging.handlers.RotatingFileHandler(log_file, maxBytes=10485760,
                                              backupCount=10)
    fh.setLevel(log_level)
    fh.setFormatter(DEFAULT_LOG_FORMATTER)
    return fh

if __name__ == '__main__':
    import argparse
    import doctest

    parser = argparse.ArgumentParser()
    parser.add_argument('--doctest', action='store_true', default=False)
    args = parser.parse_args(sys.argv[1:])
    if args.doctest:
        doctest.testmod(optionflags=doctest.ELLIPSIS)
        sys.exit(0)
