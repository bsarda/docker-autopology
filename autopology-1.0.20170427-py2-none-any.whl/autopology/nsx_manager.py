import httplib
import json
import logging
import requests
import ssl
import yaml

import cookielib

log = logging.getLogger('autopology')


class NSXManager(object):
    headers = {'Content-Type': 'application/json'}

    def __init__(self, ip, username=None, password=None, nsx_cert_file=None):
        self.ip = ip
        self.username = username
        self.password = password
        self._session = None
        self._cookies = cookielib.CookieJar()
        self._cert_file = nsx_cert_file


    @property
    def auth(self):
        return (self.username, self.password)

    def _get_cert(self):
        if self._cert_file:
            return self._cert_file
        else:
            return True

    @property
    def session(self):
        if self._session is None:
            sess = requests.Session()
            sess.auth = self.auth
            data = dict(j_username=self.username, j_password=self.password)
            sess.post('https://%s/api/session/create' % self.ip, data=data,
                      headers=self.headers, cookies=self._cookies,
                      verify=self._get_cert())
            self._session = sess
        return self._session

    def _post(self, url, **kwargs):
        resp = self.session.post(url, headers=self.headers,
                                 verify=self._get_cert(), **kwargs)
        if resp.status_code == httplib.FORBIDDEN:
            self._session = None
            resp = self.session.post(url, headers=self.headers,
                                     verify=self._get_cert(), **kwargs)
        return resp

    def _put(self, url, **kwargs):
        resp = self.session.put(url, headers=self.headers,
                                verify=self._get_cert(), **kwargs)
        if resp.status_code == httplib.FORBIDDEN:
            self._session = None
            resp = self.session.put(url, headers=self.headers,
                                    verify=self._get_cert(), **kwargs)
        return resp

    def _get(self, url, **kwargs):
        resp = self.session.get(url, headers=self.headers,
                                verify=self._get_cert(), **kwargs)
        if resp.status_code == httplib.FORBIDDEN:
            self._session = None
            resp = self.session.get(url, headers=self.headers,
                                    verify=self._get_cert(), **kwargs)
        return resp

    def _del(self, url, **kwargs):
        resp = self.session.delete(url, headers=self.headers,
                                   verify=self._get_cert(), **kwargs)
        if resp.status_code == httplib.FORBIDDEN:
            self._session = None
            resp = self.session.delete(url, headers=self.headers,
                                       verify=self._get_cert(), **kwargs)
        return resp

    def get(self, path, uid=None, path_ext=None):
        url = 'https://%s/api/v1/%s' % (self.ip, path)
        if uid:
            url = "%s/%s" % (url, uid)
        if path_ext:
            url = "%s/%s" % (url, path_ext)
        results = []
        cursor = None
        while True:
            if cursor is None:
                urlc = url
            else:
                if '?' in url:
                    urlc = "%s&cursor=%s" % (url, cursor)
                else:
                    urlc = "%s?cursor=%s" % (url, cursor)
            r = self._get(urlc)
            log.debug((r.reason, r.content))
            if r.status_code != httplib.OK:
                log.debug("[GET] %s returned: %s" % (urlc, r.text))
            if r.encoding:
                ret = yaml.load(r.text.decode(r.encoding))
            else:
                ret = yaml.load(r.text)
            if 'result_count' in ret:
                results.extend(ret['results'])
                cursor = ret.get('cursor')
                if cursor:
                    continue
                return results
            else:
                return ret

    def delete(self, path, uid=None):
        url = 'https://%s/api/v1/%s' % (self.ip, path)
        if uid:
            url = "%s/%s" % (url, uid)
        log.debug("[DEL] %s\r" % url)
        r = self._del(url)
        if r.status_code != httplib.OK:
            log.info("[DEL] %s returned: %s" % (url, r.text))
        r.raise_for_status()
        if uid is None:
            return yaml.load(r.text.decode(r.encoding))
        return r.text

    def post(self, path, schema):
        url = 'https://%s/api/v1/%s' % (self.ip, path)
        r = self._post(url, data=json.dumps(schema))
        log.debug((r.reason, r.content))
        return r.json()

    def get_revision(self, path):
        return self.get(path)['_revision']

    def put(self, path, uid, schema, merge=False):
        if merge:
            schema['_revision'] = self.get_revision(path)
        if uid is None:
            url = 'https://%s/api/v1/%s' % (self.ip, path)
        else:
            url = 'https://%s/api/v1/%s/%s' % (self.ip, path, uid)
        r = self._put(url, data=json.dumps(schema))
        log.debug((r.reason, r.content))
        r.raise_for_status()
        return r.json()
