import config
import hypervisor
import guest_vm


class Inventory(object):
    @staticmethod
    def build_inventory(fabric_nodes):
        hv_json = Inventory._build_hv_json_from_fabric_nodes(fabric_nodes)
        for hv in hv_json["hv"]:
            # Get hv_obj
            ip = hv_json["hv"][hv]['ip']
            os_type = hv_json["hv"][hv]['os_type']
            username = hv_json["hv"][hv]['username']
            password = hv_json["hv"][hv]['password']
            hv_obj = hypervisor.Hypervisor.get_hv_obj(ip=ip, username=username,
                                                      os_type=os_type,
                                                      password=password)
            # Get VM inventory
            hv_json["hv"][hv]['vm'] = hv_obj.get_vm_inventory()
        return hv_json

    @classmethod
    def _build_hv_json_from_fabric_nodes(cls, fabric_nodes):
        hv_json = {}
        for index in xrange(len(fabric_nodes)):
            hv_index = index + 1  # HV index starts from 1, not 0.
            hv_json[hv_index] = {}
            ip = fabric_nodes[index]['ip_addresses'][0]
            os_type = fabric_nodes[index]['os_type']
            username, password = config.get_auth_userpass(os_type, ip)
            hv_json[hv_index]['ip'] = ip
            hv_json[hv_index]['os_type'] = os_type
            hv_json[hv_index]['username'] = username
            hv_json[hv_index]['password'] = password
        return {'hv': hv_json}

    @staticmethod
    def add_vm_interface(vm_json):
        """
        Adds interface to VM and appends the new interface UUID to the input
        json before returning it.

        """
        hv_os_type, hv_ip, vm_name, vm_ip = vm_json['vm_uuid'].split('/')
        # XXX: We are using '_' as a special separator so
        # we need replacement with another character.
        vm_name = vm_name.replace('$', '_')
        # Create HV object.
        hv_username, hv_password = config.get_auth_userpass(hv_os_type, hv_ip)
        hv_obj = hypervisor.Hypervisor.get_hv_obj(ip=hv_ip,
                                                  username=hv_username,
                                                  password=hv_password,
                                                  os_type=hv_os_type)
        # Create VM Object.
        vm_username, vm_password = config.get_auth_userpass('vm', vm_ip)
        vm_obj = guest_vm.GuestVM.get_vm_obj(ip=vm_ip,
                                             username=vm_username,
                                             password=vm_password,
                                             parent=hv_obj,
                                             name=vm_name)
        vm_json["interface_uuid"] = vm_obj.add_interface(
            ls_id=vm_json['logical_switch_id'], ip=vm_json['interface_ip'])
        return vm_json
