import json
import jinja2
import pprint
import requests
import socket
import time
import yaml

session = requests.Session()
session.trust_env = False


def u(mgr_ip, path):
    return 'http://%s:5000%s' % (mgr_ip, path)


def jinja2_expand(input_file):
    loader = jinja2.FileSystemLoader(".")
    ENV = jinja2.Environment(loader=loader, undefined=jinja2.StrictUndefined,
                             extensions=["jinja2.ext.do"])
    tmpl = ENV.from_string(open(input_file).read())
    return yaml.load(tmpl.render())


def make_post_bulk_call(mgr_ip, input_file):
    schema = jinja2_expand(input_file)
    # pprint.pprint(schema)
    url = u(mgr_ip, '/api/v2/bulk/')
    print 'POST BULK', url
    headers = {'Content-Type': 'application/json'}
    r = session.post(url, headers=headers, verify=False,
                     data=json.dumps(schema))
    resp = r.json()
    pprint.pprint(resp)
    make_get_bulk_call(mgr_ip, uid=resp['id'])


def make_post_toplogy_call(mgr_ip, input_file):
    schema = jinja2_expand(input_file)
    # pprint.pprint(schema)
    url = u(mgr_ip, '/api/v2/topologies/')
    print 'POST TOPO', url
    headers = {'Content-Type': 'application/json'}
    r = session.post(url, headers=headers, verify=False,
                     data=json.dumps(schema))
    resp = r.json()
    pprint.pprint(resp)
    make_get_toplogy_call(mgr_ip, uid=resp['id'])


def make_get_toplogy_call(mgr_ip, uid=None):
    if uid is None:
        url = u(mgr_ip, '/api/v2/topologies/')
    else:
        url = u(mgr_ip, '/api/v2/topologies/%s' % uid)
    print 'GET TOPO', url
    headers = {'Content-Type': 'application/json'}
    done = False
    while uid and not done:
        r = session.get(url, headers=headers, verify=False)
        resp = r.json()
        pprint.pprint(resp)
        done = resp.get('status') != 'INPROGRESS'
        if not done:
            time.sleep(5)


def make_get_bulk_call(mgr_ip, uid=None):
    if uid is None:
        url = u(mgr_ip, '/api/v2/bulk/')
    else:
        url = u(mgr_ip, '/api/v2/bulk/%s/state' % uid)
    print 'GET BULK', url
    headers = {'Content-Type': 'application/json'}
    done = False
    while uid and not done:
        r = session.get(url, headers=headers, verify=False)
        resp = r.json()
        pprint.pprint(resp)
        done = resp.get('status') != 'INPROGRESS'
        if not done:
            time.sleep(5)


def get_mgmt_ip():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.connect(("source.vmware.com", 80))
    mgmt_ip = s.getsockname()[0]
    s.close()
    return mgmt_ip


if __name__ == '__main__':
    import sys
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('-i', '--input-files', action='append', nargs='*',
                        default=[], help='Trigger topology api calls')
    parser.add_argument('-b', '--bulk-files', action='append', nargs='*',
                        default=[], help='Trigger bulk api calls ')
    parser.add_argument('-m', '--manager-ip', default=get_mgmt_ip(),
                        help='NSX Manager IP to make api calls')
    args = parser.parse_args(sys.argv[1:])
    input_files = sum(args.input_files, [])
    bulk_files = sum(args.bulk_files, [])

    make_get_toplogy_call(args.manager_ip)
    make_get_bulk_call(args.manager_ip)

    for f in input_files:
        make_post_toplogy_call(args.manager_ip, f)

    for f in bulk_files:
        make_post_bulk_call(args.manager_ip, f)

    make_get_toplogy_call(args.manager_ip)
    make_get_bulk_call(args.manager_ip)
    sys.exit(0)
