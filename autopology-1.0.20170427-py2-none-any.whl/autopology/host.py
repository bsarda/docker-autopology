import logging
import os

log = logging.getLogger('autopology')


class Host(object):
    """
    Base class for any host.
    """

    def __init__(self, ip=None, username=None, password=None):
        self.ip = ip
        self.username = username
        self.password = password

    def _try_pexpect(self, cmd, password=None, timeout=30):
        import pexpect
        ssh_newkey = 'Are you sure you want to continue connecting'
        ask_password = '[Pp]assword:'
        copied_ok = 'Now try logging into the machine'
        import cStringIO
        io = cStringIO.StringIO()
        p = pexpect.spawn(cmd, cwd=os.getcwd(), env=os.environ)
        p.logfile = io
        response = [ssh_newkey, ask_password, copied_ok, pexpect.EOF]
        reply = p.expect(response)
        ok = False
        if reply == response.index(ssh_newkey):
            # Say 'yes'
            p.sendline('yes')
            reply = p.expect([ssh_newkey, ask_password, pexpect.EOF])
        # Deliberately not elif, new key resets 'reply'
        if reply == response.index(ask_password):
            # Enter password
            p.sendline(password)
            try:
                p.expect(pexpect.EOF, timeout=timeout)
            except pexpect.TIMEOUT:
                log.warn('Login timed out while sending password')
            else:
                ok = True
        elif reply == response.index(copied_ok):
            ok = True
        return ok, io.getvalue()

    def ssh_copy_id(self, ip, user, password):
        log.debug("Copying SSH keys for '%s@%s'" % (user, ip))
        self._try_pexpect("ssh-copy-id  %s@%s" % (user, ip), password=password)
